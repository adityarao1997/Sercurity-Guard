
  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4" >
    <!-- Brand Logo -->
    <a href="#" class="brand-link elevation-4 mr-1">
      <img src="<?php echo base_url('resource/dist/img/logo3.png');?>"
          
           class="brand-image elevation-21"
           style="opacity: .8 ">
      <span class="brand-text font-weight-light"><b>Sup-Admin </b></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user (optional) -->
      <div class="user-panel d-flex">
      </div>

      <!-- Sidebar Menu --><br>
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column " data-widget="treeview" role="menu" data-accordion="false" role="menu" data-accordion="false">
                        <!-- Dashboard Menu -->
             <li class="nav-item has-treeview nav-link active">
               <a class="">
                 <?php echo anchor('AdminDash','<i class="nav-icon fas fa-chart-line"></i><p class="hidden-tablet">Dashboard </p>')?>
               </a>
             </li>
              <li class="nav-item has-treeview ">
               <a>
                <?php echo anchor('Order/PlacedOrder','<i class="nav-icon fas fa-user-plus "></i><p class="hidden-tablet">placed Order</p>','class = nav-link')?>
               </a>
             </li>
              <li class="nav-item has-treeview ">
               <a>
                <?php echo anchor('Order/UpcomingOrder','<i class="nav-icon fas fa-user-friends "></i><p class="hidden-tablet">Upcoming Order</p>','class = nav-link')?>
               </a>
             </li>
              <li class="nav-item has-treeview ">
               <a>
                <?php echo anchor('Order/PlacedOrder','<i class="nav-icon fas fa-user-plus "></i><p class="hidden-tablet">placed Order</p>','class = nav-link')?>
               </a>
             </li>

             <li class="nav-item has-treeview ">
               <a>
                <?php echo anchor('AdminDash/Admin','<i class="nav-icon fas fa-street-view "></i><p class="hidden-tablet">Admin Detail</p>','class = nav-link')?>
               </a>
             </li>
             <li class="nav-item has-treeview ">
               <a>
                <?php echo anchor('AdminDash/VendorDetails','<i class="nav-icon fas fa-street-view "></i><p class="hidden-tablet">Vender Detail</p>','class = nav-link')?>
               </a>
             </li>
             <li class="nav-item has-treeview ">
               <a>
                <?php echo anchor('AdminDash/UserView','<i class="nav-icon fas fa-street-view "></i><p class="hidden-tablet">User Detail</p>','class = nav-link')?>
               </a>
             </li>
                          <!-- Vnder Type -->
               <li class="nav-item has-treeview">
              <a>
                <?php echo anchor('AdminDash/vendor_type','<i class="nav-icon fas fa-user-plus "></i><p class="hidden-tablet">Vender Category</p>','class = nav-link')?>
               </a> 
             </li>
              <li class="nav-item has-treeview">
              <a>
                <?php echo anchor('AdminDash/City_available','<i class="nav-icon fas fa-user-plus "></i><p class="hidden-tablet">City Available</p>','class = nav-link')?>
               </a> 
             </li>
                
            
           <li class="nav-item has-treeview">
               <a href="#" class="nav-link">
                <!--   <i class="  fas fa-user-tie"></i> -->
                  <i class="  nav-icon fab fa-airbnb"></i>
                  <p>Sevices <i class="right fas fa-angle-left"></i> </p>
               </a>
            <ul class="nav nav-treeview">
            <li class="nav-item">
              <a>
                <?php echo anchor('AdminDash/Setup','<i class="nav-icon fas fa-award"></i><p class="hidden-tablet">Add Setup</p>','class = nav-link')?>
              </a>
            </li>
            </ul>

            <ul class="nav nav-treeview">
            <li class="nav-item">
              <a>
                <?php echo anchor('AdminDash/Do_YouProvide','<i class="nav-icon fas fa-award"></i><p class="hidden-tablet">Do You Provide</p>','class = nav-link')?>
              </a>
            </li>
            </ul>

            <ul class="nav nav-treeview">
            <li class="nav-item">
              <a>
                <?php echo anchor('AdminDash/PreferdFor','<i class="nav-icon fas fa-award"></i><p class="hidden-tablet">Preferd For</p>','class = nav-link')?>
              </a>
            </li>
            </ul>

            <ul class="nav nav-treeview">
            <li class="nav-item">
              <a>
                <?php echo anchor('AdminDash/Types','<i class="nav-icon fas fa-award"></i><p class="hidden-tablet">Types</p>','class = nav-link')?>
              </a>
            </li>
            </ul>
           
            <ul class="nav nav-treeview">
           <li class="nav-item">
              <a>
                <?php echo anchor('AdminDash/Deco','<i class="nav-icon fas fa-award"></i><p class="hidden-tablet">Add Decoration</p>','class = nav-link')?>
              </a>
            </li>  
            </ul>
             <ul class="nav nav-treeview">
               <li class="nav-item">
                  <a class="">
                 <?php echo anchor('AdminDash/Special','<i class="nav-icon fas fa-cogs"></i><p class="hidden-tablet">Special </p>','class = nav-link')?>
                  </a>
                </li>  
            </ul>
             <ul class="nav nav-treeview">
               <li class="nav-item">
              <a class="">
                 <?php echo anchor('AdminDash/Food','<i class="nav-icon fas fa-utensils"></i><p class="hidden-tablet">Food </p>','class = nav-link')?>
               </a>
               </li>  
            </ul>
            <ul class="nav nav-treeview">
               <li class="nav-item">
                <a>
                <?php echo anchor('AdminDash/Facility','<i class="nav-icon fas fa-award"></i><p class="hidden-tablet">Add Facility</p>','class = nav-link')?>
              </a>
               </li>  
            </ul>
           
         </li>
         <!-- Order Start------------------------------------------------------- -->

           <li class="nav-item has-treeview">
               <a href="#" class="nav-link">
                <!--   <i class="  fas fa-user-tie"></i> -->
                  <i class="  nav-icon fab fa-airbnb"></i>
                  <p>Order <i class="right fas fa-angle-left"></i> </p>
               </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a>
                
               </a>
             </li>
            </ul>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a>
               
               </a>
              </li>
            </ul>
              
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a>
                
               </a>
             </li>
            </ul>

         </li>
         <li class="nav-item has-treeview">
               <a href="#" class="nav-link">
                <!--   <i class="  fas fa-user-tie"></i> -->
                  <i class="  nav-icon fab fa-airbnb"></i>
                  <p>Sevices Detail <i class="right fas fa-angle-left"></i> </p>
               </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a>
                <?php echo anchor('AdminDash/ViewPackage','<i class="nav-icon fas fa-user-friends "></i><p class="hidden-tablet">View Packages </p>','class = nav-link')?>
               </a>
              </li>
            </ul>
              
            
         </li>
      
        <!-- 
         <li class="nav-item has-treeview nav-link ">
               <a class="">
                 <?php// echo anchor('AdminDash/City','<i class="nav-icon fas fa-tachometer-alt"></i><p class="hidden-tablet">City </p>')?>
               </a>
         </li> -->
            <li class="nav-item has-treeview">
               <a href="#" class="nav-link">
                <!--   <i class="  fas fa-user-tie"></i> -->
                  <i class="  nav-icon fab fa-airbnb"></i>
                  <p>Customer Enqiuery<i class="right fas fa-angle-left"></i> </p>
               </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a>
                <?php echo anchor('UserDash/Txt_dreamEvent','<i class="nav-icon fas fa-user-friends "></i><p class="hidden-tablet">Dream Event </p>','class = nav-link')?>
               </a>
              </li>
            </ul>
              
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a>
                <?php echo anchor('UserDash/UpcomgEvent','<i class="nav-icon fas fa-user-plus "></i><p class="hidden-tablet">Up Coming Event</p>','class = nav-link')?>
               </a>
             </li>
            </ul>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a>
                <?php echo anchor('UserDash/LetsPlan_Enq','<i class="nav-icon fas fa-user-plus "></i><p class="hidden-tablet">Event Plan Enquiery</p>','class = nav-link')?>
               </a>
             </li>
            </ul>
           </li>
           <li class="nav-item has-treeview">
               <a href="#" class="nav-link">
                <!--   <i class="  fas fa-user-tie"></i> -->
                  <i class="  nav-icon fab fa-airbnb"></i>
                  <p>Venue Enquiery<i class="right fas fa-angle-left"></i> </p>
               </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a>
                <?php echo anchor('UserDash/VenueEnquiry','<i class="nav-icon fas fa-user-plus "></i><p class="hidden-tablet">Venue Enquiry</p>','class = nav-link')?>
               </a>
             </li>
            </ul>

            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a>
                <?php echo anchor('UserDash/VenueCall','<i class="nav-icon fas fa-user-plus "></i><p class="hidden-tablet">Venue Call</p>','class = nav-link')?>
               </a>
             </li>
            </ul>
        
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a>
                <?php echo anchor('UserDash/VenuePlanMeetup','<i class="nav-icon fas fa-user-plus "></i><p class="hidden-tablet">Venue Plan Meetup</p>','class = nav-link')?>
               </a>
             </li>
            </ul>
         </li><br><br><br>
      </nav>
     

    </div>
  
   
