<?php defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set("Asia/Calcutta");
  $dtmonth = date("m");
  $dtyear = date("Y");
?> 
  <div class="content-wrapper">
    <div class="content-header pb-0">
      <div class="container-fluid">
        <div class="row ">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Attandance Searh</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Attandance Searh</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=" connectedSortable ">
         <?php echo form_open("Dashboard/search_att" ,['class'=>'navbar-form navbar-right ','role'=>'search']);?>
         <center>
          <div style="width: 58%;padding: 20px;">
               <select class="form-control" id="search_mnth" name="search_mnth">
                <?php
                for($i=2017; $i<$dtyear; $i++)
                {
                  ?>
                  <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                  <?php
                }
                ?>
                <option value="<?php echo $dtyear; ?>" selected><?php echo $dtyear; ?></option>
              </select>
          </div>
          <div style="width: 58%;padding: 20px;">
             <div class="row" id="Mnth_btn">
               
             </div>  
          </div>
         </center>
    </section>
  </div>
  