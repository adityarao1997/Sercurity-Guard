<?php 

    $this->load->view('SubAdmin/Layout/header');
    $this->load->view('SubAdmin/Layout/sidebar');
    $this->load->view('SubAdmin/attendance/Addattendace_Main.php');
    $this->load->view('SubAdmin/Layout/footer');

?>






