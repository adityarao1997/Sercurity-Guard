<?php 

    $this->load->view('SubAdmin/Layout/header');
    $this->load->view('SubAdmin/Layout/sidebar');
    $this->load->view('SubAdmin/Dashboard/indexM.php');
    $this->load->view('SubAdmin/Layout/footer');


?>






