<footer class="main-footer" style="margin-left: -20px;">
    <center><div class="float-right d-none d-sm-block">
    </div>
    <strong>Copyright ©  <a href="http://techhelper.in">Techhelper.in</a>.</strong> All rights
    reserved.</center>
</footer>

   
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo base_url();?>resource/plugins/jquery/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/js/DataTables/js/jquery.dataTables.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url();?>resource/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url();?>resource/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url();?>resource/dist/js/demo.js"></script>
<script src="<?php echo base_url();?>assets/Datatable/datatables.min.js"></script>
<script src="<?php echo base_url();?>assets/js/scripts2.js"></script>
</body>
</html>