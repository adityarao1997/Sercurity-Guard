<?php
  $login_id = $this->session->userdata('id');
  $login_dtl = $this->SAdmin_model->get_current_profile();

?>
<aside class="main-sidebar sidebar-dark-primary elevation-4" >
  <a href="#" class="brand-link elevation-4 mr-1">
    <img src="<?php echo base_url('resource/dist/img/.png');?>" class="brand-image elevation-21" style="opacity: .8 ">
    <span class="brand-text font-weight-light"><b>SubAdmin </b></span>
  </a>

  <?php
  if(!isset($cur_page))
  {
    $cur_page = "";
  }
  if(!isset($main_page))
  {
    $main_page = "";
  }
  ?>

  <div class="sidebar">
      <div class="user-panel mt-3 pb-2 d-flex">
        <div class="image">
          <img src="<?php echo base_url();?>resource/images/avtar.png" class="img-circle elevation-1" alt="User Image" style="width: 40px;">
        </div>
        <div class="info">
          <a href="#" class="d-block"><?=$login_dtl[0]['name']?></a>
        </div>
      </div>
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column " data-widget="treeview" role="menu" data-accordion="false" role="menu" data-accordion="false">

        
         <li class="nav-item has-treeview ">
          <a class=" nav-link <?php if($cur_page == 'dashboard'){ echo 'active'; } ?>" href="<?php echo base_url(); ?>Dashboard">
            <i class="nav-icon fas fa-chart-line"></i><p class="hidden-tablet">Dashboard </p>
          </a>
        </li>


         
        
         <li class="nav-item has-treeview <?php if($main_page == 'cust_enq'){ echo 'menu-open'; } ?>">
          <a href="#" class="nav-link ">
            <i class="  nav-icon fas fa-paperclip"></i>
            <p>Attandance <i class="right fas fa-angle-left"></i> </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a class="nav-link <?php if($cur_page == 'up_event'){ echo 'active'; } ?>" href="<?php echo base_url(); ?>Dashboard/All_Attandance">
                <i class="nav-icon text-success fas fa-circle-notch "></i><p class="hidden-tablet">All Attandance</p>
              </a>
            </li>
          </ul>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a class="nav-link <?php if($cur_page == 'lets_plan'){ echo 'active'; } ?>" href="<?php echo base_url(); ?>Dashboard/New_Attandance">
                <i class="nav-icon text-danger fas fa-circle-notch"></i><p class="hidden-tablet">New Attandance</p>
              </a>
            </li>
          </ul>
           <ul class="nav nav-treeview">
            <li class="nav-item">
              <a class="nav-link <?php if($cur_page == 'lets_plan'){ echo 'active'; } ?>" href="<?php echo base_url(); ?>Dashboard/search_att">
                <i class="nav-icon text-warning fas fa-circle-notch"></i><p class="hidden-tablet">Search Attendance</p>
              </a>
            </li>
          </ul>
        </li>

         <li class="nav-item has-treeview <?php if($main_page == 'cust_enq'){ echo 'menu-open'; } ?>">
          <a href="#" class="nav-link ">
            <i class="  nav-icon fas fa-user-shield"></i>
            <p>Employee Details<i class="right fas fa-angle-left"></i> </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a class="nav-link <?php if($cur_page == 'up_event'){ echo 'active'; } ?>" href="<?php echo base_url(); ?>Dashboard/All_Employee">
                <i class="nav-icon text-success fas fa-circle-notch"></i><p class="hidden-tablet">All Employee</p>
              </a>
            </li>
          </ul>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a class="nav-link <?php if($cur_page == 'lets_plan'){ echo 'active'; } ?>" href="<?php echo base_url(); ?>Dashboard/Create_Employee">
                <i class="nav-icon text-danger fas fa-circle-notch "></i><p class="hidden-tablet">Add Employee</p>
              </a>
            </li>
          </ul>
        </li>
        
        

       
       
      </ul>
    </nav>
  </div>
</aside>