<?php 

    $this->load->view('SubAdmin/Layout/header');
    $this->load->view('SubAdmin/Layout/sidebar');
    $this->load->view('SubAdmin/Employee/Addemp_Main.php');
    $this->load->view('SubAdmin/Layout/footer');

?>






