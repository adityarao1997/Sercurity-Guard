<?php 

    $this->load->view('SubAdmin/Layout/header');
    $this->load->view('SubAdmin/Layout/sidebar');
    $this->load->view('SubAdmin/Employee/Editemp_Main.php');
    $this->load->view('SubAdmin/Layout/footer');

?>






