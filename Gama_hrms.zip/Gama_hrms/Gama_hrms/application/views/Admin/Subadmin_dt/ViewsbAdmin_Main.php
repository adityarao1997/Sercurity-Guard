<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 
  <div class="content-wrapper">
    <div class="content-header pb-0">
      <div class="container-fluid">
        <div class="row ">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">SubAdmin List</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">SubAdmin View</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=" connectedSortable ">
         <?php echo form_open("AdminDash/Create_SAdmin" ,['class'=>'navbar-form navbar-right ','role'=>'search']);?>
         <center>
           <div class=" col-md-12">
             <?php echo form_submit(['value' => 'Add New','class'=>'btn btn-primary ']);?>
            </div>
         </center>
      <div style="width: 98%;padding: 20px;">
        <table  id="col_table" class="table table-striped table-bordered" >
          <thead  >
            <tr>
              <th scope="col">S. No.</th>
              <th scope="col"> Name</th>
              <th scope="col">Email</th>
              <th scope="col">city</th>
              <th scope="col">Role</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
          <?php
          $i = 0;
          foreach($subadmin as $adm)
          {
            $i++;
              $vend_id = $adm['city'];
              $data2 = $this->Admin_model->comapare($vend_id);
            ?>
            <tr>
              <td><?php echo $i; ?></td>
              <td><?php echo $adm['name']; ?></td>
              <td><?php echo $adm['email']; ?></td>
              <td><?php echo $data2[0]['city'] ?></td>
               <td class="text-bold text-danger"><?php if($adm['type'] == 2){?> Sub-Admin <?php } ?></td>
              <td>
                <a href="<?php echo site_url('AdminDash/Edit_SAdmin/'.$adm['id']);?>" style="color: white;" class="btn btn-success btn-sm">View</a> 
                <button type="button" class="btn btn-danger btn-sm dlt_click" id="<?php echo $adm['id']; ?>" data-name="<?php echo $adm['name']; ?>" data-url="<?php echo site_url('AdminDash/Del_SAdmin/'.$adm['id']);?>">Delete</button>
              </td>
            </tr>
            <?php
          }
          ?>
          </tbody>
        </table>
      </div>
    </section>
  </div>
  <div class="modal fade model-sm" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Are you Sure to delete this?</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
         
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-danger">
           <a href="" style="color: white;" class="delete_id">Delete</a> 
          </button>
        </div>
      </div>
    </div>
  </div>