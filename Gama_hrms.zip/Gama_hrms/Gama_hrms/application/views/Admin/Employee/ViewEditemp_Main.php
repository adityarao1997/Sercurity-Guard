<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 

<?php echo form_open_multipart('AdminDash/Employee_Edit/'.$emp_ad['id'],array("class"=>"form-horizontal")); ?>
 <?php if($error = $this->session->flashdata('login_response')):?>
      <div class="row">
        <div class="col-lg-12">
            <div class="alert alert-dismissible alert-danger">
               <?php echo $error; ?>
            </div>
       </div>
      </div>
    <?php endif; ?> 
<?php
$jdate = explode(',',$emp_ad['jdate']);
$rej_date = explode(',',$emp_ad['rej_date']);
$description = explode(',',$emp_ad['description']);

  $mem_nm = explode(',',$emp_ad['mem_nm']);
$mem_rel = explode(',',$emp_ad['mem_rel']);
$mem_con = explode(',',$emp_ad['mem_con']);
?>

 <div class="content-wrapper">
     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Employee Edit </h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('AdminDash');?>">Home</a></li>
              <li class="breadcrumb-item active">Employee View</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  
    <section class="col-lg-12 connectedSortable">
     <center><div class="col-lg-11">
         <div class="card-body login-card-body" style="border: 1px solid green;">
          <i class="nav-icon fab fa-audible"><h5 class="text-dark">Edit <b>Employee</b></h5></i> <a class="float-right" href="<?php echo base_url('AdminDash/All_Employee');?>"><i class="text-danger"><b>X<b></i></a><br><br>
          
           <b class="float-left text-danger"><h4>Personal Details</h4></b><br><hr>
               <div class="row mt-4">
                  <div class="col-lg-6">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Employee Name</label>
                     <input  type="text" name="fname" value="<?php echo ($this->input->post('fname') ? $this->input->post('fname') : $emp_ad['fname']); ?>" class="form-control" id="fname" placeholder="Employee Full  Name" readonly>
                  </div>
               </div>
               <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                     <label class="col-form-label float-left"><span class="text-danger">*</span>Father Name</label>
                     <input  type="text" name="faname"  value="<?php echo ($this->input->post('faname') ? $this->input->post('faname') : $emp_ad['faname']); ?>"  class="form-control" id="faname" placeholder="Father Name" readonly>
                  </div>
                  <div class="col-lg-6 float-right">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Mother Name</label>
                     <input  type="text" name="moname"  value="<?php echo ($this->input->post('moname') ? $this->input->post('moname') : $emp_ad['moname']); ?>"  class="form-control" id="moname" placeholder="Mother Name" readonly>
                  </div>
               </div>
               <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                     <label class="col-form-label float-left"><span class="text-danger">*</span>Address 1</label>
                     <input  type="text" name="addr" value="<?php echo ($this->input->post('addr') ? $this->input->post('addr') : $emp_ad['addr']); ?>"  class="form-control" id="addr" placeholder="Address 1" readonly>
                  </div>
                  <div class="col-lg-6 float-right">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Address 2</label>
                     <input  type="text" name="addr2" value="<?php echo ($this->input->post('addr2') ? $this->input->post('addr2') : $emp_ad['addr2']); ?>"  class="form-control" id="addr2" placeholder="Address 2" readonly>
                  </div>
               </div>
                <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                     <label class="col-form-label float-left"><span class="text-danger">*</span>Designation</label>
                     <select class="form-control" name="desg" disabled>
                       <option value="">Select Designation</option>
                        <option value="Security Guard" <?php if($emp_ad['desg'] == 'Security Guard'){ echo 'selected'; } ?>>Security Guard</option>
                        <option value="Security Supervisor" <?php if($emp_ad['desg'] == 'Security Supervisor'){ echo 'selected'; } ?>>Security Supervisor</option>
                        <option value="Head Guard" <?php if($emp_ad['desg'] == 'Head Guard'){ echo 'selected'; } ?>>Head Guard</option>
                        <option value="Security Officier" <?php if($emp_ad['desg'] == 'Security Officier'){ echo 'selected'; } ?>>Security Officier</option>
                        <option value="Gun Man" <?php if($emp_ad['desg'] == 'Gun Man'){ echo 'selected'; } ?>>Gun Man</option>
                        <option value="Lady Guard" <?php if($emp_ad['desg'] == 'Lady Guard'){ echo 'selected'; } ?>>Lady Guard</option>
                        <option value="Other" <?php if($emp_ad['desg'] == 'Other'){ echo 'selected'; } ?>>Other</option>
                     </select>
                  </div>
                  <div class="col-lg-6 float-right">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Gender</label>
                     <select class="form-control" name="gender" disabled>
                       <option value="">Select Gender</option>
                        <option value="Male" <?php if($emp_ad['gender'] == 'Male'){ echo 'selected'; } ?>>Male</option>
                        <option value="Female" <?php if($emp_ad['gender'] == 'Female'){ echo 'selected'; } ?>>Female</option>
                     </select>
                  </div>
               </div>
                <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Mobile Number</label>
                     <input  type="text" name="cont"  value="<?php echo ($this->input->post('cont') ? $this->input->post('cont') : $emp_ad['cont']); ?>"  class="form-control" id="cont" placeholder="Mobile Number" readonly>
                  </div>
                  <div class="col-lg-6 float-right">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Marriage Status</label>
                    <select class="form-control" name="mrg_status" disabled>
                       <option value="">Status</option>
                        <option value="Single" <?php if($emp_ad['mrg_status'] == 'Single'){ echo 'selected'; } ?>>Single</option>
                        <option value="Married" <?php if($emp_ad['mrg_status'] == 'Married'){ echo 'selected'; } ?>>Married</option>
                        <option value="Un-married" <?php if($emp_ad['mrg_status'] == 'Un-married'){ echo 'selected'; } ?>>Un-married</option>
                     </select>
                  </div>
               </div>
               <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                     <label class="col-form-label float-left"><span class="text-danger">*</span>DOB</label>
                     <input  type="date" name="dob" value="<?php echo ($this->input->post('dob') ? $this->input->post('dob') : $emp_ad['dob']); ?>" class="form-control" id="dob" placeholder="Date of Birth" readonly>
                  </div>
                 
               </div>
                   <br><b class="float-left text-danger"><h4>KYC Detail's</h4></b><br><hr>
              <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Adhaar Number</label>
                    <input  type="text" name="adhar_num" value="<?php echo ($this->input->post('adhar_num') ? $this->input->post('adhar_num') : $emp_ad['adhar_num']); ?>" class="form-control" id="adhar_num" placeholder="Adhaar Card Number" readonly>
                  </div>
                  <div class="col-lg-6 float-right">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Pan Card Number</label>
                     <input  type="text" name="pan_num" value="<?php echo ($this->input->post('pan_num') ? $this->input->post('pan_num') : $emp_ad['pan_num']); ?>" class="form-control" id="pan_num" placeholder="Pan Card Number"  readonly>
                  </div>
              </div>
              <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Account Holder Name</label>
                    <input  type="text" name="ac_name" value="<?php echo ($this->input->post('ac_name') ? $this->input->post('ac_name') : $emp_ad['ac_name']); ?>" class="form-control" id="ac_name" placeholder="Account Holder Name" readonly>
                  </div>
                  <div class="col-lg-6 float-right">
                   <label class="col-form-label float-left"><span class="text-danger">*</span>Account Number</label>
                   <input  type="text" name="ac_no" value="<?php echo ($this->input->post('ac_no') ? $this->input->post('ac_no') : $emp_ad['ac_no']); ?>" class="form-control" id="ac_no" placeholder="Pan Card Number" readonly>
                  </div>
              </div>
              <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Bank Name</label>
                     <select class="form-control" name="bank_name" id="bank_name" disabled>
                        <option value="">Select Bank</option>
                        <option value="Indian Overseas Bank" <?php if($emp_ad['bank_name'] == 'Indian Overseas Bank'){ echo 'selected'; } ?>>Indian Overseas Bank</option>
                        <option value="Other" <?php if($emp_ad['bank_name'] == 'Other'){ echo 'selected'; } ?>>Other</option>
                        <
                     </select>
                  </div>
                  <div class="col-lg-6 float-right">
                   <label class="col-form-label float-left"><span class="text-danger">*</span>IFSC Code</label>
                   <input  type="text" name="ifsc" value="<?php echo ($this->input->post('ifsc') ? $this->input->post('ifsc') : $emp_ad['ifsc']); ?>" class="form-control" id="ifsc" placeholder="IFSC Code" readonly>
                  </div>
              </div>
              <br><b class="float-left text-danger"><h4>Professional Details</h4></b><br><hr>
              <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>UAN No.</label>
                    <input  type="text" name="lname"  value="<?php echo ($this->input->post('lname') ? $this->input->post('lname') : $emp_ad['lname']); ?>" class="form-control" id="lname" placeholder="UAN No" readonly>
                  </div>
                  <div class="col-lg-6 float-right">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>ESIC No.</label>
                     <input  type="text" name="esic_num"  value="<?php echo ($this->input->post('esic_num') ? $this->input->post('esic_num') : $emp_ad['esic_num']); ?>" class="form-control" id="esic_num" placeholder="ESIC No." readonly>
                  </div>
              </div>
              <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Medical Certificate</label>
                     <select class="form-control" name="med_cer" disabled>
                        <option value="">Select</option>
                        <option value="Yes" <?php if($emp_ad['med_cer'] == 'Yes'){ echo 'selected'; } ?>>Yes</option>
                        <option value="No" <?php if($emp_ad['med_cer'] == 'No'){ echo 'selected'; } ?>>No</option>
                     </select>
                  </div>
                  <div class="col-lg-6 float-right">
                   <label class="col-form-label float-left"><span class="text-danger">*</span>Police Verification</label>
                   <select class="form-control" name="polic_ver" disabled>
                        <option value="">Select</option>
                         <option value="Yes" <?php if($emp_ad['polic_ver'] == 'Yes'){ echo 'selected'; } ?>>Yes</option>
                        <option value="No" <?php if($emp_ad['polic_ver'] == 'No'){ echo 'selected'; } ?>>No</option>
                     </select>
                  </div>
              </div>
              <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Do You have Any Pending Case?</label>
                     <select class="form-control" name="polic_case" disabled>
                        <option value="">Select </option>
                         <option value="Yes" <?php if($emp_ad['polic_case'] == 'Yes'){ echo 'selected'; } ?>>Yes</option>
                        <option value="No" <?php if($emp_ad['polic_case'] == 'No'){ echo 'selected'; } ?>>No</option>
                     </select>
                  </div>
                  <div class="col-lg-6 float-right">
                   <label class="col-form-label float-left"><span class="text-danger">*</span>Are you Indian?</label>
                   <select class="form-control" name="nationality" disabled>
                        <option value="">Select </option>
                        <option value="Yes" <?php if($emp_ad['nationality'] == 'Yes'){ echo 'selected'; } ?>>Yes</option>
                        <option value="No" <?php if($emp_ad['nationality'] == 'No'){ echo 'selected'; } ?>>No</option>
                     </select>
                  </div>
              </div>
               <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Location</label>
                     <select class="form-control" name="loc_type" disabled>
                        <option value="">Select Location</option>
                         <option value="Central" <?php if($emp_ad['loc_type'] == 'Central'){ echo 'selected'; } ?>>Central</option>
                        <option value="State" <?php if($emp_ad['loc_type'] == 'State'){ echo 'selected'; } ?>>State</option>
                     </select>
                  </div>
                  <div class="col-lg-6 float-right">
                   <label class="col-form-label float-left"><span class="text-danger">*</span>City</label>
                   <select class="form-control" name="city" disabled>
                        <option value="">Select City</option>
                        <?php 
                          foreach($all_city_type as $city_type)
                          {
                           $selected = ($city_type['id'] == $emp_ad['city']) ? ' selected="selected"' : "";
                          echo '<option value="'.$city_type['id'].'" '.$selected.'>'.$city_type['city'].'</option>';
                           } 
                          ?>
                     </select>
                  </div>
              </div>
               <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Company Name</label>
                     <select class="form-control" name="co_name" disabled>
                        <option value="">Select City</option>
                        <?php 
                          foreach($all_cmp_type as $cmpy)
                          {
                            $selected = ($cmpy['id'] == $emp_ad['co_name']) ? ' selected="selected"' : "";
                            echo '<option value="'.$cmpy['id'].'" '.$selected.'>'.$cmpy['cl_coname'].'</option>';
                           } 
                          ?>
                     </select>
                  </div>
                  <div class="col-lg-6 float-right">
                   <label class="col-form-label float-left"><span class="text-danger">*</span>Zone</label>
                   <select class="form-control" name="zone" disabled>
                        <option value="">Select City</option>
                        <?php 
                          foreach($all_zone_type as $Zone)
                          {
                            $selected = ($Zone['id'] == $emp_ad['zone']) ? ' selected="selected"' : "";
                            echo '<option value="'.$Zone['id'].'" '.$selected.'>'.$Zone['zone'].'</option>';
                           } 
                          ?>
                     </select>
                  </div>
              </div>
                <br><b class="float-left text-danger"><h4>Family Detail's</h4></b><br><hr>
                <div class="row mt-3">
                  <table class="table table-hover table-active" id="dynamic_field1">  
                    <thead class="f1">
                      <tr>
                         <th scope="col" class="f2">Member Name</th>
                         <th scope="col" class="f2">Member relation</th>
                         <th scope="col" class="f2">Contact</th>
                      </tr>
                    </thead>
                     <tbody class="thead-light"> 
                      <?php
                        $i=0;
                        foreach ($mem_nm as $key1)
                        {
                          $but = "";
                          $j = $i+1;
                          if($i == 0)
                          {
                            $but = '
                              <button type="button" name="add" id="add1" class="btn btn-success">Add</button>
                            ';
                          }
                          else
                          {
                            $but = '
                              <button type="button" name="remove" id="'.$j.'" class="btn btn-danger btn_remove">X</button>
                            ';
                          }
                          ?> 
                          <tr id="row<?=$j ?>">
                            <td><input type="text" class="form-control" value="<?=$key1 ?>" name="mem_nm[][mem_nm]" /></td>
                            <td><input type="text" class="form-control" value="<?=$mem_rel[$i] ?>" name="mem_rel[][mem_rel]"></td>
                            <td><textarea type="text" class="form-control" value="<?=$mem_con[$i] ?>" name="mem_con[][mem_con]"><?=$mem_con[$i] ?></textarea></td>
                            <td><?=$but?></td> 
                          </tr>
                          <?php
                          $i++;
                        }
                      ?> 
                    </tbody>
                  </table>
                </div>
              
                <br><b class="float-left text-danger"><h4>Attached Document Details (Max 5MB)</h4></b><br><hr>
              <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Adhar card Pic</label>
                    <?php if($emp_ad['adhar']){?>
                    <img src="../../../Gama_hrms/upload/Employee/<?php echo $emp_ad['adhar'];?>" style="height: 70px; width: 70px;" class="form-control float-left"/>
                    <?php } else{ ?>
                    <img class="img" src="<?php echo base_url();?>assets/img/n0_doc.png" alt="User Avatar" style="height: 100px; width: 100px; border-radius: 100px;">
                    <?php }?>
                    <input  type="file" name="adhar" class="form-control" id="adhar">
                  </div>
                  <div class="col-lg-6 float-right">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Pan card Pic</label>
                   <?php if($emp_ad['pan_up']){?>
                    <img src="../../../Gama_hrms/upload/Employee/<?php echo $emp_ad['pan_up'];?>" style="height: 70px; width: 70px;" class="form-control float-left"/>
                    <?php } else{ ?>
                    <img class="img" src="<?php echo base_url();?>assets/img/n0_doc.png" alt="User Avatar" style="height: 100px; width: 100px; border-radius: 100px;">
                    <?php }?>
                    <input  type="file" name="pan_up" class="form-control" id="pan_up">
                  </div>
              </div>
               <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Passbook Pic</label>
                    <?php if($emp_ad['passbook']){?>
                    <img src="../../../Gama_hrms/upload/Employee/<?php echo $emp_ad['passbook'];?>" style="height: 70px; width: 70px;" class="form-control float-left"/>
                    <?php } else{ ?>
                    <img class="img" src="<?php echo base_url();?>assets/img/n0_doc.png" alt="User Avatar" style="height: 100px; width: 100px; border-radius: 100px;">
                    <?php }?>
                    <input  type="file" name="passbook" class="form-control" id="passbook">
                  </div>
                  <div class="col-lg-6 float-right">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>10th Marksheet</label>
                   <?php if($emp_ad['ten_mask']){?>
                    <img src="../../../Gama_hrms/upload/Employee/<?php echo $emp_ad['adhar'];?>" style="height: 70px; width: 70px;" class="form-control float-left"/>
                    <?php } else{ ?>
                    <img class="img" src="<?php echo base_url();?>assets/img/n0_doc.png" alt="User Avatar" style="height: 100px; width: 100px; border-radius: 100px;">
                    <?php }?>
                    <input  type="file" name="ten_mask" class="form-control" id="ten_mask">
                  </div>
              </div>
               <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>12th Marksheet</label>
                    <?php if($emp_ad['twl_mark']){?>
                    <img src="../../../Gama_hrms/upload/Employee/<?php echo $emp_ad['twl_mark'];?>" style="height: 70px; width: 70px;" class="form-control float-left"/>
                    <?php } else{ ?>
                    <img class="img" src="<?php echo base_url();?>assets/img/n0_doc.png" alt="User Avatar" style="height: 100px; width: 100px; border-radius: 100px;">
                    <?php }?>
                    <input  type="file" name="twl_mark" class="form-control" id="twl_mark">
                  </div>
                  <div class="col-lg-6 float-right">
                     <label class="col-form-label float-left"><span class="text-danger">*</span>Profile Pic (Max 5MB)</label>
                     <?php if($emp_ad['image']){?>
                    <img src="../../../Gama_hrms/upload/Employee/<?php echo $emp_ad['image'];?>" style="height: 70px; width: 70px;" class="form-control float-left"/>
                    <?php } else{ ?>
                    <img class="img" src="<?php echo base_url();?>assets/img/n0_doc.png" alt="User Avatar" style="height: 100px; width: 100px; border-radius: 100px;">
                    <?php }?>
                    <input  type="file" name="image" class="form-control" id="image">
                  </div>
                  
              </div>
              <br><b class="float-left text-danger"><h4>Job Status (Past)</h4></b><br><hr>
                <div class="row mt-3">
                  <table class="table table-hover table-active" id="dynamic_field">  
                    <thead class="f1">
                      <tr>
                         <th scope="col" class="f2">Joining Date</th>
                         <th scope="col" class="f2">Reject Date</th>
                         <th scope="col" class="f2">Description</th>
                      </tr>
                    </thead>
                     <tbody class="thead-light"> 
                      <?php
                        $i=0;
                        foreach ($jdate as $key1)
                        {
                          $but = "";
                          $j = $i+1;
                          if($i == 0)
                          {
                            $but = '
                              <button type="button" name="add" id="add" class="btn btn-success">Add</button>
                            ';
                          }
                          else
                          {
                            $but = '
                              <button type="button" name="remove" id="'.$j.'" class="btn btn-danger btn_remove">X</button>
                            ';
                          }
                          ?> 
                          <tr id="row<?=$j ?>">
                            <td><input type="date" class="form-control" value="<?=$key1 ?>" name="jdate[][jdate]" /></td>
                            <td><input type="date" class="form-control" value="<?=$rej_date[$i] ?>" name="rej_date[][rej_date]"></td>
                            <td><textarea type="text" class="form-control" value="<?=$description[$i] ?>" name="description[][description]"><?=$description[$i] ?></textarea></td>
                            <td><?=$but?></td> 
                          </tr>
                          <?php
                          $i++;
                        }
                      ?> 
                    </tbody>
                  </table>
                </div>
          <div class="form-group row mt-5">
            
            <div class="col-md-6">
            <a class="btn btn-danger" href="<?php echo base_url('AdminDash/All_Employee');?>">Cancel</a>
             <a class="btn btn-success btn-sm" href="<?php echo site_url('AdminDash/printDiv/'.$emp_ad['id']);?>" style="color: white;"><i class="fas fa-print"></i></a> 
            </div>
           </div>
          </div>
        </div></center>    
    </section>
  </div>
<?php echo form_close(); ?>   
 <script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){      
      var i=1;  


      $('#add').click(function(){  
           i++;
           var count = $('.alltrs').length;
           count++; 
           $('#dynamic_field').append('<tr id="row'+i+'" class="dynamic-added alltrs"><td><input type="date" class="form-control" name = "jdate[][jdate]" /></td><td><input type="date" class="form-control" name = "rej_date[][rej_date]" /></td><td><textarea type="date" class="form-control" name = "description[][description]" placeholder="Rating" value=""/></textarea></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></td></tr>');  
      });

      $(document).on('click', '.btn_remove', function(){  
           var button_id = $(this).attr("id");   
           $('#row'+button_id+'').remove();  
      });  


    });  
</script>