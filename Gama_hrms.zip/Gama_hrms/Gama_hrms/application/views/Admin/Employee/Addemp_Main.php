<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 
<?php echo form_open_multipart('AdminDash/Create_Employee',array("class"=>"form-horizontal")); ?>
 <?php if($error = $this->session->flashdata('login_response')):?>
      <div class="row">
        <div class="col-lg-12">
            <div class="alert alert-dismissible alert-danger">
               <?php echo $error; ?>
            </div>
       </div>
      </div>
    <?php endif; ?> 
<div class="content-wrapper ">
     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Employee Add</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('AdminDash');?>">Home</a></li>
              <li class="breadcrumb-item active">Employee Add</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  
    <section class="col-lg-12 connectedSortable">
     <center><div class="col-lg-11">
      <span class="error_form_msg"></span>
         <div class="card-body login-card-body">
            <i class="nav-icon fab fa-audible"><h5 class="text-dark">Add <b>New Employee</b></h5>
            </i><a class="float-right" href="<?php echo base_url('AdminDash/All_Employee');?>"><i class=" text-danger"><b>X<b></i></a> <br><br>
               <b class="float-left text-danger"><h4>Personal Details</h4></b><br><hr>
               <div class="row mt-4">
                  <div class="col-lg-6 float-left">
                     <label class="col-form-label float-left"><span class="text-danger">*</span>Profile Pic (Max 5MB)</label>
                     <input  type="file" name="image" class="form-control" id="image">
                  </div>
                  <div class="col-lg-6 float-right">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Employee Name</label>
                     <input  type="text" name="fname" class="form-control inpreq" id="fname" placeholder="Employee Full  Name">
                  </div>
               </div>
               <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                     <label class="col-form-label float-left"><span class="text-danger">*</span>Father Name</label>
                     <input  type="text" name="faname" class="form-control inpreq" id="faname" placeholder="Father Name">
                  </div>
                  <div class="col-lg-6 float-right">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Mother Name</label>
                     <input  type="text" name="moname" class="form-control inpreq" id="moname" placeholder="Mother Name">
                  </div>
               </div>
               <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                     <label class="col-form-label float-left"><span class="text-danger">*</span>Address 1</label>
                     <input  type="text" name="addr" class="form-control inpreq" id="addr" placeholder="Address 1">
                  </div>
                  <div class="col-lg-6 float-right">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Address 2</label>
                     <input  type="text" name="addr2" class="form-control inpreq" id="addr2" placeholder="Address 2">
                  </div>
               </div>
                <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                     <label class="col-form-label float-left"><span class="text-danger">*</span>Designation</label>
                     <select class="form-control" name="desg" id="desg">
                       <option value="">Select Designation</option>
                       <option value="Security Guard">Security Guard</option>
                       <option value="Security Supervisor">Security Supervisor</option>
                       <option value="Head Guard">Head Guard</option>
                       <option value="Security Officier">Security Officier</option>
                       <option value="Gun Man">Gun Man</option>
                       <option value="Lady Guard">Lady Guard</option>
                       <option value="Other">Other</option>
                     </select><br>
                   <div style="display:none;" id='other_deg1'>
                     <input type="text" class="form-control" name="other_deg" placeholder="Other Type Of Designation"/>
                  </div>
                  </div>
                  <div class="col-lg-6 float-right">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Gender</label>
                     <select class="form-control" name="gender">
                       <option value="">Select Gender</option>
                       <option value="Male">Male</option>
                       <option value="Female">Female</option>
                     </select>
                  </div>
               </div>
                <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Mobile Number</label>
                     <input  type="text" name="cont" class="form-control validateNumber inpreq" id="cont" placeholder="Mobile Number" maxlength="10">
                  </div>
                  <div class="col-lg-6 float-right">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Marriage Status</label>
                    <select class="form-control" name="mrg_status">
                       <option value="">Status</option>
                       <option value="Single">Single</option>
                       <option value="Married">Married</option>
                       <option value="Un-married">Un-married</option>
                     </select>
                  </div>
               </div>
               <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                     <label class="col-form-label float-left"><span class="text-danger">*</span>DOB</label>
                     <input  type="date" name="dob" class="form-control inpreq" id="dob" placeholder="Date of Birth">
                  </div>
                  <div class="col-lg-6 float-right">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Date of Joining</label>
                     <input  type="date" name="jdate" class="form-control inpreq" id="jdate" placeholder="Date of Joining">
                  </div>
               </div>
                   <br><b class="float-left text-danger"><h4>KYC Detail's</h4></b><br><hr>
              <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Adhaar Number</label>
                    <input  type="text" name="adhar_num" class="form-control inpreq validateNumber" id="adhar_num" placeholder="Adhaar Card Number">
                  </div>
                  <div class="col-lg-6 float-right">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Pan Card Number(Optional)</label>
                     <input  type="text" name="pan_num" class="form-control " id="pan_num" placeholder="Pan Card Number">
                  </div>
              </div>
              <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Account Holder Name(Optional)</label>
                    <input  type="text" name="ac_name" class="form-control" id="ac_name" placeholder="Account Holder Name">
                  </div>
                  <div class="col-lg-6 float-right">
                   <label class="col-form-label float-left"><span class="text-danger">*</span>Account Number(Optional)</label>
                   <input  type="text" name="ac_no" class="form-control" id="ac_no" placeholder="Pan Card Number">
                  </div>
              </div>
              <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Bank Name(Optional)</label>
                     <select class="form-control" name="bank_name" id="bank_name">
                        <option value="">Select Bank</option>
                        <option value="Indian Overseas Bank">Indian Overseas Bank</option>
                        <option value="Other">Other</option>
                     </select>
                     <br>
                     <input type="text" class="form-control otherval" name="other_bnk" id="other_bnk" style="display: none;">
                  </div>
                  <div class="col-lg-6 float-right">
                   <label class="col-form-label float-left"><span class="text-danger">*</span>IFSC Code(Optional)</label>
                   <input  type="text" name="ifsc" class="form-control" id="ifsc" placeholder="IFSC Code">
                  </div>
              </div>
              <br><b class="float-left text-danger"><h4>Professional Details</h4></b><br><hr>
              <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>UAN No.(Optional)</label>
                    <input  type="text" name="lname" class="form-control" id="lname" placeholder="UAN No">
                  </div>
                  <div class="col-lg-6 float-right">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>ESIC No.(Optional)</label>
                     <input  type="text" name="esic_num" class="form-control" id="esic_num" placeholder="ESIC No.">
                  </div>
              </div>
              <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Medical Certificate(Optional)</label>
                     <select class="form-control" name="med_cer" id="med_cer">
                        <option value="">Select</option>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                     </select>
                     <br>
                  <div style="display:none;" id='Medimage'>
                     <input type='file' class='form-control' name='medcer_pic' value size='20' />
                  </div>
                  </div>
                  <div class="col-lg-6 float-right">
                   <label class="col-form-label float-left"><span class="text-danger">*</span>Police Verification(Optional)</label>
                   <select class="form-control" name="polic_ver" id="polic_ver">
                        <option value="">Select</option>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                     </select>
                     <br>
                  <div style="display:none;" id='Policeimage'>
                     <input type='file' class='form-control' name='policcer_pic' value size='20' />
                  </div>
                  </div>
              </div>
              <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Do You have Any Pending Case?(Optional)</label>
                     <select class="form-control" name="polic_case">
                        <option value="">Select </option>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                     </select>
                  </div>
                  <div class="col-lg-6 float-right">
                   <label class="col-form-label float-left"><span class="text-danger">*</span>Are you Indian?(Optional)</label>
                   <select class="form-control" name="nationality">
                        <option value="">Select </option>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                     </select>
                  </div>
              </div>
               <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Location</label>
                     <select class="form-control" name="loc_type">
                        <option value="">Select Location</option>
                        <option value="Central">Central</option>
                        <option value="State">State</option>
                     </select>
                  </div>
                  <div class="col-lg-6 float-right">
                   <label class="col-form-label float-left"><span class="text-danger">*</span>City</label>
                   <select class="form-control" name="city">
                        <option value="">Select City</option>
                        <?php 
                          foreach($all_city_type as $city_type)
                          {
                            $selected = ($city_type['id'] == $this->input->post('city')) ? ' selected="selected"' : "";
                            echo '<option value="'.$city_type['id'].'" '.$selected.'>'.$city_type['city'].'</option>';
                           } 
                          ?>
                     </select>
                  </div>
              </div>
               <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Company Name</label>
                     <select class="form-control" name="co_name">
                        <option value="">Select City</option>
                        <?php 
                          foreach($all_cmp_type as $cmpy)
                          {
                            $selected = ($cmpy['id'] == $this->input->post('cl_coname')) ? ' selected="selected"' : "";
                            echo '<option value="'.$cmpy['id'].'" '.$selected.'>'.$cmpy['cl_coname'].'</option>';
                           } 
                          ?>
                     </select>
                  </div>
                  <div class="col-lg-6 float-right">
                   <label class="col-form-label float-left"><span class="text-danger">*</span>Zone</label>
                   <select class="form-control" name="zone">
                        <option value="">Select City</option>
                        <?php 
                          foreach($all_zone_type as $Zone)
                          {
                            $selected = ($Zone['id'] == $this->input->post('zone')) ? ' selected="selected"' : "";
                            echo '<option value="'.$Zone['id'].'" '.$selected.'>'.$Zone['zone'].'</option>';
                           } 
                          ?>
                     </select>
                  </div>
              </div>
                <br><b class="float-left text-danger"><h4>Family Detail's</h4></b><br><hr>
                  <div class="row mt-3">
                  <label class="col-form-label float-left f"><span class="text-danger">*</span>Your Family Member  :</label> 
                  <div class="col-lg-12">
                  <table class="table table-hover table-active" id="dynamic_field">  
                    <thead class="f1">
                    <tr>
                       <th scope="col" class="f2">Member Name</th>
                       <th scope="col" class="f2">Member Relation</th>
                       <th scope="col" class="f2">Contact</th>
                    </tr>
                  </thead>
                  <tbody class="thead-light">
                    <tr class="alltrs">
                      <td>
                        <input type="text" class="form-control" name="mem_nm[][mem_nm]" placeholder="Member Name"></td>
                       <td>
                        <input type="text" class="form-control" name="mem_rel[][mem_rel]" placeholder="Member Relation"></td>
                       <td>
                        <input type="text" class="form-control validateNumber" name="mem_con[][mem_con]" placeholder="Contact Number" maxlength="10"></td>
                       <td><button type="button" name="add" id="add" class="btn btn-success">Add</button></td> 
                    </tr>
                  </tbody>
                  </table>
                  </div>
                </div>
                <br><b class="float-left text-danger"><h4>Attached Document Details (Max 5MB)</h4></b><br><hr>
              <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Adhar card Pic</label>
                    <input  type="file" name="adhar" class="form-control" id="adhar">
                  </div>
                  <div class="col-lg-6 float-right">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Pan card Pic(Optional)</label>
                     <input  type="file" name="pan_up" class="form-control" id="pan_up">
                  </div>
              </div>
               <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>Passbook Pic(Optional)</label>
                    <input  type="file" name="passbook" class="form-control" id="passbook">
                  </div>
                  <div class="col-lg-6 float-right">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>10th Marksheet</label>
                     <input  type="file" name="ten_mask" class="form-control" id="ten_mask">
                  </div>
              </div>
               <div class="row mt-3">
                  <div class="col-lg-6 float-left">
                    <label class="col-form-label float-left"><span class="text-danger">*</span>12th Marksheet(Optional)</label>
                    <input  type="file" name="twl_mark" class="form-control" id="twl_mark">
                  </div>
                  
              </div>
              <div class="form-group row mt-4">
                <div class="col-md-6">
                    <input type="submit" name="upload" class="btn btn-success save_vend_data" value="Save">
                </div>
                <div class="col-md-6">
                  <a class="btn btn-danger" href="<?php echo base_url('AdminDash/All_Employee');?>">Cancel</a>
                </div>
              </div>
        </div>
     </div></center>    
    </section>
</div>
<?php echo form_close(); ?>
 <script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $('#med_cer').on('change', function() {
      if ( this.value == 'Yes')
      {
        $("#Medimage").show();
      }
      else
      {
        $("#Medimage").hide();
      }
    });
});

$(document).ready(function(){
    $('#polic_ver').on('change', function() {
      if ( this.value == 'Yes')
      {
        $("#Policeimage").show();
      }
      else
      {
        $("#Policeimage").hide();
      }
    });
});

$(document).ready(function(){
    $('#bank_name').on('change', function() {
      if ( this.value == 'Other')
      {
        $(".otherval").show();
      }
      else
      {
        $(".otherval").hide();
      }
    });
});

$(document).ready(function(){
    $('#desg').on('change', function() {
      if ( this.value == 'Other')
      {
        $("#other_deg1").show();
      }
      else
      {
        $("#other_deg1").hide();
      }
    });
});
</script>
<script type="text/javascript">
    $(document).ready(function(){      
      var i=1;  


      $('#add').click(function(){  
           i++;
           var count = $('.alltrs').length;
           count++; 
           $('#dynamic_field').append('<tr id="row'+i+'" class="dynamic-added alltrs"><td><input type="text" class="form-control " name = "mem_nm[][mem_nm]" placeholder="Member Name" maxlength="10"/></td><td><input type="text" class="form-control" name = "mem_rel[][mem_rel]" placeholder="Member Relation"/></td><td><input type="text" class="form-control " name = "mem_con[][mem_con]" placeholder="Member Contact" /></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></td></tr>');  
      });
    
      $(document).on('click', '.btn_remove', function(){  
           var button_id = $(this).attr("id");   
           $('#row'+button_id+'').remove();  
      });  


    });  
</script>