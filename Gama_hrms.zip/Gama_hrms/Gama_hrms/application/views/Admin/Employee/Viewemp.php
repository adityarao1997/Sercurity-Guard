<?php 

    $this->load->view('Layout/include/header');
    $this->load->view('Layout/include/sidebar');
    $this->load->view('Admin/Employee/Viewemp_Main.php');
    $this->load->view('Layout/include/footer');

?>
<script>
   
   $(document).ready(function(){
     
     //load_data();
     function load_data(query)
      {
        $.ajax({
           url:"Fetch_SetupData/",
           method:"POST",
           data:{query:query},
           success:function(data) {
              $('#result').html(data);
           }
        });
      }

      $('#search_text').keyup(function(){
         
           var search = $(this).val();
           console.log(search);
           if (search != '')
           {
              load_data(search);
           }else{
             load_data();
           }
      });
   });
 </script>