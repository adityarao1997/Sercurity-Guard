<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 
<body class="">


 
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark"><strong>Venue</strong> List</h1>
          </div><!-- /.col -->
          <div class="col-sm-12 mt-3" style="background:#EAE7E7; height: 6vh;">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo base_url('AdminDash');?>">Home</a><i
              class="fas fa-angle-double-right mx-2 white-text" aria-hidden="true"></i></li>
              <li class="active"><strong>View All Venue</strong></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=" connectedSortable ">
      <!-- <div class="Container ">
        
         <?php echo form_open("AdminDash/" ,['class'=>'navbar-form navbar-right ','role'=>'search']);?>
         <div class="row">
            <div class="form-group col-md-5 ">
                <input type="text" name="search_text" id="search_text" placeholder="Search by venue Name " class="form-control "> -->
                <!-- <button type="button" class="btn btn-danger btn-sm close_search col-lg-1" style="display: none;">X</button> 
             </div>
           <div class="form-group col-md-2">
              <?php echo form_submit(['value' => 'search','class'=>'btn btn-primary']);?>
              
          </div>
         </div>
     </div> --> 
    <!-- <div id="result"></div> -->
		
			  	<div style="width: 98%;padding: 20px;">
        <table  id="col_table" class="table table-striped table-bordered" style="width:100%">
				      	<thead style="">
				            <tr>
				              <th scope="col">S.No.</th>
				              <th scope="col">Image</th>
				              <th scope="col">Vendor Name</th>
				              <th scope="col">Venue Name</th>
				              <th scope="col">Contact</th>
				              <th scope="col">Cost</th>
				              <th scope="col">Status</th>
				              <th scope="col">Form Status</th>
				              <th scope="col">Action</th>
				            </tr>
				     	</thead>
				        <tbody class="thead-light">
				         
			              <?php
                               $i = 0;
                            foreach($venue as $ven){
                            $i++;
                            $img = explode('_-_',$ven['venue_image']);
                            $vend_id1 = $ven['vendor_id'];
                            $data1 = $this->SAdmin_model->comapare_venName($vend_id1);
                            $vend_id = $ven['type_name'];
                            $data2 = $this->SAdmin_model->comapare($vend_id);
                            
                          ?>
				            <tr>
				             <td><?php echo $i; ?></td>
				            <td><img src="../../../Vendor/upload/Venue/<?php echo $img[0];?>" style="height: 50px; width: 50px; border-radius: 100px;  "/></td>
				            <td class="text-danger"><?php echo $data1[0]['company_name'] ?></td>
				            <td><?php echo $ven['venue_name']; ?></td>
				            <!--<td class="text-danger"><?php echo $ven['type_name']; ?></td>-->
				            <!--  <td class="text-danger"><?php echo $data2[0]['vendor_type'];?></td>-->
				            <td><?php echo $ven['contact']; ?></td>
				            <td><b> &#8377; </b><?php echo $ven['charge']; ?></td>
			              <?php if($ven['status'] == '0'):?>
                            <td style="color: red;"><b><?php echo "pending"; ?></b></td>
                           <?php else: ?>
                           <?php if($ven['status'] == '1'): ?>
                             <td style="color: red;"><b><?php echo "Hold"; ?></b></td>
                           
                            <?php else: ?>
                           <?php if($ven['status'] == '2'): ?>
                             <td style="color: red;"><b><?php echo "Re-Send"; ?></b></td>
                            <?php else: ?>  
                           <?php if($ven['status'] == '3'): ?>
                             <td style="color: green;"><b><?php echo "approved"; ?></b></td>
                           <?php endif;?>
                           <?php endif;?>
                           <?php endif;?>
                           <?php endif;?>   
                          <?php if($ven['form_status'] == '0'):?>
                            <td style="color: green;"><b><?php echo "Active"; ?></b></td>
                           <?php else: ?>
                           <?php if($ven['form_status'] == '1'): ?>
                             <td style="color: black;"><b><?php echo "Hold"; ?></b></td>
                            <?php endif;?>
                           <?php endif;?>
				               <td>
				               
				                   <a class="btn btn-success btn-sm" href="<?php echo site_url('AdminDash/Add_Venue_Edit/'.$ven['id']);?>" style="color: white;">Edit</a> 
				                   <a class="btn btn-success btn-sm" href="<?php echo site_url('AdminDash/VenueView_data/'.$ven['id']);?>" style="color: white;">View</a> 
				                
				                 <button type="button" class="btn btn-danger btn-sm dlt_click" id="<?php echo $ven['id']; ?>" data-name="<?php echo $ven['venue_name']; ?>" data-url="<?php echo site_url('AdminDash/Add_venue_Dlt/'.$ven['id']);?>">Delete</button>
				              </td>
				              </tr>
				             <?php } ?>    
				        </tbody>
			   		</table>
				</div>
			</center>   
        </div>
    </section>
        <div class="modal fade model-sm" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Are you Sure to delete this?</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
             
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-danger">
               <a href="" style="color: white;" class="delete_id">Delete</a> 
              </button>
            </div>
          </div>
         </div>
       </div>          
</div>