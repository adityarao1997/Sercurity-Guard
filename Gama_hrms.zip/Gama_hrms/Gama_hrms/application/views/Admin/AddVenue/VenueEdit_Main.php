<?php defined('BASEPATH') OR exit('No direct script access allowed');?>  
<?php echo form_open_multipart('AdminDash/Add_Venue_Edit/'.$venue['id'],array("class"=>"form-horizontal"));
$vendor_typeid = $this->session->userdata('vendor_typeid');
$vendor_ids = explode(',', $vendor_typeid);
$img = explode('_-_',$venue['venue_image']);
 ?>
 <head>
    <style>
      .prev,
    .next {
      cursor: pointer;
      position: absolute;
      top: 50%;
      width: auto;
      padding: 16px;
      margin-top: -50px;
      color: black;
      font-weight: bold;
      font-size: 20px;
      transition: 0.6s ease;
      border-radius: 0 3px 3px 0;
      user-select: none;
      -webkit-user-select: none;
    }
    /* Position the "next button" to the right */
    .next {
      right: 300px;
      border-radius: 3px 0 0 3px;
    }
    .prev{
      right: 1000px;
    }


    .close:hover,
    .close:focus {
      color: red;
      text-decoration: none;
      cursor: pointer;
    }

    .mySlides {
      display: none;
    }

    .cursor {
      cursor: pointer;
    }

    /* On hover, add a black background color with a little bit see-through */
    .prev:hover,
    .next:hover {
      background-color: rgba(0, 0, 0, 0.8);
    }

    /* The Modal (background) */
    .modal {
      display: none;
      position: fixed;
      z-index: 1;
      padding-top: 100px;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: black;
    }

    .modal-content {
      position: relative;
      background-color: #fefefe;
      margin: auto;
      padding: 0;
      width: 90%;
    }

    /* The Close Button */
    .close {
      color: green;
      position: absolute;
      top: 10px;
      right: 250px;
      font-size: 35px;
      font-weight: bold;
    }
    </style>
</head>
 <div class="content-wrapper">
     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark"><strong>Venue </strong>Edit</h1>
          </div><!-- /.col -->
         <div class="col-sm-12 mt-3" style="background:#EAE7E7; height: 6vh;">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo base_url('AdminDash/View_add_Venue');?>">Venue</a><i
              class="fas fa-angle-double-right mx-2 white-text" aria-hidden="true"></i></li>

              <li class="active"><strong>Edit Venue</strong></li>
            </ol>
          </div><!-- /.col -->
        </div>
      </div>
    </div>
   <section class="col-lg-12 connectedSortable pb-5">
     <center>

        <div class="col-lg-10">
           <div class="card-body login-card-body" style="border: 1px solid green;"> <i class="nav-icon fab fa-audible"><h5 class="text-dark">Edit <b>Venue Form</b></h5></i> 
          <a href="<?php echo base_url('AdminDash/View_add_Venue');?>"><span class=" float-right nav-icon text-danger aria-hidden" ><b>X<b></span></a><br><br>
              <div class="row">
                <div class="row">
                <label class="col-form-label float-left"><span class="text-danger">*</span>Venue Images</label>
                  <div class="col-lg-12 mt-2">
                    <?php
                    $i=0;
                    $j=1;
                    foreach ($img as $key) {
                      ?>
                      <div class="col-sm-3 float-left">
                        <a target="_blank"><img target="_blank" src="../../../Vendor/upload/Venue/<?php echo $key;?>" class="img-fluid" onclick="openModal();currentSlide(<?=$j ?>)"/></a>
                      </div>
                      <?php
                      $i++;
                      $j++;
                    }
                    ?>
                </div>
              </div>
                </div>
                <div id="myModal" class="modal">
          <div class="modal-content">
            <?php
                  $i=0;
                  $j=1;
                  foreach ($img as $key) {
                    ?>
                  <div class="mySlides">
                    <span class="close cursor" onclick="closeModal()">&times;</span>
                    <div class="numbertext"><?=$j ?> / 4</div>
                      <a target="_blank"><img  src="../../../Vendor/upload/Venue/<?php echo $key;?>" class="img-fluid" style="width: 50%; height:50%;"/></a>
                    </div>
                    <?php
                    $i++;
                    $j++;
            }
            ?>
            </div>
            <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
            <a class="next" onclick="plusSlides(1)">&#10095;</a>
        </div>

            <div class="row mt-3">   
              <div class="col-lg-6">
                <label class="col-form-label float-left"><span class="text-danger">*</span>Venue Name</label>
                 <input  type="text" name="venue_name" value="<?php echo ($this->input->post('venue_name') ? $this->input->post('venue_name') : $venue['venue_name']); ?>" class="form-control" id="venue_name" readonly>
               </div>
               <div class="col-lg-6">
                <label class="col-form-label float-left"><span class="text-danger">*</span>Contact</label>
                 <input  type="text" name="contact" value="<?php echo ($this->input->post('contact') ? $this->input->post('contact') : $venue['contact']); ?>" class="form-control" id="contact" readonly>
               </div>
            </div>

             <div class="row mt-3">   
              <div class="col-lg-6">
                <label class="col-form-label float-left"><span class="text-danger">*</span>Venue Type</label>
                 <input  type="text" name="venue_name" value="<?php echo ($this->input->post('type_name') ? $this->input->post('type_name') : $venue['type_name']); ?>" class="form-control" id="venue_name" readonly>
               </div>
              
            </div>
            
            <div class="row">
                <label class="col-form-label float-left"><span class="text-danger">*</span>Prefered For(Venue Sutaible For)</label>
            </div>
             <div class="mt-3 row shadow preferd_check" >
                 <?php 
                 $venue_preferd = explode('_-_',$venue['prefered_name']);
                 $i=0;
                 foreach ($venue_preferd as $key)
                 {
                   $data1 = $this->SAdmin_model->comapare_venue_preferd_for($key);
                 ?>
                  <br/>
                 
                  <div class="col-sm-4 mt-2 mb-2">
                      <input type="text" class="form-control" value="<?=$data1[0]['prefered_name'];?>" readonly/>
                  </div>
                  <?php
                     $i++;
                   }
                  ?>
            </div>
            
            <div class="row mt-3">   
              <div class="col-lg-6">
                <label class="col-form-label float-left"><span class="text-danger">*</span>Opening Time</label>
                 <input  type="time" name="venue_name" value="<?php echo ($this->input->post('time_in') ? $this->input->post('time_in') : $venue['time_in']); ?>" class="form-control" id="venue_name" readonly>
               </div>
               <div class="col-lg-6">
                <label class="col-form-label float-left"><span class="text-danger">*</span>Closeing Time</label>
                 <input  type="time" name="contact" value="<?php echo ($this->input->post('time_out') ? $this->input->post('time_out') : $venue['time_out']); ?>" class="form-control" id="contact" readonly>
               </div>
            </div>

            <div class="row mt-3 col-sm-12">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Location</label>
              <input  type="text" name="venue_location" value="<?php echo ($this->input->post('venue_location') ? $this->input->post('venue_location') : $venue['venue_location']); ?>" class="form-control" id="venue_address" readonly>
            </div>
            <div class="row mt-3 col-sm-12">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Address</label>
              <input  type="text" name="venue_address" value="<?php echo ($this->input->post('venue_address') ? $this->input->post('venue_address') : $venue['venue_address']); ?>" class="form-control" id="venue_address" readonly>
            </div>

            <div class="row mt-3">   
              <div class="col-lg-4">
                <label class="col-form-label float-left"><span class="text-danger">*</span>Max Capacity</label>
                 <input  type="text" name="max_capacity" value="<?php echo ($this->input->post('max_capacity') ? $this->input->post('max_capacity') : $venue['max_capacity']); ?>" class="form-control" id="max_capacity" readonly>
               </div>
               <div class="col-lg-4">
                <label class="col-form-label float-left"><span class="text-danger">*</span>Flexibility</label>
                 <input  type="text" name="max_capacity" value="<?php echo ($this->input->post('max_capacity') ? $this->input->post('max_capacity') : $venue['max_capacity']); ?>" class="form-control" id="max_capacity" readonly>
               </div>
               <div class="col-lg-4">
                <label class="col-form-label float-left"><span class="text-danger">*</span>Charges</label>
                 <input  type="text" name="charge" value="<?php echo ($this->input->post('charge') ? $this->input->post('charge') : $venue['charge']); ?>" class="form-control" id="charge" readonly>
               </div>
            </div>

             <div class="row mt-3">
               <div class="col-lg-6">
                 <label class="col-form-label float-left"><span class="text-danger">*</span>Veg Plate Price</label>
                 <input  type="text" name="Vegplt" value="<?php echo ($this->input->post('Vegplt') ? $this->input->post('Vegplt') : $venue['Vegplt']); ?>" class="form-control" id="Vegplt" readonly>
               </div>
               <div class="col-lg-6">
                <label class="col-form-label float-left"><span class="text-danger">*</span>NonVeg Plate Price</label>
                 <input  type="text" name="nonplt" value="<?php echo ($this->input->post('nonplt') ? $this->input->post('nonplt') : $venue['nonplt']); ?>" class="form-control" id="nonplt" readonly>
               </div>
             </div>

             <div class="row mt-3">
               <div class="col-lg-4">
                 <label class="col-form-label float-left"><span class="text-danger">*</span>Status</label>
                 <select class="form-control" name="status">
                   <option >Status</option>
                     <option value="0" <?php if($venue['status'] == '0'){ echo 'selected'; } ?>>Pendding</option>
                      <option value="1" <?php if($venue['status'] == '1'){ echo 'selected'; } ?>>Hold</option>
                      <option value="2" <?php if($venue['status'] == '2'){ echo 'selected'; } ?>>Re-Send</option>
                      <option value="3" <?php if($venue['status'] == '3'){ echo 'selected'; } ?>>Approved</option>
                 </select>
               </div>
               <div class="col-lg-4">
                <label class="col-form-label float-left"><span class="text-danger">*</span>Date</label>
                <input  type="text" name="date" value="<?php echo ($this->input->post('date') ? $this->input->post('date') : $venue['date']); ?>" class="form-control" id="packdate" readonly/>
               </div>
               <div class="col-lg-4">
                   <label class="col-form-label float-left"><span class="text-danger">*</span>Form-Status</label>
                    <?php if($venue['form_status'] == '0'):?>
                     <input  type="text" value="Active" class="form-control" id="packdate" readonly/>
                   <?php else: ?>
                   <?php if($venue['form_status'] == '1'): ?>
                    <input  type="text" value="Hold" class="form-control" id="packdate" readonly/>
                   <?php endif;?>
                   <?php endif;?>
               </div>
             </div>
             <div class="row mt-3 col-sm-12">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Description</label>
              <textarea  type="text" name="des" class="form-control" id="des" style="height: 100px;"><?=$venue['des'];?></textarea>
            </div>
             
              <div class="form-group float-right row mt-3">
                <div class=" col-md-7">
                    <input type="submit" name="upload" class="btn btn-success">
                </div>
                <div class="col-md-4">
	              <a class="btn btn-danger" href="<?php echo base_url('AdminDash/View_add_Venue');?>">Cancle</a>
	            </div>
              </div>
            </div>
            </div></center>    
    </section>
   
  </div>
<?php echo form_close(); ?>   
 <script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script>
    
    $(document).on('keyup', '.validateNumber', function() { 
        if (/\D/g.test(this.value))
        {
            // Filter non-digits from input value.
            this.value = this.value.replace(/\D/g, '');
        }
    });
</script>

<script>
function openModal() {
  document.getElementById("myModal").style.display = "block";
}

function closeModal() {
  document.getElementById("myModal").style.display = "none";
}

var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  var captionText = document.getElementById("caption");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
  captionText.innerHTML = dots[slideIndex-1].alt;
}
</script>