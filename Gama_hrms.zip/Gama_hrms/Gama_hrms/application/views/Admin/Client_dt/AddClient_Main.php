<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 
<?php echo form_open_multipart('AdminDash/Create_Client',array("class"=>"form-horizontal")); ?>
 <?php if($error = $this->session->flashdata('login_response')):?>
      <div class="row">
        <div class="col-lg-12">
            <div class="alert alert-dismissible alert-danger">
               <?php echo $error; ?>
            </div>
       </div>
      </div>
    <?php endif; ?> 
 <div class="content-wrapper">
     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Client Add</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('AdminDash');?>">Home</a></li>
              <li class="breadcrumb-item active">Client Add</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  
    <section class="col-lg-12 connectedSortable">
     <center><div class="col-lg-10">
               <span class="error_form_msg"></span>
         <div class="card-body login-card-body">
          <i class="nav-icon fab fa-audible"><h5 class="text-dark">Add <b>New Client</b></h5>
          </i><a class="float-right" href="<?php echo base_url('AdminDash/All_City');?>"><i class=" text-danger"><b>X<b></i></a> <br><br>
         
          <div class="row mt-4">
            <div class="col-lg-6 float-left">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Client Name</label>
                <input  type="text" name="cl_name" class="form-control inpreq" id="cl_name" placeholder="Client Name">
            </div>
             <div class="col-lg-6 float-right">
               <label class="col-form-label float-left"><span class="text-danger">*</span>Company Name</label>
                <input  type="text" name="cl_coname" class="form-control inpreq" id="cl_coname" placeholder="Company Name">
            </div>
          </div>
          <div class="row mt-2">
            <div class="col-lg-6 float-left">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Contact Number</label>
                <input  type="phone" name="cl_cont" class="form-control inpreq validateNumber" id="cl_cont" placeholder="Contact Number" maxlength="10">
            </div>
             <div class="col-lg-6 float-right">
               <label class="col-form-label float-left"><span class="text-danger">*</span>City Name</label>
               <select name="cl_city"  class="form-control">
                 <option value="">Select City</option>
                  <?php 
                     foreach($all_city_type as $city_type)
                          {
                             $selected = ($city_type['id'] == $this->input->post('city')) ? ' selected="selected"' : "";

                        echo '<option value="'.$city_type['id'].'" '.$selected.'>'.$city_type['city'].'</option>';
                           } 
                  ?>
                </select>
            </div>
          </div>
           <div class="row mt-2">
            <div class="col-lg-12 float-left">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Address</label>
                <input type="text" name="cl_address" id="cl_address" class="form-control inpreq" placeholder="Address">
            </div>
          </div>
           <div class="row mt-2">
            <div class="col-lg-6 float-left">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Strength</label>
                <input  type="text" name="cl_noemp" class="form-control inpreq" id="cl_noemp" placeholder="Strength(Number of Member)">
            </div>
             <div class="col-lg-6 float-right">
               <label class="col-form-label float-left"><span class="text-danger">*</span>GSTIN(Optional)</label>
                <input  type="text" name="cl_gst" class="form-control " id="cl_gst" placeholder="GSTIN(Optional)">
            </div>
          </div>
           <div class="row mt-2">
            <div class="col-lg-6 float-left">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Agreement No.(Optional)</label>
                <input  type="text" name="cl_agno" class="form-control " id="cl_agno" placeholder="Agreement No.(Optional)">
            </div>
             <div class="col-lg-6 float-right">
               <label class="col-form-label float-left"><span class="text-danger">*</span>Labour Licence No(Optional)</label>
                <input  type="text" name="laber_no" class="form-control " id="laber_no" placeholder="Laber Licence No(Optional)">
            </div>
          </div>
          <div class="row mt-2">
            <div class="col-lg-6 float-left">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Agreement Start Date(Optional)</label>
                <input  type="date" name="cl_agri_stdate" class="form-control" id="cl_agri_stdate" >
            </div>
             <div class="col-lg-6 float-right">
               <label class="col-form-label float-left"><span class="text-danger">*</span>Agreement End Date(Optional)</label>
                <input  type="date" name="cl_agri_enddate" class="form-control" id="cl_agri_enddate" >
            </div>
          </div>

          <div class="row mt-2">
            <div class="col-lg-6 float-left">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Work Order Number(Optional)</label>
                <input  type="text" name="work_order_no" class="form-control" id="work_order_no" placeholder="Work Order Number" >
            </div>
             <div class="col-lg-6 float-right">
               <label class="col-form-label float-left"><span class="text-danger">*</span>Work Order Pic(Optional)</label>
                <input  type="file" name="work_order_pic" class="form-control" id="work_order_pic" >
            </div>
          </div>

          <div class="row mt-2">
            <div class="col-lg-6 float-left">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Company Logo</label>
                <input  type="file" name="client_logo" class="form-control" id="client_logo" >
            </div>
             <div class="col-lg-6 float-right">
               <label class="col-form-label float-left"><span class="text-danger">*</span>Labour Licence Pic(Optional)</label>
                <input  type="file" name="laber_pic" class="form-control" id="laber_pic" >
            </div>
          </div>
          
           <div class="row mt-2">
            <div class="col-lg-6 float-left">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Agreement Image(Optional)</label>
                <input  type="file" name="order_pic" class="form-control" id="order_pic" >
            </div>
             <div class="col-lg-6 float-left">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Rate Breakup Image(Optional)</label>
                <input  type="file" name="rate_breakup_img" class="form-control" id="rate_breakup_img" >
            </div>
             
          </div>

          <div class="form-group row mt-4">
            <div class="col-md-6">
                <input type="submit" name="upload" class="btn btn-success save_vend_data" value="Save">
            </div>
            <div class="col-md-6">
              <a class="btn btn-danger" href="<?php echo base_url('AdminDash/All_City');?>">Cancel</a>
            </div>
           </div>
          </div>
        </div></center>    
    </section>
  </div>
<?php echo form_close(); ?>