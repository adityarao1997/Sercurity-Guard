<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 

<?php echo form_open_multipart('AdminDash/Client_Edit/'.$city_ad['id'],array("class"=>"form-horizontal")); ?>
 <?php if($error = $this->session->flashdata('login_response')):?>
      <div class="row">
        <div class="col-lg-12">
            <div class="alert alert-dismissible alert-danger">
               <?php echo $error; ?>
            </div>
       </div>
      </div>
    <?php endif; ?> 


 <div class="content-wrapper">
     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Client </h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('AdminDash');?>">Home</a></li>
              <li class="breadcrumb-item active">Client Edit</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  
    <section class="col-lg-12 connectedSortable">
     <center><div class="col-lg-10">
         <div class="card-body login-card-body" style="border: 1px solid green;">
          <i class="nav-icon fab fa-audible"><h5 class="text-dark">Edit <b>Client</b></h5></i> <a class="float-right" href="<?php echo base_url('AdminDash/All_Client');?>"><i class="text-danger"><b>X<b></i></a><br><br>
          
              <div class="row mt-4">
            <div class="col-lg-6 float-left">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Client Name</label>
                <input  type="text" name="cl_name" class="form-control" value="<?php echo ($this->input->post('cl_name') ? $this->input->post('cl_name') : $city_ad['cl_name']); ?>" id="cl_name" placeholder="Client Name" readonly>
            </div>
             <div class="col-lg-6 float-right">
               <label class="col-form-label float-left"><span class="text-danger">*</span>Company Name</label>
                <input  type="text" name="cl_coname" class="form-control" value="<?php echo ($this->input->post('cl_coname') ? $this->input->post('cl_coname') : $city_ad['cl_coname']); ?>" id="cl_coname" placeholder="Company Name" readonly>
            </div>
          </div>
          <div class="row mt-2">
            <div class="col-lg-6 float-left">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Contact Number</label>
                <input  type="phone" name="cl_cont" class="form-control" value="<?php echo ($this->input->post('cl_cont') ? $this->input->post('cl_cont') : $city_ad['cl_cont']); ?>" id="cl_cont" placeholder="Contact Number" readonly>
            </div>
             <div class="col-lg-6 float-right">
               <label class="col-form-label float-left"><span class="text-danger">*</span>City Name</label>
               <select name="cl_city"  class="form-control" disabled> 
                 <option value="">Select City</option>
                  <?php 
                     foreach($all_city_type as $city_type)
                          {
                              $selected = ($city_type['id'] == $city_ad['cl_city']) ? ' selected="selected"' : "";


                        echo '<option value="'.$city_type['id'].'" '.$selected.'>'.$city_type['city'].'</option>';
                           } 
                  ?>
                </select>
            </div>
          </div>
          <div class="row mt-2">
            <div class="col-lg-12 float-left">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Address</label>
                <input type="text" name="cl_address" id="cl_address"  value="<?php echo ($this->input->post('cl_address') ? $this->input->post('cl_address') : $city_ad['cl_address']); ?>" class="form-control inpreq" placeholder="Address" readonly>
            </div>
          </div>
           <div class="row mt-2">
            <div class="col-lg-6 float-left">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Strength</label>
                <input  type="text" name="cl_noemp" class="form-control" value="<?php echo ($this->input->post('cl_noemp') ? $this->input->post('cl_noemp') : $city_ad['cl_noemp']); ?>" id="cl_noemp" placeholder="Strength(Number of Member)" readonly>
            </div>
             <div class="col-lg-6 float-right">
               <label class="col-form-label float-left"><span class="text-danger">*</span>GSTIN(Optional)</label>
                <input  type="text" name="cl_gst" class="form-control" value="<?php echo ($this->input->post('cl_gst') ? $this->input->post('cl_gst') : $city_ad['cl_gst']); ?>" id="cl_gst" placeholder="GSTIN(Optional)" readonly>
            </div>
          </div>
           <div class="row mt-2">
            <div class="col-lg-6 float-left">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Agreement No.(Optional)</label>
                <input  type="text" name="cl_agno" class="form-control" value="<?php echo ($this->input->post('cl_agno') ? $this->input->post('cl_agno') : $city_ad['cl_agno']); ?>" id="cl_agno" placeholder="Agreement No.(Optional)" readonly>
            </div>
             <div class="col-lg-6 float-right">
               <label class="col-form-label float-left"><span class="text-danger">*</span>Labour Licence No(Optional)</label>
                <input  type="text" name="laber_no" class="form-control" value="<?php echo ($this->input->post('laber_no') ? $this->input->post('laber_no') : $city_ad['laber_no']); ?>" id="laber_no" placeholder="Laber Licence No(Optional)" readonly>
            </div>
          </div>
          <div class="row mt-2">
            <div class="col-lg-6 float-left">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Agreement Start Date</label>
                <input  type="date" name="cl_agri_stdate" class="form-control" value="<?php echo ($this->input->post('cl_agri_stdate') ? $this->input->post('cl_agri_stdate') : $city_ad['cl_agri_stdate']); ?>" id="cl_agri_stdate" readonly>
            </div>
             <div class="col-lg-6 float-right">
               <label class="col-form-label float-left"><span class="text-danger">*</span>Agreement End Date</label>
                <input  type="date" name="cl_agri_enddate" class="form-control" value="<?php echo ($this->input->post('cl_agri_enddate') ? $this->input->post('cl_agri_enddate') : $city_ad['cl_agri_enddate']); ?>" id="cl_agri_enddate" readonly>
            </div>
          </div>
           <div class="row mt-2">
            <div class="col-lg-6 mt-4 float-left">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Work Order Number(Optional)</label>
                <input  type="text" name="work_order_no" value="<?php echo ($this->input->post('work_order_no') ? $this->input->post('work_order_no') : $city_ad['work_order_no']); ?>" class="form-control" id="work_order_no" placeholder="Work Order Number" readonly>
            </div>
             <div class="col-lg-6 float-right">
               <label class="col-form-label float-left"><span class="text-danger">*</span>Work Order Pic(Optional)</label>
               <?php if($city_ad['work_order_pic']){?>
                 <img src="../../../Gama_hrms/upload/Client/<?php echo $city_ad['work_order_pic'];?>" style="height: 70px; width: 70px; "/>
                  <?php } else{ ?>
                     <img class="img" src="<?php echo base_url();?>resource/images/image.jpeg" alt="User Avatar" style="height: 70px; width: 70px;">
                   <?php }?>
            </div>
          </div>


          <div class="row mt-4">
            <div class="col-lg-6 float-left">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Company Logo</label>
                <?php if($city_ad['client_logo']){?>
                 <img src="../../../Gama_hrms/upload/Client/<?php echo $city_ad['client_logo'];?>" style="height: 70px; width: 70px;"/>
                  <?php } else{ ?>
                     <img class="img" src="<?php echo base_url();?>resource/images/image.jpeg" alt="User Avatar" style="height: 70px; width: 70px;">
                   <?php }?>
                  
            </div>
             <div class="col-lg-6 float-right">
               <label class="col-form-label float-left"><span class="text-danger">*</span>Labour Licence Pic</label>
               <?php if($city_ad['laber_pic']){?>
                <img src="../../../Gama_hrms/upload/Client/<?php echo $city_ad['laber_pic'];?>" style="height: 70px; width: 70px; "/>
                  <?php } else{ ?>
                     <img class="img" src="<?php echo base_url();?>resource/images/image.jpeg" alt="User Avatar" style="height: 70px; width: 70px;">
                   <?php }?>
                
            </div>
          </div> 
          
           <div class="row mt-4">
             <div class="col-lg-6 float-right">
               <label class="col-form-label float-left"><span class="text-danger">*</span>Agreement Licence Pic</label>
                <?php if($city_ad['order_pic']){?>
                 <img src="../../../Gama_hrms/upload/Client/<?php echo $city_ad['order_pic'];?>" style="height: 70px; width: 70px; "/>
                  <?php } else{ ?>
                     <img class="img" src="<?php echo base_url();?>resource/images/image.jpeg" alt="User Avatar" style="height: 70px; width: 70px;">
                   <?php }?>
            </div>
            <div class="col-lg-6 float-right">
               <label class="col-form-label float-left"><span class="text-danger">*</span>Rate Breakup Image(Optional)</label>
                <?php if($city_ad['rate_breakup_img']){?>
                 <img src="../../../Gama_hrms/upload/Client/<?php echo $city_ad['rate_breakup_img'];?>" style="height: 70px; width: 70px; "/>
                  <?php } else{ ?>
                     <img class="img" src="<?php echo base_url();?>resource/images/image.jpeg" alt="User Avatar" style="height: 70px; width: 70px;">
                   <?php }?>
                 
            </div>
          </div>
         
          <div class="form-group row mt-5">
            <div class="col-md-6">
              <a class="btn btn-warning" href="<?php echo base_url('AdminDash/printClientInfo/'.$city_ad['id']);?>"><i class="fas fa-print"></i></a>
            </div>
            <div class="col-md-6">
            <a class="btn btn-danger" href="<?php echo base_url('AdminDash/All_Client');?>">Cancel</a>
            </div>
           </div>
          </div>
        </div></center>    
    </section>
  </div>
<?php echo form_close(); ?>