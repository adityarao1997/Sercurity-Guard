<?php defined('BASEPATH') OR exit('No direct script access allowed');

date_default_timezone_set("Asia/Calcutta");
  $dtmonth = date("m");
  $dtyear = date("Y");
?> 
  <div class="content-wrapper">
    <div class="content-header pb-0">
      <div class="container-fluid">
        <div class="row ">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Attandance  List</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Attandance View</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=" connectedSortable ">
        
         <center>
           <div class=" col-md-12">
              <a href="#" id="addRow1" class="btn btn-info" data-toggle="modal" data-target="#add_employee">Add New <i class="fa fa-plus"></i></a>
               <a href="<?php echo site_url('AdminDash/Print_attandance');?>" class="btn btn-info" >Print <i class="fa fa-print"></i></a>
         </center>
      <div class="table-scrollable" style="width: 98%;padding: 20px;" style="border: 1px solid black;">
        <table  id="add_att_table" class="table table-striped table-bordered" >
          <thead >
            <tr>
              <th scope="col">S.No</th>
              <th scope="col">Emp. Code</th>
              <th scope="col">UAN</th>
              <th scope="col">Name</th>
              <th scope="col">Designation</th>
              <th scope="col">Account No.</th>
              
            </tr>
          </thead>
          <tbody id="table_emp_body">
          
          </tbody>
        </table>
         <br>
        <button class="btn btn-success float-sm-right pull-right" id="save_pay" disabled="true">Save</button>
      </div>
      <br><br>
      <div style="border: 1px solid #c7bcbc;padding: 5px;color: #868585;margin: 10px;">
        <p style="margin-bottom: 0px;"><b>NH</b> : National Holiday</p>
        <p style="margin-bottom: 0px;">* Check absent days checkboxes only.</p>
        <p style="margin-bottom: 0px;">* All unchecked days checkboxes considered as present days.</p>
      </div>
    </section>
  </div>
  <div class="modal fade" id="add_employee" tabindex="-1" role="dialog" aria-labelledby="add_employeeLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="add_employeeLabel">Select Employee</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-1"></div>
            <label class="col-md-1">Year</label>
            <div class="col-md-3">
              <select class="form-control" id="dtyearp" name="dtyearp">
                <?php
                for($i=2017; $i<$dtyear; $i++)
                {
                  ?>
                  <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                  <?php
                }
                ?>
                <option value="<?php echo $dtyear; ?>" selected><?php echo $dtyear; ?></option>
              </select>
            </div>
            <div class="col-md-1"></div>
            <label class="col-md-1">Month</label>
            <div class="col-md-3">
              <select class="form-control" id="dtmonthp" name="dtmonthp">
                <option value="">Select Month</option>
                <?php
                  $i = 1;
                  while($i <= 12)
                  {
                    $sel = "";
                    if($dtmonth == $i)
                    {
                      $sel = "selected";
                    }
                    $days_in_month=cal_days_in_month(CAL_GREGORIAN,$i,$dtyear);
                    ?>
                    <option value="<?=$i ?>" data-day="<?=$days_in_month ?>" <?=$sel ?>><?=$i ?></option>
                    <?php
                    $i++;
                  }
                ?>
              </select>
            </div>
          </div>
          <br>
          <div class="row hiderow">
            <div class="col-md-3">
              <select class="form-control" id="loc_type">
                <option value="">Location Type</option>
                <option value="Central">Central</option>
                <option value="State">State</option>
              </select>
            </div>
          
            <div class="col-md-3" id="city_div">
	        	</div>
            <div class="col-md-3" id="zone_div">
            </div>
	        	<div class="col-md-3" id="co_name">
	        	</div>
            <div class="col-md-12" id="emp_type_out">
            </div>
	        	<div class="col-md-12 mt-4" id="emp_type">
	        	</div>
	        	<input type="hidden" id="co_nameid">
	        	<input type="hidden" id="city_ida">
	        	<input type="hidden" id="zone_ida">
          
          </div>
          <div class="row" id="emp_out" style="max-height: 55vh;overflow-y: scroll;">
            
          </div>
          <input type="hidden" name="tr_allids" id="tr_allids">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" data-dismiss="modal">Save</button>
          
        </div>
      </div>
    </div>
  </div>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <script type="text/javascript">
    var ndate = new Date();
    var curmonth = ndate.getMonth() + 1;
    $(document).ready(function()
    {
      $("#dtmonthp").on('change',function ()
      {
        if($(this).val() != "")
        {
          $('.hiderow').show();
          var days = $(this).find(':selected').data('day');
          //console.log(days);
          var dataHTML = '';
          $('.all_day_head').remove();
          for( var i=1; i<=days; i++)
          {
            /*dataHTML += '<th>'+i+'<br><input type="checkbox" id="daytd'+i+'" name="absent_days[]" value="'+i+'"><select id="daysel_'+i+'" name="absent_type[]"><option value="full">Full</option><option value="half">Haft</option><option value="NH">NH</option></select></th>';*/
            dataHTML += '<th class="all_day_head">Day '+i+'</th>';
          }
          $("#add_att_table thead tr").append(dataHTML);
        }
        else
        {
          $('.hiderow').hide();
        }
      });
      var selcurmonth = curmonth + 1;

      $("#dtyearp").on('change',function ()
      {
        var sel_year = $(this).val();
        if(sel_year != "")
        {
          var out_months = '<option value="">Select Month</option>';
          var i = 1;
          var curmonth_days = 0;
          while(i <= 12)
          {
            curmonth_days = getDaysInMonth(i,sel_year);
            out_months += '<option value="'+i+'"  data-day="'+curmonth_days+'">'+i+'</option>';
            i++;
          }
          $("#dtmonthp").html(out_months);
        }
      });
      
      $("#dtmonthp").trigger("change");
    });
    function getDaysInMonth(month,year)
    {
      return new Date(year, month, 0).getDate();
    };
     </script>