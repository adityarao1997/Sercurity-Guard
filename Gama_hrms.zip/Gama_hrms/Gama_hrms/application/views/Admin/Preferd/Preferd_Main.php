<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 
 <div class="content-wrapper">

    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Preferd For</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Preferd For</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=" connectedSortable pl-2">
    	<div class="Container ">
            <?php echo form_open("AdminDash/AddPreferdFor" ,['class'=>'navbar-form navbar-right ','role'=>'search']);?>
            <div class="row">
               <div class=" col-md-12">
                   <?php echo form_submit(['value' => 'Add New','class'=>'btn btn-primary ']);?>
              </div>
            </div>
        </div>
      <div style="width: 98%;padding: 20px;">
        <table class="table table-striped table-bordered" id="col_table">
          <thead >
            <tr>
              <th scope="col">S.No</th>
              <th scope="col">Vendor Type</th>
              <th scope="col">Preferd Name</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $i = 0;
            foreach($prefered as $f)
            {
              $i++;
              $vend_id = $f['vendor_typeid'];
              $data1 = $this->SAdmin_model->comapare($vend_id);
              ?>
              <tr>
                <td><?php echo $i; ?></td>
                <td class="text-danger"><?php echo $data1[0]['vendor_type'];?></td>
                <td><?php echo $f['prefered_name']; ?></td>
                <td>
                  <button class="btn btn-success btn-sm">
                     <a href="<?php echo site_url('AdminDash/preferedEdit/'.$f['id']);?>" style="color: white;">Edit</a> 
                   </button>
                   <button class="btn btn-success btn-sm">
                     <a href="<?php echo site_url('AdminDash/preferedEdit/'.$f['id']);?>" style="color: white;">View</a> 
                   </button>
                  <button type="button" class="btn btn-danger btn-sm dlt_click" id="<?php   echo $f['id']; ?>" data-name="<?php echo $f['prefered_name']; ?>"       data-url="<?php echo site_url('AdminDash/preferedDlt/'.$f['id']);?>">Delete
                  </button>
                </td> 
              </tr>
              <?php
            }
            ?>
          </tbody>
        </table>
      </div>
    </section>
    <div class="modal fade model-sm" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Are you Sure to delete this?</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
             
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-danger">
               <a href="" style="color: white;" class="delete_id">Delete</a> 
              </button>
            </div>
          </div>
         </div>
       </div>           
 </div>    
