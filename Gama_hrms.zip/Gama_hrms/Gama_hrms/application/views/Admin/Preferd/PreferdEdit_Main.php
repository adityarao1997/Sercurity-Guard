<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 

<?php echo form_open('AdminDash/preferedEdit/'.$prefered['id'],array("class"=>"form-horizontal")); ?>

 <?php if($error = $this->session->flashdata('login_response')):?>
      <div class="row">
        <div class="col-lg-12">
            <div class="alert alert-dismissible alert-danger">
               <?php echo $error; ?>
            </div>
       </div>
      </div>
    <?php endif; ?> 


 <div class="content-wrapper">
     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">prefered</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('AdminDash');?>">Home</a></li>
              <li class="breadcrumb-item active">Prefered Edit</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  
    <section class="col-lg-12 connectedSortable pl-3">
     <center><div class="col-lg-6">
         <div class="card-body login-card-body" style="border: 1px solid green;">
          <i class="nav-icon fab fa-audible"><h5 class="text-dark">Select the <b>Preferd For</b></h5></i>
          <a href="<?php echo base_url('AdminDash/PreferdFor');?>"><span class=" float-right nav-icon text-danger aria-hidden" ><b>X<b></span></a> <br><br>
          <div class="form-group">
            <label for="type_name" class="col-sm-6 float-sm-left"><span class="text-danger">*</span>Select Vendor Type</label>
            <div class="col-md-8">
               <select name="vendor_typeid" class="form-control">
                  <option value="">Select vendor_type</option>
                  <?php 
                  foreach($all_vendor_type as $vendor_type)
                  {
                    $selected = ($vendor_type['id'] == $prefered['vendor_typeid']) ? ' selected="selected"' : "";

                    echo '<option value="'.$vendor_type['id'].'" '.$selected.'>'.$vendor_type['vendor_type'].'</option>';
                  } 
                  ?>
      </select>
            </div>
          </div>
         <div class="form-group">
            <label for="type_name" class="col-sm-6 float-sm-left"><span class="text-danger">*</span>Type Name</label>
            <div class="col-md-8">
              <input type="text" name="prefered_name" value="<?php echo ($this->input->post('prefered_name') ? $this->input->post('prefered_name') : $prefered['prefered_name']); ?>" class="form-control" id="prefered_name" />
            </div>
        </div>
          <div class="form-group row">
            <div class=" col-md-6">
                  <?php echo form_submit(['value' => 'submit','class'=>'btn btn-primary float-sm-right','name' => 'upload']);?>
            </div>
            <div class="col-md-6">
              <a class="btn btn-danger" href="<?php echo base_url('AdminDash/PreferdFor');?>">Cancel</a>
            </div>
           </div>
          </div>
        </div></center>    
    </section>
  </div>
<?php echo form_close(); ?>   
