<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 
<?php echo form_open('AdminDash/Create_Zone',array("class"=>"form-horizontal")); ?>
 <?php if($error = $this->session->flashdata('login_response')):?>
      <div class="row">
        <div class="col-lg-12">
            <div class="alert alert-dismissible alert-danger">
               <?php echo $error; ?>
            </div>
       </div>
      </div>
    <?php endif; ?> 
 <div class="content-wrapper">
     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Zone Add</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('AdminDash');?>">Home</a></li>
              <li class="breadcrumb-item active">Zone Add</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  
    <section class="col-lg-12 connectedSortable">
     <center><div class="col-lg-8">
         <div class="card-body login-card-body" style="border: 1px solid green;">
          <i class="nav-icon fab fa-audible"><h5 class="text-dark">Add <b>New City</b></h5>
          </i><a class="float-right" href="<?php echo base_url('AdminDash/All_Zone');?>"><i class=" text-danger"><b>X<b></i></a> <br><br>
         
         <div class="row mt-4">
            <div class="col-lg-6 float-left">
              <label for="type_name" class="float-sm-left"><span class="text-danger">*</span>City Name</label>
               <select name="city"  class="form-control">
               <option value="">Select City</option>
                <?php 
                   foreach($all_city_type as $city_type)
                        {
                           $selected = ($city_type['city'] == $this->input->post('city')) ? ' selected="selected"' : "";

                      echo '<option value="'.$city_type['city'].'" '.$selected.'>'.$city_type['city'].'</option>';
                         } 
                ?>
              </select>
            </div>
            <div class="col-lg-6 float-right">
              <label for="type_name" class="float-sm-left"><span class="text-danger">*</span>Company Name</label>
                <select name="co_name"  class="form-control">
               <option value="">Select Company</option>
                <?php 
                   foreach($all_cmp_type as $cmp)
                        {
                           $selected = ($cmp['cl_coname'] == $this->input->post('cl_coname')) ? ' selected="selected"' : "";

                      echo '<option value="'.$cmp['cl_coname'].'" '.$selected.'>'.$cmp['cl_coname'].'</option>';
                         } 
                ?>
              </select>
            </div>
         </div>
         <div class="row mt-4">
            <div class="col-lg-6 float-left">
               <label for="type_name" class="float-sm-left"><span class="text-danger">*</span>Zone Name</label>
                <input type="text" name="zone" placeholder="Zone Name" value="<?php echo $this->input->post('zone'); ?>" class="form-control" id="zone" />
            </div>
            <div class="col-lg-6 float-right">
              <label for="type_name" class="float-sm-left"><span class="text-danger">*</span>EPF Deduction %</label>
                <input type="text" name="depf" placeholder="EPF Deduction %" value="8.3" class="form-control" id="depf" />
            </div>
         </div>
         <div class="row mt-4">
            <div class="col-lg-6 float-left">
               <label for="type_name" class="float-sm-left"><span class="text-danger">*</span>EPF Contribution %</label>
                <input type="text" name="cepf" placeholder="EPF Contribution %" value="7.692" class="form-control" id="cepf" />
            </div>
            <div class="col-lg-6 float-right">
              <label for="type_name" class="float-sm-left"><span class="text-danger">*</span>ESI Deduction %</label>
                <input type="text" name="desi" placeholder="ESI Deduction %" value="57.142" class="form-control" id="desi" />
            </div>
         </div>

         <div class="row mt-4">
            <div class="col-lg-6 float-left">
              <label for="type_name" class="float-sm-left"><span class="text-danger">*</span>ESI Contribution %</label>
                <input type="text" name="cesi" placeholder="ESI Contribution %" value="21.053" class="form-control" id="cesi" />
            </div>
         </div>

         
          <div class="form-group row mt-5">
            <div class="col-md-6">
                
                <input type="submit" name="upload" class="btn btn-success" value="Save">
            </div>
            <div class="col-md-6">
              <a class="btn btn-danger" href="<?php echo base_url('AdminDash/All_Zone');?>">Cancel</a>
            </div>
           </div>
          </div>
        </div></center>    
    </section>
  </div>
<?php echo form_close(); ?>   
