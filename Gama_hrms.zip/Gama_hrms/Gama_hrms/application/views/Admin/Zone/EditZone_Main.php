<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 

<?php echo form_open('AdminDash/Edit_Zone/'.$zone_ad['id'],array("class"=>"form-horizontal")); ?>
 <?php if($error = $this->session->flashdata('login_response')):?>
      <div class="row">
        <div class="col-lg-12">
            <div class="alert alert-dismissible alert-danger">
               <?php echo $error; ?>
            </div>
       </div>
      </div>
    <?php endif; ?> 


 <div class="content-wrapper">
     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Setup</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('AdminDash');?>">Home</a></li>
              <li class="breadcrumb-item active">Setup Add</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  
    <section class="col-lg-12 connectedSortable">
     <center><div class="col-lg-6">
         <div class="card-body login-card-body" style="border: 1px solid green;">
          <i class="nav-icon fab fa-audible"><h5 class="text-dark">Edit <b>Zone</b></h5></i> <a class="float-right" href="<?php echo base_url('AdminDash/All_City');?>"><i class="text-danger"><b>X<b></i></a><br><br>
          
          <div class="row mt-4">
            <div class="col-lg-6 float-left">
              <label class="float-left">City</label> 
              <input type="text" class="form-control text-bold " value="<?php echo $zone_ad['city']?>" readonly>
            </div>
            <div class="col-lg-6 float-right">
               <label class="float-left">Company Name</label> 
              <input type="text" class="form-control text-bold" value="<?php echo $zone_ad['co_name']?>" readonly>
            </div>
          </div> 

          <div class="row mt-4">
            <div class="col-lg-6 float-left">
              <label class="float-left">Zone Name</label> 
              <input type="text" name="zone" value="<?php echo ($this->input->post('zone') ? $this->input->post('zone') : $zone_ad['zone']); ?>" class="form-control" id="zone" />
            </div>
            <div class="col-lg-6 float-right">
               <label class="float-left">EPF Deduction %</label> 
               <input type="text" name="depf" value="<?php echo ($this->input->post('depf') ? $this->input->post('depf') : $zone_ad['depf']); ?>" class="form-control" id="city" />
            </div>
          </div>
          <div class="row mt-4">
            <div class="col-lg-6 float-left">
              <label class="float-left">EPF Contribution %</label> 
              <input type="text" name="cepf" value="<?php echo ($this->input->post('cepf') ? $this->input->post('cepf') : $zone_ad['cepf']); ?>" class="form-control" id="cepf" />
            </div>
            <div class="col-lg-6 float-right">
               <label class="float-left">ESI Deduction %</label> 
               <input type="text" name="desi" value="<?php echo ($this->input->post('desi') ? $this->input->post('desi') : $zone_ad['desi']); ?>" class="form-control" id="desi" />
            </div>
          </div> 
           <div class="row mt-4">
            <div class="col-lg-6 float-left">
              <label class="float-left">ESI Contribution %</label> 
              <input type="text" name="cesi" value="<?php echo ($this->input->post('cesi') ? $this->input->post('cesi') : $zone_ad['cesi']); ?>" class="form-control" id="cesi" />
            </div>
           
          </div> 
         
          <div class="form-group row mt-4">
            <div class=" col-md-6">
                <?php echo form_submit(['value' => 'Save','class'=>'btn btn-primary ', 'name'=>'upload']);?>
            </div>
            <div class="col-md-6">
            <a class="btn btn-danger" href="<?php echo base_url('AdminDash/All_City');?>">Cancel</a>
            </div>
           </div>
          </div>
        </div></center>    
    </section>
  </div>
<?php echo form_close(); ?>   
