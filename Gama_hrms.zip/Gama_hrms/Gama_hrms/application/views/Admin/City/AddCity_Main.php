<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 
<?php echo form_open('AdminDash/Create_City',array("class"=>"form-horizontal")); ?>
 <?php if($error = $this->session->flashdata('login_response')):?>
      <div class="row">
        <div class="col-lg-12">
            <div class="alert alert-dismissible alert-danger">
               <?php echo $error; ?>
            </div>
       </div>
      </div>
    <?php endif; ?> 
 <div class="content-wrapper">
     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">City Add</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('AdminDash');?>">Home</a></li>
              <li class="breadcrumb-item active">City Add</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  
    <section class="col-lg-12 connectedSortable">
     <center><div class="col-lg-6">
         <div class="card-body login-card-body" style="border: 1px solid green;">
          <i class="nav-icon fab fa-audible"><h5 class="text-dark">Add <b>New City</b></h5>
          </i><a class="float-right" href="<?php echo base_url('AdminDash/All_City');?>"><i class=" text-danger"><b>X<b></i></a> <br><br>
         
         <div class="form-group">
            <label for="type_name" class="col-sm-6 float-sm-left"><span class="text-danger">*</span>City Name</label>
            <div class="col-md-10">
              <input type="text" name="city" placeholder="City Name" value="<?php echo $this->input->post('city'); ?>" class="form-control" id="city" />
            </div>
        </div>
          <div class="form-group row">
            <div class="col-md-6">
                
                <input type="submit" name="upload" class="btn btn-success" value="Save">
            </div>
            <div class="col-md-6">
              <a class="btn btn-danger" href="<?php echo base_url('AdminDash/All_City');?>">Cancel</a>
            </div>
           </div>
          </div>
        </div></center>    
    </section>
  </div>
<?php echo form_close(); ?>   
