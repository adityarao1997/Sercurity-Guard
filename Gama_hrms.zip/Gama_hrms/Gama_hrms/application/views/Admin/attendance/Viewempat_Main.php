<?php defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set("Asia/Calcutta");
  $dtmonth = date("m");
  $dtyear = date("Y");
?> 
  <div class="content-wrapper">
    <div class="content-header pb-0">
      <div class="container-fluid">
        <div class="row ">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Attandance Add</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Attandance Add</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=" connectedSortable ">
         <?php echo form_open("AdminDash/Add_Attandance" ,['class'=>'navbar-form navbar-right ','role'=>'search']);?>
         <center>
          <div style="width: 58%;padding: 20px;">
               <select class="form-control" id="search_mnth" name="search_mnth">
                <?php
                for($i=2017; $i<$dtyear; $i++)
                {
                  ?>
                  <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                  <?php
                }
                ?>
                <option value="<?php echo $dtyear; ?>" selected><?php echo $dtyear; ?></option>
              </select>
          </div>
          <div style="width: 58%;padding: 20px;">
             <div class="row" id="Mnth_btn">
               
             </div>  
          </div>
         </center>
    </section>
  </div>
  <div class="modal fade model-sm" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Are you Sure to delete this?</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
         
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-danger">
           <a href="" style="color: white;" class="delete_id">Delete</a> 
          </button>
        </div>
      </div>
    </div>
  </div>