<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 
  <div class="content-wrapper">
    <div class="content-header pb-0">
      <div class="container-fluid">
        <div class="row ">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Attandance List</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Attandance View</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=" connectedSortable ">
         <?php echo form_open("AdminDash/New_Attandance" ,['class'=>'navbar-form navbar-right ','role'=>'search']);?>
         <center>
           <div class=" col-md-12">
             <?php echo form_submit(['value' => 'Add New','class'=>'btn btn-primary ']);?>
            </div>
         </center>
      <div style="width: 98%;padding: 20px;">
        <table  id="col_table" class="table table-striped table-bordered" >
          <thead  >
            <tr>
              <th scope="col">S.No</th>
              <th scope="col">Name</th>
              <th scope="col">Company</th>
              <th scope="col">Contact</th>
              <th scope="col">Month</th>
              <th scope="col">Present-Day</th>
              <th scope="col">Absent</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
          <?php
          $i = 0;
          foreach($attnd_data as $attd_d)
          {
            $i++;
               $ad = $attd_d['month_days'] - $attd_d['absent_days'];
               

            ?>
            <tr>
              <td><?php echo $i; ?></td>
              <td><?php echo $attd_d['emp_name']; ?></td>
              <td><?php echo $attd_d['cmp_name']; ?></td>
              <td><?php echo $attd_d['contact_no']; ?></td>
              <td><?php echo $attd_d['month']; ?></td>
              <td><?php echo $ad; ?></td>
              <td><?php echo $attd_d['absent_days']; ?></td>
              <td>
                  <a href="<?php echo site_url('AdminDash/Print_attandance/'.$attd_d['id']);?>" style="color: white;" class="btn btn-success btn-sm"><i class="fas fa-print"></i></a>
                 <a href="<?php echo site_url('AdminDash/Emp_attendance/'.$attd_d['id']);?>" style="color: white;" class="btn btn-success btn-sm"><i class="fas fa-eye"></i></a>
                <button type="button" class="btn btn-danger btn-sm dlt_click" id="<?php echo $attd_d['id']; ?>" data-name="<?php echo $attd_d['emp_name']; ?>" data-url="<?php echo site_url('AdminDash/Del_attendance/'.$attd_d['id']);?>"><i class="far fa-trash-alt"></i></button>
              </td>
            </tr>
            <?php
          }
          ?>
          </tbody>
        </table>
      </div>
    </section>
  </div>
  <div class="modal fade model-sm" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Are you Sure to delete this?</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
         
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-danger">
           <a href="" style="color: white;" class="delete_id">Delete</a> 
          </button>
        </div>
      </div>
    </div>
  </div>