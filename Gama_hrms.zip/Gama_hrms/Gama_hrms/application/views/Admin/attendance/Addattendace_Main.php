<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 

<?php echo form_open_multipart('AdminDash/Attandace_add/'.$data_ad['id'],array("class"=>"form-horizontal")); ?>
 <?php if($error = $this->session->flashdata('login_response')):?>
      <div class="row">
        <div class="col-lg-12">
            <div class="alert alert-dismissible alert-danger">
               <?php echo $error; ?>
            </div>
       </div>
      </div>
    <?php endif; ?> 
<?php

 
?>


 <div class="content-wrapper">
     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Attandance View</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('AdminDash');?>">Home</a></li>
              <li class="breadcrumb-item active">Attandance View</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  
    <section class="col-lg-12 connectedSortable">
     <center><div class="col-lg-10">
         <div class="card-body login-card-body" style="box-shadow: 2;">
          <i class="nav-icon fab fa-audible"><h5 class="text-dark">Attandance <b>View</b></h5></i> <a class="float-right" href="<?php echo base_url('AdminDash/All_Attandance');?>"><i class="text-danger"><b>X<b></i></a><br><br>
          
          <div class="row mt-2">
            <div class="col-lg-6 float-left">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Employee Code</label>
                <input  type="text" name="emp_name" class="form-control text-bold" value="<?php echo ($this->input->post('emp_code') ? $this->input->post('emp_code') : $data_ad['emp_code']); ?>" id="emp_name" placeholder="Client Name" >
            </div>
             <div class="col-lg-6 float-right">
               <label class="col-form-label float-left"><span class="text-danger">*</span>Employee Name</label>
                <input  type="text" name="cmp_name" class="form-control text-bold" value="<?php echo ($this->input->post('emp_name') ? $this->input->post('emp_name') : $data_ad['emp_name']); ?>" id="cmp_name" placeholder="Company Name" >
            </div>
          </div>
           <div class="row mt-2">
            <div class="col-lg-6 float-left">
              <label class="col-form-label float-left"><span class="text-danger">*</span>UAN Number</label>
                <input  type="text" name="uan" class="form-control text-bold" value="<?php echo ($this->input->post('uan') ? $this->input->post('uan') : $data_ad['uan']); ?>" id="uan" placeholder="Client Name" >
            </div>
             <div class="col-lg-6 float-right">
               <label class="col-form-label float-left"><span class="text-danger">*</span>Contact Number</label>
                <input  type="text" name="contact_no" class="form-control text-bold" value="<?php echo ($this->input->post('contact_no') ? $this->input->post('contact_no') : $data_ad['contact_no']); ?>" id="contact_no" placeholder="Company Name" >
            </div>
          </div>
          <div class="row mt-2">
            <div class="col-lg-6 float-left">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Company Name</label>
                <input  type="text" name="cmp_name" class="form-control text-bold" value="<?php echo ($this->input->post('cmp_name') ? $this->input->post('cmp_name') : $data_ad['cmp_name']); ?>" id="cmp_name" placeholder="Client Name" >
            </div>
             <div class="col-lg-6 float-right">
               <label class="col-form-label float-left"><span class="text-danger">*</span>Year</label>
                <input  type="text" name="year" class="form-control text-bold" value="<?php echo ($this->input->post('year') ? $this->input->post('year') : $data_ad['year']); ?>" id="year" placeholder="Company Name" >
            </div>
          </div>
          <div class="row mt-2">
            <div class="col-lg-6 float-left">
              <label class="col-form-label float-left"><span class="text-danger">*</span>Month</label>
                <input  type="text" name="month" class="form-control text-bold" value="<?php echo ($this->input->post('month') ? $this->input->post('month') : $data_ad['month']); ?>" id="month" placeholder="Client Name" >
            </div>
            
          </div>
          <div class="row mt-5">
              <h4 class="text-bold text-danger" style="align : center;">All Absent Days </h4>
            <table class="table" style="border: 1px solid black; ">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">S.no</th>
                  <th scope="col">Date</th>
                  <th scope="col">Absent</th>
                </tr>
              </thead>
              <tbody>
                <?php
                 $temp1 = explode('-_-', $data_ad['absent_detail']);
                 for ($i=0; $i < $data_ad['absent_days']; $i++) { 
                 $temp2 = explode('-', $temp1[$i]);
                   $y = 1;
                   $z = 0; 
                   
                ?>
                <tr>
                  <th scope="row"><?=$i+1;?></th>
                  <td><?=$temp2[$z]?>/<?=$data_ad['month']?>/<?=$data_ad['year']?></td>
                  <td><?=$temp2[$y]?> day leave</td>
                </tr>
              <?php  }?>
              </tbody>
            </table>
          </div>
         
         
          <div class="form-group row mt-5">
            <div class="col-md-6">
            <a class="btn btn-danger" href="<?php echo base_url('AdminDash/All_Attandance');?>">Cancel</a>
            </div>
           </div>
          </div>
        </div></center>    
    </section>
  </div>
<?php echo form_close(); ?>  

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script type="text/javascript">
     $(document).ready(function(){
        $("#dtmonthp").on('change',function () {
            var days = $(this).find(':selected').data('day');
            console.log(days);
         var dataHTML = '';
         for( var i=1; i<=days; i++)
         {
          dataHTML += '<div class="col-lg-6"><th>Days-'+i+'<br><input type="checkbox" id="daytd'+i+'" name="absent_days[][absent_days]" value="'+i+'"><select id="daysel_'+i+'" name="absent_type[][absent_type]"><option value="full">Full</option><option value="half">Haft</option><option value="NH">NH</option></select></th></div><br>';
         }
         $("#formetdata").html(dataHTML);

        });
    });
 </script>