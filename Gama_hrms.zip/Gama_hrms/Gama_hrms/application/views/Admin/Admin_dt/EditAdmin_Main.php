<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 

<?php echo form_open('AdminDash/Edit_Admin/'.$admin['id'],array("class"=>"form-horizontal")); ?>
 <?php if($error = $this->session->flashdata('login_response')):?>
      <div class="row">
        <div class="col-lg-12">
            <div class="alert alert-dismissible alert-danger">
               <?php echo $error; ?>
            </div>
       </div>
      </div>
    <?php endif; ?> 


 <div class="content-wrapper">
     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Admin Edit</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('AdminDash');?>">Home</a></li>
              <li class="breadcrumb-item active">Admin Details</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  
    <section class="col-lg-12 connectedSortable">
     <center><div class="col-lg-6">
         <div class="card-body login-card-body" style="border: 1px solid green;">
          <i class="nav-icon fab fa-audible"><h5 class="text-dark">Edit <b>Admin</b></h5></i> <a class="float-right" href="<?php echo base_url('AdminDash/All_Admin');?>"><i class="text-danger"><b>X<b></i></a><br><br>
          
          <div class="row mt-4">
            <div class="col-lg-6 float-left">
              <label class="float-left">City</label> 
              <input type="text" class="form-control text-bold " value="<?php echo $admin['city']?>" readonly>
            </div>
          </div> 

          <div class="row mt-4">
            <div class="col-lg-6 float-left">
              <label class="float-left">Admin Name</label> 
              <input type="text" name="zone" value="<?php echo ($this->input->post('name') ? $this->input->post('zone') : $admin['name']); ?>" class="form-control" id="zone" readonly/>
            </div>
            <div class="col-lg-6 float-right">
               <label class="float-left">Email</label> 
               <input type="text" name="depf" value="<?php echo ($this->input->post('email') ? $this->input->post('depf') : $admin['email']); ?>" class="form-control" id="city" readonly/>
            </div>
          </div>
          <div class="row mt-4">
            <div class="col-lg-6 float-left">
              <label class="float-left">Contact Number</label> 
              <input type="text" name="cepf" value="<?php echo ($this->input->post('contact') ? $this->input->post('cepf') : $admin['contact']); ?>" class="form-control" id="cepf" readonly/>
            </div>
            <div class="col-lg-6 float-right">
               <label class="float-left">Password</label> 
               <input type="text" name="desi" value="<?php echo ($this->input->post('pass') ? $this->input->post('desi') : $admin['pass']); ?>" class="form-control" id="desi" readonly/>
            </div>
          </div> 
         
            <div class="col-md-6 mt-5">
            <a class="btn btn-danger" href="<?php echo base_url('AdminDash/All_Admin');?>">Cancel</a>
            </div>
          </div> 
         
          
          </div>
        </div></center>    
    </section>
  </div>
<?php echo form_close(); ?>   
