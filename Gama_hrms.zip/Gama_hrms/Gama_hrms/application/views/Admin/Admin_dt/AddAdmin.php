<?php 

    $this->load->view('Layout/include/header');
    $this->load->view('Layout/include/sidebar');
    $this->load->view('Admin/Admin_dt/AddAdmin_Main.php');
    $this->load->view('Layout/include/footer');

?>






