<?php
	
	if(isset($_POST["mob_no"]))
	{
		$otp = mt_rand(100000, 999999);
		$_SESSION["reg_otp"] = $otp;
		echo $otp;
	}

?>