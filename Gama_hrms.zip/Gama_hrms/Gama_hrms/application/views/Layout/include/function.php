<?php
	//echo "jsdhfdskjdfsfdsfdjsfhksjdsfhjk";
	if(isset($_POST["loc_type1"]))
	{
		
		$loc = $_POST["loc_type1"];
    $ret = $this->Admin_model->serch_locType($loc);
    //$output = "check";
    $output = '
      <select name="city" class="form-control" id="city_sel">
        <option value="">Select City</option>
        '.$ret.'
      </select>
    ';
    //echo json_encode($ret);
    //$ret = "ch";
    echo json_encode($output);
	}

	if(isset($_POST["city_sel1"]))
  {
    $city = $_POST["city_sel1"];
    $ret = $this->Admin_model->serchcmp_bycity($city);
    $output = '
        <select class="form-control" id="zone_sel">
          <option value="">Select Zone</option>
          '.$ret.'
        </select>
    ';
    echo $output;
  }

  if(isset($_POST["zone_sel1"]))
  {
    $zone = $_POST["zone_sel1"];
    $ret = $this->Admin_model->serchcmp_byzone($zone);
    $output = '
        <select class="form-control" id="coname_sel">
          <option value="">Select Company</option>
          '.$ret.'
        </select>
    ';
    echo $output;
  }

  if(isset($_POST["coname_sel1"]))
  {
    $coname_sel = $_POST["coname_sel1"];
    $ret = $this->Admin_model->serchcmp_byemp($coname_sel);

    echo $ret;
  }

  if(isset($_POST["tr_allid"]))
  {
    
    $ids = $_POST["tr_allid"];
    $output = "";
    foreach($ids as $id)
    {
      $output .= rettddata($id);
    }
    echo $output;
  }

  if(isset($_POST["tr_id"]))
  {
    
    $id = $_POST["tr_id"];
    $sel_month = $_POST["sel_month"];
    $sel_year = $_POST["sel_year"];

    $output = $this->Admin_model->rettddata($id, $sel_month, $sel_year);
    echo $output;
  }
  
  if(isset($_POST["emp_at_count"]))
  {
    $emp_at_count = $_POST["emp_at_count"];
    $atsub_cmp = $_POST["atsub_cmp"];
    $atsub_monthday = $_POST["atsub_monthday"];
    $atsub_month = $_POST["atsub_month"];
    $atsub_year = $_POST["atsub_year"];

    $ch = 0;
    $already = 0;
    if($emp_at_count > 0)
    {
      $i = 0;
      while($i < $emp_at_count)
      {
        
        $emp_code_a = $_POST["emp_code_a".$i];
        $nametd_a = $_POST["nametd_a".$i];
        $uanno_a = $_POST["uanno_a".$i];
        $contaid_a = $_POST["contaid_a".$i];
        $emp_atid = $_POST["emp_atid".$i];
        $absent_days = $_POST["absent_days".$i];
        $all_absent_detail = $_POST["all_absent_detail".$i];

        $ret = $this->Admin_model->add_attendancenew($emp_code_a, $nametd_a, $uanno_a, $contaid_a, $emp_atid, $absent_days, $all_absent_detail,$atsub_cmp, $atsub_monthday, $atsub_month, $atsub_year);
        if($ret)
        {
          $ch++;
        }
        else if($ret == "already")
        {
          $already++;
        }
        
        $i++;
      }
    }
    if($ch >= 1)
    {
      $output = 1;
    }
    else if($already > 0)
    {
      $output = "already";
    }
    else
    {
      $output = 0;
    }
    echo $output;
  }
  
   if(isset($_POST["search_mnth1"]))
  {
    
    $loc = $_POST["search_mnth1"];
    $ret = $this->Admin_model->serch_month_attenda($loc);
    $output = '
     <a class="btn btn-info" href="'.base_url('AdminDash/Print_atndby_mnth/'.$ret).'" >'.$ret.'</a>
     
    ';
    //echo json_encode($ret);
    //$ret = "ch";
    echo json_encode($output);
  }


?>