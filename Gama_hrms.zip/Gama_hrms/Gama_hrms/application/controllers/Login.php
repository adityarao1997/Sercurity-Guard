<?php
class Login extends CI_Controller
 {

   function __construct()
    {
        parent::__construct();
        $this->load->model('Login_model');
    } 
 	
 	public function index()
 	{    
        $this->session->unset_userdata('id');
 		    $this->load->view('Layout/login');
 	}

 	public function all_login()
 	{
 		    $this->form_validation->set_rules('email', 'email', 'required');
        $this->form_validation->set_rules('pass', 'pass', 'required');
        $this->form_validation->set_rules('type', 'type', 'required');
        $this->form_validation->set_error_delimiters('<div class="error">','</div>');
        if ($this->form_validation->run()) 
        {
                
          $email = $this->input->post('email');
          $pass = $this->input->post('pass');
          $type = $this->input->post('type');
              $id = $this->Login_model->login_all($email, $pass, $type);
              if($id > 0)
              {
                $this->session->set_userdata(['id'=>$id]);
                return redirect('AdminDash');
              }
              else
              {
                $error = $this->session->set_flashdata('login_response', 'Invalid username/password');
                return redirect('Login');
              }
          }
          else
          {
             $data['_view'] =  'Layout/login';
             $this->load->view('Layout/login',$data);
          }
  
  }
  
     public function Subadmin()
  {    
        $this->session->unset_userdata('id');
        $this->load->view('Layout/login2');
  }

    public function sub_login()
  {
        $this->form_validation->set_rules('email', 'email', 'required');
        $this->form_validation->set_rules('pass', 'pass', 'required');
        $this->form_validation->set_rules('type', 'type', 'required');
        $this->form_validation->set_error_delimiters('<div class="error">','</div>');
        if ($this->form_validation->run()) 
        {
                
          $email = $this->input->post('email');
          $pass = $this->input->post('pass');
          $type = $this->input->post('type');
              $id = $this->Login_model->login_sub($email, $pass, $type);
              if($id > 0)
              {
                $this->session->set_userdata(['id'=>$id]);
                return redirect('Dashboard');
              }
              else
              {
                $error = $this->session->set_flashdata('login_response', 'Invalid username/password');
                return redirect('Login/sub_login');
              }
          }
          else
          {
             $data['_view'] =  'Layout/login2';
             $this->load->view('Layout/login2',$data);
          }
  
  }


}
       
?>