<?php
class AdminDash extends CI_Controller
  {
    function __construct()
    {
        parent::__construct();
        $this->load->model('Admin_model');
        $this->load->model('Login_model');
    } 

    /*
     * Listing of types
     */
      function index()
      {
        $data['cur_page'] = "dashboard";
         if(!$this->session->userdata('id')){
                  return redirect('Login');
            }else{
                $this->load->view('Admin/Dashboard/index',$data);
              }

      }
       function access_ajax_other()
      {
          $data['_view'] = 'Layout/include/function';
         $this->load->view('Layout/include/function',$data);
      }


     /*City Start*/
      function All_City()
      {    
        $params['limit'] = 'RECORDS_PER_PAGE'; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('Admin/City/ViewCity');
        $config['total_rows'] = $this->Admin_model->get_all_city_count();
        $this->pagination->initialize($config);

        $data['city_data'] = $this->Admin_model->get_all_cityList($params);
        
      
        $data['cur_page'] = "dashboard";
        $data['main_page'] = "all_city";
        $data['_view'] =  'Admin/City/ViewCity';
        $this->load->view('Admin/City/ViewCity',$data);
      }

      function Create_City()
      {    
        
       if( $this->input->post('upload') )    // if form is posted
        {
           
          $this->form_validation->set_rules('city','city','required');
           
          $city = $this->input->post('city');

             if($this->Admin_model->add_city($city))
             {
                
                  return redirect('AdminDash/All_City');
             }else
              {
                   $this->load->view('Admin/City/AddCity');
              }
             
        } 
        $data['cur_page'] = "dashboard";
        $data['_view'] =  'Admin/City/AddCity';
        $this->load->view('Admin/City/AddCity',$data);
      }

      function City_Edit($id)
      {
        $data['city_ad'] = $this->Admin_model->get_city_avail($id);

        if(isset($data['city_ad']['id']))
        {
          $this->load->library('form_validation');
          $this->form_validation->set_rules('city','city','required');

          if($this->form_validation->run())     
          {  
            
            $params = array(
              'city' => $this->input->post('city'),
            );

            $this->Admin_model->update_city($id,$params);
            redirect('AdminDash/All_City');
          }
          else
          {
            $data['city_ad'] = $this->Admin_model->get_city_avail($id);
            $data['_view'] = 'Admin/City/EditCity';
            $this->load->view('Admin/City/EditCity',$data);
          }
        }
        else
        {
          show_error('The City you are trying to edit does not exist.');
        }
      }
      function Del_city($id)
      {
          $city = $this->Admin_model->get_city_avail($id);

          if(isset($city['id']))
          {
              $this->Admin_model->delete_city($id);
              redirect('AdminDash/All_City');
          }
          else
              show_error('The admin you are trying to delete does not exist.');
      }
     /*City Close*/

     /*Client Start*/
      function All_Client()
      {    
        $params['limit'] = 'RECORDS_PER_PAGE'; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('Admin/Client_dt/ViewClient');
        $config['total_rows'] = $this->Admin_model->get_all_client_count();
        $this->pagination->initialize($config);

        $data['client_data'] = $this->Admin_model->get_all_clientList($params);
        
      
        $data['cur_page'] = "dashboard";
        $data['main_page'] = "All_Client";
        $data['_view'] =  'Admin/Client_dt/ViewClient';
        $this->load->view('Admin/Client_dt/ViewClient',$data);
      }

      function Create_Client()
      {    
        
       if( $this->input->post('upload') )    // if form is posted
        {
           
          $this->form_validation->set_rules('cl_name','cl_name','required');
          $this->form_validation->set_rules('cl_coname','cl_coname','required');
          $this->form_validation->set_rules('cl_noemp','cl_noemp','required');
          $this->form_validation->set_rules('cl_gst','cl_gst');
          $this->form_validation->set_rules('cl_agno','cl_agno');
          $this->form_validation->set_rules('cl_cont','cl_cont','required');
          $this->form_validation->set_rules('cl_city','cl_city','required');
          $this->form_validation->set_rules('laber_no','laber_no');
          $this->form_validation->set_rules('cl_agri_stdate','cl_agri_stdate');
          $this->form_validation->set_rules('cl_agri_enddate','cl_agri_enddate');
          $this->form_validation->set_rules('cl_address','cl_address','required');
          $this->form_validation->set_rules('work_order_no','work_order_no');
           
          $cl_name = $this->input->post('cl_name');
          $cl_coname = $this->input->post('cl_coname');
          $cl_noemp = $this->input->post('cl_noemp');
          $cl_gst = $this->input->post('cl_gst');
          $cl_agno = $this->input->post('cl_agno');
          $cl_cont = $this->input->post('cl_cont');
          $cl_city = $this->input->post('cl_city');
          $laber_no = $this->input->post('laber_no');
          $cl_agri_stdate = $this->input->post('cl_agri_stdate');
          $cl_agri_enddate = $this->input->post('cl_agri_enddate');
          $cl_address = $this->input->post('cl_address');
          $work_order_no = $this->input->post('work_order_no');

         
          $client_logo = "";

          $config['upload_path'] = './upload/Client/';
          $config['allowed_types'] = 'jpg|png|jpeg|gif';


          if($_FILES["client_logo"]["name"] != "")
           {
             $client_logo_ext2 = explode('.', $_FILES["client_logo"]["name"]);
             $client_logo_ext2 = end($client_logo_ext2);
             $client_logo = 'Client_logo'.uniqid().date('Y-m-d');
             $config['file_name']= $client_logo;  
             $this->load->library('upload', $config);  
             $this->lets_upload_client('client_logo');
            $client_logo = $client_logo.'.'.$client_logo_ext2;
           }
            $laber_pic = "";

           if($_FILES["laber_pic"]["name"] != "")
           {
             $laber_pic_ext2 = explode('.', $_FILES["laber_pic"]["name"]);
             $laber_pic_ext2 = end($laber_pic_ext2);
             $laber_pic = 'Laber-lince'.uniqid().date('Y-m-d');
             $config['file_name']= $laber_pic;  
             $this->upload->initialize($config);  
             $this->load->library('upload', $config);  
             $this->lets_upload_client('laber_pic');
            $laber_pic = $laber_pic.'.'.$laber_pic_ext2;
           }
           $order_pic = "";

           if($_FILES["order_pic"]["name"] != "")
           {
             $order_pic_ext2 = explode('.', $_FILES["order_pic"]["name"]);
             $order_pic_ext2 = end($order_pic_ext2);
             $order_pic = 'Agrement-lince'.uniqid().date('Y-m-d');
             $config['file_name']= $order_pic;  
             $this->upload->initialize($config);  
             $this->load->library('upload', $config);  
             $this->lets_upload_client('order_pic');
             $order_pic = $order_pic.'.'.$order_pic_ext2;
           }

            $work_order_pic = "";

           if($_FILES["work_order_pic"]["name"] != "")
           {
             $work_order_pic_ext2 = explode('.', $_FILES["work_order_pic"]["name"]);
             $work_order_pic_ext2 = end($work_order_pic_ext2);
             $work_order_pic = 'work_order_pic'.uniqid().date('Y-m-d');
             $config['file_name']= $work_order_pic;  
             $this->upload->initialize($config);  
             $this->load->library('upload', $config);  
             $this->lets_upload_client('work_order_pic');
             $work_order_pic = $work_order_pic.'.'.$work_order_pic_ext2;
           }

           $rate_breakup_img = "";

           if($_FILES["rate_breakup_img"]["name"] != "")
           {
             $rate_breakup_img_ext2 = explode('.', $_FILES["rate_breakup_img"]["name"]);
             $rate_breakup_img_ext2 = end($rate_breakup_img_ext2);
             $rate_breakup_img = 'rate_breakup_img'.uniqid().date('Y-m-d');
             $config['file_name']= $rate_breakup_img;  
             $this->upload->initialize($config);  
             $this->load->library('upload', $config);  
             $this->lets_upload_client('rate_breakup_img');
             $rate_breakup_img = $rate_breakup_img.'.'.$rate_breakup_img_ext2;
           }

             if($this->Admin_model->add_client($cl_name,$cl_coname,$cl_city,$cl_address,$work_order_no,$work_order_pic,$cl_noemp,$cl_gst,$cl_agno,$cl_cont,$laber_no,$cl_agri_stdate,$cl_agri_enddate,$client_logo,$laber_pic,$order_pic,$rate_breakup_img))
             {
                
                  return redirect('AdminDash/All_Client');
             }else
              {
                   $this->load->view('Admin/Client_dt/AddClient');
              }
             
        } 
        $data['cur_page'] = "dashboard";
         $data['all_city_type'] = $this->Admin_model->get_all_city_type('city');
        $data['_view'] =  'Admin/Client_dt/AddClient';
        $this->load->view('Admin/Client_dt/AddClient',$data);
      }

      function Client_Edit($id)
      {
        $data['city_ad'] = $this->Admin_model->get_client_avail($id);

        if(isset($data['city_ad']['id']))
        {

          $this->form_validation->set_rules('cl_name','cl_name','required');
          $this->form_validation->set_rules('cl_coname','cl_coname','required');
          $this->form_validation->set_rules('cl_noemp','cl_noemp','required');
          $this->form_validation->set_rules('cl_gst','cl_gst');
          $this->form_validation->set_rules('cl_agno','cl_agno');
          $this->form_validation->set_rules('cl_cont','cl_cont','required');
          $this->form_validation->set_rules('cl_city','cl_city','required');
          $this->form_validation->set_rules('laber_no','laber_no');
          $this->form_validation->set_rules('cl_agri_stdate','cl_agri_stdate');
          $this->form_validation->set_rules('cl_agri_enddate','cl_agri_enddate');
          $this->form_validation->set_rules('cl_address','cl_address','required');
          $this->form_validation->set_rules('work_order_no','work_order_no');

          if($this->form_validation->run())     
          {  
            $client_logo = $data['city_ad']['client_logo'];
            $laber_pic = $data['city_ad']['laber_pic'];
            $order_pic = $data['city_ad']['order_pic'];
            $work_order_pic = $data['city_ad']['work_order_pic'];
            $rate_breakup_img = $data['city_ad']['rate_breakup_img'];
           
            $config['upload_path'] = './upload/Client/';                        
            $config['allowed_types'] = 'jpg|png|jpeg|gif';
            $this->load->library('upload');
            
            if(isset($_FILES["client_logo"]['tmp_name']))
            {
              if(file_exists($_FILES["client_logo"]['tmp_name']) || is_uploaded_file($_FILES['client_logo']['tmp_name']))
              {
                //echo "cmp<br>";
                $test1 = explode(".", $_FILES["client_logo"]["name"]);
                $extension1 = end($test1);
                $client_logo = 'Updated_Client_image-'.date('Y-m-d').uniqid().'.'.$extension1;
          
                $config['file_name']= $client_logo;
                $this->upload->initialize($config);
                $this->load->library('upload', $config);  
                $this->lets_upload_client('client_logo');

                $file = './upload/'.$data['city_ad']['client_logo'];
                if(is_file($file))
                  unlink($file);
              }
            }
            if(isset($_FILES["laber_pic"]['tmp_name']))
            {
              if(file_exists($_FILES["laber_pic"]['tmp_name']) || is_uploaded_file($_FILES['laber_pic']['tmp_name']))
              {
                //echo "cmp<br>";
                $test1 = explode(".", $_FILES["laber_pic"]["name"]);
                $extension1 = end($test1);
                $laber_pic = 'Updated_laber_image-'.date('Y-m-d').uniqid().'.'.$extension1;
          
                $config['file_name']= $laber_pic;
                $this->upload->initialize($config);
                $this->load->library('upload', $config);  
                $this->lets_upload_client('laber_pic');

                $file = './upload/'.$data['city_ad']['laber_pic'];
                if(is_file($file))
                  unlink($file);
              }
            }
            if(isset($_FILES["order_pic"]['tmp_name']))
            {
              if(file_exists($_FILES["order_pic"]['tmp_name']) || is_uploaded_file($_FILES['order_pic']['tmp_name']))
              {
                //echo "cmp<br>";
                $test1 = explode(".", $_FILES["order_pic"]["name"]);
                $extension1 = end($test1);
                $order_pic = 'Updated_Agrement-'.date('Y-m-d').uniqid().'.'.$extension1;
          
                $config['file_name']= $order_pic;
                $this->upload->initialize($config);
                $this->load->library('upload', $config);  
                $this->lets_upload_client('order_pic');

                $file = './upload/'.$data['city_ad']['order_pic'];
                if(is_file($file))
                  unlink($file);
              }
            }
            if(isset($_FILES["work_order_pic"]['tmp_name']))
            {
              if(file_exists($_FILES["work_order_pic"]['tmp_name']) || is_uploaded_file($_FILES['work_order_pic']['tmp_name']))
              {
                //echo "cmp<br>";
                $test1 = explode(".", $_FILES["work_order_pic"]["name"]);
                $extension1 = end($test1);
                $work_order_pic = 'Update_work_order_pic-'.date('Y-m-d').uniqid().'.'.$extension1;
          
                $config['file_name']= $work_order_pic;
                $this->upload->initialize($config);
                $this->load->library('upload', $config);  
                $this->lets_upload_client('work_order_pic');

                $file = './upload/'.$data['city_ad']['work_order_pic'];
                if(is_file($file))
                  unlink($file);
              }
            }
            if(isset($_FILES["rate_breakup_img"]['tmp_name']))
            {
              if(file_exists($_FILES["rate_breakup_img"]['tmp_name']) || is_uploaded_file($_FILES['rate_breakup_img']['tmp_name']))
              {
                //echo "cmp<br>";
                $test1 = explode(".", $_FILES["rate_breakup_img"]["name"]);
                $extension1 = end($test1);
                $rate_breakup_img = 'Update_rate_breakup_img-'.date('Y-m-d').uniqid().'.'.$extension1;
          
                $config['file_name']= $rate_breakup_img;
                $this->upload->initialize($config);
                $this->load->library('upload', $config);  
                $this->lets_upload_client('rate_breakup_img');

                $file = './upload/'.$data['city_ad']['rate_breakup_img'];
                if(is_file($file))
                  unlink($file);
              }
            }
            $params = array(
            
              'cl_name' => $this->input->post('cl_name'),
              'cl_coname' => $this->input->post('cl_coname'),
              'cl_noemp' => $this->input->post('cl_noemp'),
              'cl_gst' => $this->input->post('cl_gst'),
              'cl_agno' => $this->input->post('cl_agno'),
              'cl_cont' => $this->input->post('cl_cont'),
              'cl_city' => $this->input->post('cl_city'),
              'cl_address' => $this->input->post('cl_address'),
              'work_order_no' => $this->input->post('work_order_no'),
              'laber_no' => $this->input->post('laber_no'),
              'cl_agri_stdate' => $this->input->post('cl_agri_stdate'),
              'cl_agri_enddate' => $this->input->post('cl_agri_enddate'),
              'client_logo' => $client_logo,
              'laber_pic' => $laber_pic,
              'order_pic' => $order_pic,
              'work_order_pic' => $work_order_pic,
              'rate_breakup_img' => $rate_breakup_img,
              
            );

            $this->Admin_model->update_client($id,$params);
            redirect('AdminDash/All_Client');
          }
          else
          {
            $data['city_ad'] = $this->Admin_model->get_client_avail($id);
            $data['all_city_type'] = $this->Admin_model->get_all_city_type('city');
            $data['_view'] = 'Admin/Client_dt/EditClient';
            $this->load->view('Admin/Client_dt/EditClient',$data);
          }
        }
        else
        {
          show_error('The City you are trying to edit does not exist.');
        }
      }
      
      function View_client_info($id)
      {
        $data['city_ad'] = $this->Admin_model->get_client_avail($id);
        $data['all_city_type'] = $this->Admin_model->get_all_city_type('city');
        $data['_view'] = 'Admin/Client_dt/View';
        $this->load->view('Admin/Client_dt/View',$data);
      }
      function Del_Client($id)
      {
          $city = $this->Admin_model->get_client_avail($id);

          if(isset($city['id']))
          {
              $this->Admin_model->delete_client($id);
              redirect('AdminDash/All_Client');
          }
          else
              show_error('The admin you are trying to delete does not exist.');
      }
     /*Client Close*/

    function lets_upload_client( $field_name )   
    {
      if( ! $this->upload->do_upload( $field_name ))    
      {
        $this->data['notification'] .= $this->upload->display_errors(); 
      }
      else
      {
        $upload_data = $this->upload->data();    
        $path = $upload_data['file_name'];   
        $this->data['notification'] = " is successfully uploaded.<br>";    
      }
    }


         /*City Start*/
      function All_Zone()
      {    
        $params['limit'] = 'RECORDS_PER_PAGE'; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('Admin/Zone/ViewZone');
        $config['total_rows'] = $this->Admin_model->get_all_Zone_count();
        $this->pagination->initialize($config);

        $data['zone_data'] = $this->Admin_model->get_all_ZoneList($params);
        
      
        $data['cur_page'] = "dashboard";
        $data['main_page'] = "all_zone";
        $data['_view'] =  'Admin/Zone/ViewZone';
        $this->load->view('Admin/Zone/ViewZone',$data);
      }

      function Create_Zone()
      {    
        
       if( $this->input->post('upload') )    // if form is posted
        {
           
          $this->form_validation->set_rules('city','city','required');
          $this->form_validation->set_rules('co_name','co_name','required');
          $this->form_validation->set_rules('zone','zone','required');
          $this->form_validation->set_rules('depf','depf','required');
          $this->form_validation->set_rules('cepf','cepf','required');
          $this->form_validation->set_rules('desi','desi','required');
          $this->form_validation->set_rules('cesi','cesi','required');
           
          $city = $this->input->post('city');
          $co_name = $this->input->post('co_name');
          $zone = $this->input->post('zone');
          $depf = $this->input->post('depf');
          $cepf = $this->input->post('cepf');
          $desi = $this->input->post('desi');
          $cesi = $this->input->post('cesi');

             if($this->Admin_model->add_zone($city,$co_name,$zone,$depf,$cepf,$desi,$cesi))
             {
                
                  return redirect('AdminDash/All_Zone');
             }else
              {
                   $this->load->view('Admin/Zone/AddZone');
              }
             
        } 
        $data['cur_page'] = "dashboard";
        $data['all_city_type'] = $this->Admin_model->get_all_city_type('city');
        $data['all_cmp_type'] = $this->Admin_model->get_all_comp_type('client');
        $data['_view'] =  'Admin/Zone/AddZone';
        $this->load->view('Admin/Zone/AddZone',$data);
      }

      function Edit_Zone($id)
      {
        $data['zone_ad'] = $this->Admin_model->get_zone_avail($id);

        if(isset($data['zone_ad']['id']))
        {
          $this->load->library('form_validation');
          $this->form_validation->set_rules('zone','zone','required');
          $this->form_validation->set_rules('depf','depf','required');
          $this->form_validation->set_rules('cepf','cepf','required');
          $this->form_validation->set_rules('desi','desi','required');
          $this->form_validation->set_rules('cesi','cesi','required');

          if($this->form_validation->run())     
          {  
            
            $params = array(
              'zone' => $this->input->post('zone'),
              'depf' => $this->input->post('depf'),
              'cepf' => $this->input->post('cepf'),
              'desi' => $this->input->post('desi'),
              'cesi' => $this->input->post('cesi'),
            );

            $this->Admin_model->update_zone($id,$params);
            redirect('AdminDash/All_Zone');
          }
          else
          {
            $data['zone_ad'] = $this->Admin_model->get_zone_avail($id);
            $data['_view'] = 'Admin/Zone/EditZone';
            $this->load->view('Admin/Zone/EditZone',$data);
          }
        }
        else
        {
          show_error('The City you are trying to edit does not exist.');
        }
      }
      function Del_Zone($id)
      {
          $city = $this->Admin_model->get_zone_avail($id);

          if(isset($city['id']))
          {
              $this->Admin_model->delete_zone($id);
              redirect('AdminDash/All_Zone');
          }
          else
              show_error('The admin you are trying to delete does not exist.');
      }
     /*City Close*/

     /*Admin Add*/
      function All_admin()
      {    
        $params['limit'] = 'RECORDS_PER_PAGE'; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('Admin/Admin_dt/ViewAdmin');
        $config['total_rows'] = $this->Admin_model->get_all_admin_count();
        $this->pagination->initialize($config);

        $data['admin_data'] = $this->Admin_model->get_all_adminList($params);
        
      
        $data['cur_page'] = "dashboard";
        $data['main_page'] = "All_Client";
        $data['_view'] =  'Admin/Admin_dt/ViewAdmin';
        $this->load->view('Admin/Admin_dt/ViewAdmin',$data);
      }
       function Create_Admin()
      {    
        
       if( $this->input->post('upload') )    // if form is posted
        {
           
          $this->form_validation->set_rules('name','name','required');
          $this->form_validation->set_rules('email','email','required');
          $this->form_validation->set_rules('contact','contact','required');
          $this->form_validation->set_rules('city','city','required');
          $this->form_validation->set_rules('pass','pass','required');
           
          $name = $this->input->post('name');
          $email = $this->input->post('email');
          $contact = $this->input->post('contact');
          $city = $this->input->post('city');
          $pass = $this->input->post('pass');
          $type = $this->input->post('type');

         

             if($this->Admin_model->add_admin($name,$email,$contact,$city,$pass,$type))
             {
                
                  return redirect('AdminDash/All_admin');
             }else
              {
                   $this->load->view('Admin/Admin_dt/AddAdmin');
              }
             
        } 
        $data['cur_page'] = "dashboard";
        $data['all_city_type'] = $this->Admin_model->get_all_city_type('city');
        $data['_view'] =  'Admin/Admin_dt/AddAdmin';
        $this->load->view('Admin/Admin_dt/AddAdmin',$data);
      }

       function Edit_Admin($id)
        {
        
            $data['admin'] = $this->Admin_model->get_admin($id);
            $data['_view'] = 'Admin/Admin_dt/EditAdmin';
            $this->load->view('Admin/Admin_dt/EditAdmin',$data);
      
        }
      function Del_Admin($id)
      {
          $admin = $this->Admin_model->get_admin($id);

          if(isset($admin['id']))
          {
              $this->Admin_model->delete_admin($id);
              redirect('AdminDash/All_Admin');
          }
          else
              show_error('The admin you are trying to delete does not exist.');
      }


       /*Admin Add*/
      function All_Subadmin()
      {    
        $params['limit'] = 'RECORDS_PER_PAGE'; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('Admin/Subadmin_dt/ViewsbAdmin');
        $config['total_rows'] = $this->Admin_model->get_all_sadmin_count();
        $this->pagination->initialize($config);

        $data['subadmin'] = $this->Admin_model->get_all_sadminList($params);
        
      
        $data['cur_page'] = "dashboard";
        $data['main_page'] = "All_Client";
        $data['_view'] =  'Admin/Subadmin_dt/ViewsbAdmin';
        $this->load->view('Admin/Subadmin_dt/ViewsbAdmin',$data);
      }
      function Create_SAdmin()
      {    
        
       if( $this->input->post('upload') )    // if form is posted
        {
           
          $this->form_validation->set_rules('name','name','required');
          $this->form_validation->set_rules('email','email','required');
          $this->form_validation->set_rules('contact','contact','required');
          $this->form_validation->set_rules('city','city','required');
          $this->form_validation->set_rules('pass','pass','required');
           
          $name = $this->input->post('name');
          $email = $this->input->post('email');
          $contact = $this->input->post('contact');
          $city = $this->input->post('city');
          $pass = $this->input->post('pass');
          $type = $this->input->post('type');

         

             if($this->Admin_model->add_sadmin($name,$email,$contact,$city,$pass,$type))
             {
                
                  return redirect('AdminDash/All_Subadmin');
             }else
              {
                   $this->load->view('Admin/Subadmin_dt/AddsbAdmin');
              }
             
        } 
        $data['cur_page'] = "dashboard";
        $data['all_city_type'] = $this->Admin_model->get_all_city_type('city');
        $data['_view'] =  'Admin/Subadmin_dt/AddsbAdmin';
        $this->load->view('Admin/Subadmin_dt/AddsbAdmin',$data);
      }

       function Edit_SAdmin($id)
        {
        
            $data['sbadmin'] = $this->Admin_model->get_sadmin($id);
            $data['_view'] = 'Admin/Subadmin_dt/EditsbAdmin';
            $this->load->view('Admin/Subadmin_dt/EditsbAdmin',$data);
      
        }
      function Del_SAdmin($id)
      {
          $admin = $this->Admin_model->get_sadmin($id);

          if(isset($admin['id']))
          {
              $this->Admin_model->delete_sadmin($id);
              redirect('AdminDash/All_Subadmin');
          }
          else
              show_error('The admin you are trying to delete does not exist.');
      }
      
      
       /*Employeee  Start*/
      function All_Employee()
      {    
        $params['limit'] = 'RECORDS_PER_PAGE'; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('Admin/Employee/Viewemp');
        $config['total_rows'] = $this->Admin_model->get_all_emp_count();
        $this->pagination->initialize($config);

        $data['emp_data'] = $this->Admin_model->get_all_empList($params);
        
      
        $data['cur_page'] = "dashboard";
        $data['main_page'] = "All_Client";
        $data['_view'] =  'Admin/Employee/Viewemp';
        $this->load->view('Admin/Employee/Viewemp',$data);
      }

      function Create_Employee()
      {    
        
       if( $this->input->post('upload') )    // if form is posted
        {
           
          $this->form_validation->set_rules('fname','fname','required');
          $this->form_validation->set_rules('lname','lname','required');
          $this->form_validation->set_rules('esic_num','esic_num','required');
          $this->form_validation->set_rules('faname','faname','required');
          $this->form_validation->set_rules('moname','moname','required');
          $this->form_validation->set_rules('addr','addr','required');
          $this->form_validation->set_rules('addr2','addr2','required');
          $this->form_validation->set_rules('desg','desg','required');
          $this->form_validation->set_rules('gender','gender','required');
          $this->form_validation->set_rules('cont','cont','required');
          $this->form_validation->set_rules('dob','dob','required');
          $this->form_validation->set_rules('jdate','jdate','required');
          $this->form_validation->set_rules('ac_no','ac_no','required');
          $this->form_validation->set_rules('ac_name','ac_name','required');
          $this->form_validation->set_rules('ifsc','ifsc','required');
          $this->form_validation->set_rules('bank_name','bank_name','required');
          $this->form_validation->set_rules('loc_type','loc_type','required');
          $this->form_validation->set_rules('co_name','co_name','required');
          $this->form_validation->set_rules('zone','zone','required');
          $this->form_validation->set_rules('med_cer','med_cer','required');
          $this->form_validation->set_rules('polic_ver','polic_ver','required');
          $this->form_validation->set_rules('polic_case','polic_case','required');
          $this->form_validation->set_rules('nationality','nationality','required');
          $this->form_validation->set_rules('mrg_status','mrg_status','required');
          $this->form_validation->set_rules('adhar_num','adhar_num','required');
          $this->form_validation->set_rules('pan_num','pan_num','required');
          $this->form_validation->set_rules('other_bnk','other_bnk');
          $this->form_validation->set_rules('other_deg','other_deg');
           
          $fname = $this->input->post('fname');
          $lname = $this->input->post('lname');
          $esic_num = $this->input->post('esic_num');
          $faname = $this->input->post('faname');
          $moname = $this->input->post('moname');
          $addr = $this->input->post('addr');
          $addr2 = $this->input->post('addr2');
          $desg = $this->input->post('desg');
          $gender = $this->input->post('gender');
          $cont = $this->input->post('cont');
          $dob = $this->input->post('dob');
          $jdate = $this->input->post('jdate');
          $ac_no = $this->input->post('ac_no');
          $ac_name = $this->input->post('ac_name');
          $ifsc = $this->input->post('ifsc');
          $bank_name = $this->input->post('bank_name');
          $loc_type = $this->input->post('loc_type');
          $city = $this->input->post('city');
          $co_name = $this->input->post('co_name');
          $zone = $this->input->post('zone');
          $med_cer = $this->input->post('med_cer');
          $polic_ver = $this->input->post('polic_ver');
          $polic_case = $this->input->post('polic_case');
          $nationality = $this->input->post('nationality');
          $mrg_status = $this->input->post('mrg_status');
          $adhar_num = $this->input->post('adhar_num');
          $pan_num = $this->input->post('pan_num');
          $other_bnk = $this->input->post('other_bnk');
          $other_deg = $this->input->post('other_deg');
          
          $mem_nm = '';
             $mem_rel = '';
             $mem_con ='';
              foreach ($this->input->post('mem_nm') as $key => $value) 
              {
                if($mem_nm == "")
                {
                    $mem_nm =  $value["mem_nm"];
                }
                else
                {
                    $mem_nm .= ','.$value["mem_nm"];
                }
              
              }
               foreach ($this->input->post('mem_rel') as $key => $value) 
              {
                if($mem_rel == "")
                {
                    $mem_rel =  $value["mem_rel"];
                }
                else
                {
                    $mem_rel .= ','.$value["mem_rel"];
                }
              
              }
              foreach ($this->input->post('mem_con') as $key => $value) 
              {
                if($mem_con == "")
                {
                    $mem_con =  $value["mem_con"];
                }
                else
                {
                    $mem_con .= ','.$value["mem_con"];
                }
              
              }

          $image = "";
          $adhar = "";
          $passbook = "";
          $pan_up = "";
          $ten_mask = "";
          $twl_mark = "";
          $medcer_pic = "";
          $policcer_pic = "";

          $config['upload_path'] = './upload/Employee/';
          $config['allowed_types'] = 'jpg|png|jpeg|gif';


          if($_FILES["image"]["name"] != "")
           {
             $image_ext2 = explode('.', $_FILES["image"]["name"]);
             $image_ext2 = end($image_ext2);
             $image = 'Employee-Image'.uniqid().date('Y-m-d');
             $config['file_name']= $image;  
             $this->load->library('upload', $config);  
             $this->lets_upload_employee('image');
            $image = $image.'.'.$image_ext2;
           }

           if($_FILES["adhar"]["name"] != "")
           {
             $adhar_ext2 = explode('.', $_FILES["adhar"]["name"]);
             $adhar_ext2 = end($adhar_ext2);
             $adhar = 'Adhar-pic'.uniqid().date('Y-m-d');
             $config['file_name']= $adhar;  
             $this->upload->initialize($config);  
             $this->load->library('upload', $config);  
             $this->lets_upload_employee('adhar');
            $adhar = $adhar.'.'.$adhar_ext2;
           }
           if($_FILES["passbook"]["name"] != "")
           {
             $passbook_ext2 = explode('.', $_FILES["passbook"]["name"]);
             $passbook_ext2 = end($passbook_ext2);
             $passbook = 'BankPassbook'.uniqid().date('Y-m-d');
             $config['file_name']= $passbook;  
             $this->upload->initialize($config);  
             $this->load->library('upload', $config);  
             $this->lets_upload_employee('passbook');
            $passbook = $passbook.'.'.$passbook_ext2;
           }
           if($_FILES["pan_up"]["name"] != "")
           {
             $pan_up_ext2 = explode('.', $_FILES["pan_up"]["name"]);
             $pan_up_ext2 = end($pan_up_ext2);
             $pan_up = 'PanCard'.uniqid().date('Y-m-d');
             $config['file_name']= $pan_up;  
             $this->upload->initialize($config);  
             $this->load->library('upload', $config);  
             $this->lets_upload_employee('pan_up');
            $pan_up = $pan_up.'.'.$pan_up_ext2;
           }
           if($_FILES["ten_mask"]["name"] != "")
           {
             $ten_mask_ext2 = explode('.', $_FILES["ten_mask"]["name"]);
             $ten_mask_ext2 = end($ten_mask_ext2);
             $ten_mask = 'MarkTen'.uniqid().date('Y-m-d');
             $config['file_name']= $ten_mask;  
             $this->upload->initialize($config);  
             $this->load->library('upload', $config);  
             $this->lets_upload_employee('ten_mask');
            $ten_mask = $ten_mask.'.'.$ten_mask_ext2;
           }
           if($_FILES["twl_mark"]["name"] != "")
           {
             $twl_mark_ext2 = explode('.', $_FILES["twl_mark"]["name"]);
             $twl_mark_ext2 = end($twl_mark_ext2);
             $twl_mark = 'MarkTwl'.uniqid().date('Y-m-d');
             $config['file_name']= $twl_mark;  
             $this->upload->initialize($config);  
             $this->load->library('upload', $config);  
             $this->lets_upload_employee('twl_mark');
            $twl_mark = $twl_mark.'.'.$twl_mark_ext2;
           }
           if($_FILES["medcer_pic"]["name"] != "")
           {
             $medcer_pic_ext2 = explode('.', $_FILES["medcer_pic"]["name"]);
             $medcer_pic_ext2 = end($medcer_pic_ext2);
             $medcer_pic = 'mediclCer'.uniqid().date('Y-m-d');
             $config['file_name']= $medcer_pic;  
             $this->upload->initialize($config);  
             $this->load->library('upload', $config);  
             $this->lets_upload_employee('medcer_pic');
            $medcer_pic = $medcer_pic.'.'.$medcer_pic_ext2;
           }
            if($_FILES["policcer_pic"]["name"] != "")
           {
             $policcer_pic_ext2 = explode('.', $_FILES["policcer_pic"]["name"]);
             $policcer_pic_ext2 = end($policcer_pic_ext2);
             $policcer_pic = 'Policeer'.uniqid().date('Y-m-d');
             $config['file_name']= $policcer_pic;  
             $this->upload->initialize($config);  
             $this->load->library('upload', $config);  
             $this->lets_upload_employee('policcer_pic');
            $policcer_pic = $policcer_pic.'.'.$policcer_pic_ext2;
           }
           
             if($this->Admin_model->add_employee($fname,$lname,$esic_num,$faname,$moname,$addr,$addr2,$desg,$gender,$cont,$dob,$jdate,$ac_no,$ac_name,$ifsc,$bank_name,$loc_type,$city,$co_name,$zone,$mem_nm,$mem_rel,$mem_con,$med_cer,$polic_ver,$polic_case,$nationality,$mrg_status,$adhar_num,$pan_num,$image,$adhar,$passbook,$pan_up,$ten_mask,$twl_mark,$other_bnk,$other_deg,$medcer_pic,$policcer_pic))
             {
                
                  return redirect('AdminDash/All_Employee');
             }else
              {
                   $this->load->view('Admin/Employee/Addemp');
              }
             
        } 
        $data['cur_page'] = "dashboard";
         $data['all_city_type'] = $this->Admin_model->get_all_city_type('city');
         $data['all_cmp_type'] = $this->Admin_model->get_all_comp_type();
         $data['all_zone_type'] = $this->Admin_model->get_all_zone_type();
        $data['_view'] =  'Admin/Employee/Addemp';
        $this->load->view('Admin/Employee/Addemp',$data);
      }

      function Employee_Edit($id)
      {
        $data['emp_ad'] = $this->Admin_model->get_emp($id);

        if(isset($data['emp_ad']['id']))
        {

          $this->form_validation->set_rules('fname','fname','required');
          $this->form_validation->set_rules('lname','lname');
          $this->form_validation->set_rules('esic_num','esic_num');
          $this->form_validation->set_rules('faname','faname','required');
          $this->form_validation->set_rules('moname','moname','required');
          $this->form_validation->set_rules('addr','addr','required');
          $this->form_validation->set_rules('addr2','addr2','required');
          $this->form_validation->set_rules('desg','desg','required');
          $this->form_validation->set_rules('gender','gender','required');
          $this->form_validation->set_rules('cont','cont','required');
          $this->form_validation->set_rules('dob','dob','required');
          $this->form_validation->set_rules('ac_no','ac_no');
          $this->form_validation->set_rules('ac_name','ac_name');
          $this->form_validation->set_rules('ifsc','ifsc');
          $this->form_validation->set_rules('bank_name','bank_name');
          $this->form_validation->set_rules('loc_type','loc_type','required');
          $this->form_validation->set_rules('co_name','co_name','required');
          $this->form_validation->set_rules('zone','zone','required');
          $this->form_validation->set_rules('med_cer','med_cer');
          $this->form_validation->set_rules('polic_ver','polic_ver');
          $this->form_validation->set_rules('polic_case','polic_case');
          $this->form_validation->set_rules('nationality','nationality');
          $this->form_validation->set_rules('mrg_status','mrg_status','required');
          $this->form_validation->set_rules('adhar_num','adhar_num','required');
          $this->form_validation->set_rules('pan_num','pan_num');
          $this->form_validation->set_rules('other_bnk','other_bnk');

          if($this->form_validation->run())     
          {  
            $image = $data['emp_ad']['image'];
            $adhar = $data['emp_ad']['adhar'];
            $passbook = $data['emp_ad']['passbook'];
            $pan_up = $data['emp_ad']['pan_up'];
            $ten_mask = $data['emp_ad']['ten_mask'];
            $twl_mark = $data['emp_ad']['twl_mark'];
            $medcer_pic = $data['emp_ad']['medcer_pic'];
            $policcer_pic = $data['emp_ad']['policcer_pic'];
           
            $config['upload_path'] = './upload/Employee/';                        
            $config['allowed_types'] = 'jpg|png|jpeg|gif';
            $this->load->library('upload');
            
            if(isset($_FILES["image"]['tmp_name']))
            {
              if(file_exists($_FILES["image"]['tmp_name']) || is_uploaded_file($_FILES['image']['tmp_name']))
              {
                //echo "cmp<br>";
                $test1 = explode(".", $_FILES["image"]["name"]);
                $extension1 = end($test1);
                $image = 'Updated_emp-profle-'.date('Y-m-d').uniqid().'.'.$extension1;
          
                $config['file_name']= $image;
                $this->upload->initialize($config);
                $this->load->library('upload', $config);  
                $this->lets_upload_employee('image');

                $file = './upload/'.$data['emp_ad']['image'];
                if(is_file($file))
                  unlink($file);
              }
            }
            if(isset($_FILES["adhar"]['tmp_name']))
            {
              if(file_exists($_FILES["adhar"]['tmp_name']) || is_uploaded_file($_FILES['adhar']['tmp_name']))
              {
                //echo "cmp<br>";
                $test1 = explode(".", $_FILES["adhar"]["name"]);
                $extension1 = end($test1);
                $adhar = 'Updated-Adhar_image-'.date('Y-m-d').uniqid().'.'.$extension1;
          
                $config['file_name']= $adhar;
                $this->upload->initialize($config);
                $this->load->library('upload', $config);  
                $this->lets_upload_employee('adhar');

                $file = './upload/'.$data['emp_ad']['adhar'];
                if(is_file($file))
                  unlink($file);
              }
            }
            if(isset($_FILES["passbook"]['tmp_name']))
            {
              if(file_exists($_FILES["passbook"]['tmp_name']) || is_uploaded_file($_FILES['passbook']['tmp_name']))
              {
                //echo "cmp<br>";
                $test1 = explode(".", $_FILES["passbook"]["name"]);
                $extension1 = end($test1);
                $passbook = 'Updated-Passbook-'.date('Y-m-d').uniqid().'.'.$extension1;
          
                $config['file_name']= $passbook;
                $this->upload->initialize($config);
                $this->load->library('upload', $config);  
                $this->lets_upload_employee('passbook');

                $file = './upload/'.$data['emp_ad']['passbook'];
                if(is_file($file))
                  unlink($file);
              }
            }
            if(isset($_FILES["pan_up"]['tmp_name']))
            {
              if(file_exists($_FILES["pan_up"]['tmp_name']) || is_uploaded_file($_FILES['pan_up']['tmp_name']))
              {
                //echo "cmp<br>";
                $test1 = explode(".", $_FILES["pan_up"]["name"]);
                $extension1 = end($test1);
                $pan_up = 'Updated-Pancard-'.date('Y-m-d').uniqid().'.'.$extension1;
          
                $config['file_name']= $pan_up;
                $this->upload->initialize($config);
                $this->load->library('upload', $config);  
                $this->lets_upload_employee('pan_up');

                $file = './upload/'.$data['emp_ad']['pan_up'];
                if(is_file($file))
                  unlink($file);
              }
            }
            if(isset($_FILES["ten_mask"]['tmp_name']))
            {
              if(file_exists($_FILES["ten_mask"]['tmp_name']) || is_uploaded_file($_FILES['ten_mask']['tmp_name']))
              {
                //echo "cmp<br>";
                $test1 = explode(".", $_FILES["ten_mask"]["name"]);
                $extension1 = end($test1);
                $ten_mask = 'Update-TenMark-'.date('Y-m-d').uniqid().'.'.$extension1;
          
                $config['file_name']= $ten_mask;
                $this->upload->initialize($config);
                $this->load->library('upload', $config);  
                $this->lets_upload_employee('ten_mask');

                $file = './upload/'.$data['emp_ad']['ten_mask'];
                if(is_file($file))
                  unlink($file);
              }
            }
            if(isset($_FILES["twl_mark"]['tmp_name']))
            {
              if(file_exists($_FILES["twl_mark"]['tmp_name']) || is_uploaded_file($_FILES['twl_mark']['tmp_name']))
              {
                //echo "cmp<br>";
                $test1 = explode(".", $_FILES["twl_mark"]["name"]);
                $extension1 = end($test1);
                $twl_mark = 'Update-TwlMark-'.date('Y-m-d').uniqid().'.'.$extension1;
          
                $config['file_name']= $twl_mark;
                $this->upload->initialize($config);
                $this->load->library('upload', $config);  
                $this->lets_upload_employee('twl_mark');

                $file = './upload/'.$data['emp_ad']['twl_mark'];
                if(is_file($file))
                  unlink($file);
              }
            }
             if(isset($_FILES["medcer_pic"]['tmp_name']))
            {
              if(file_exists($_FILES["medcer_pic"]['tmp_name']) || is_uploaded_file($_FILES['medcer_pic']['tmp_name']))
              {
                //echo "cmp<br>";
                $test1 = explode(".", $_FILES["medcer_pic"]["name"]);
                $extension1 = end($test1);
                $medcer_pic = 'Update-TwlMark-'.date('Y-m-d').uniqid().'.'.$extension1;
          
                $config['file_name']= $medcer_pic;
                $this->upload->initialize($config);
                $this->load->library('upload', $config);  
                $this->lets_upload_employee('medcer_pic');

                $file = './upload/'.$data['emp_ad']['medcer_pic'];
                if(is_file($file))
                  unlink($file);
              }
            }

            if(isset($_FILES["policcer_pic"]['tmp_name']))
            {
              if(file_exists($_FILES["policcer_pic"]['tmp_name']) || is_uploaded_file($_FILES['policcer_pic']['tmp_name']))
              {
                //echo "cmp<br>";
                $test1 = explode(".", $_FILES["policcer_pic"]["name"]);
                $extension1 = end($test1);
                $policcer_pic = 'Update-TwlMark-'.date('Y-m-d').uniqid().'.'.$extension1;
          
                $config['file_name']= $policcer_pic;
                $this->upload->initialize($config);
                $this->load->library('upload', $config);  
                $this->lets_upload_employee('policcer_pic');

                $file = './upload/'.$data['emp_ad']['policcer_pic'];
                if(is_file($file))
                  unlink($file);
              }
            }

             $jdate = '';
             $rej_date = '';
             $description ='';
              foreach ($this->input->post('jdate') as $key => $value) 
              {
                if($jdate == "")
                {
                    $jdate =  $value["jdate"];
                }
                else
                {
                    $jdate .= ','.$value["jdate"];
                }
              
              }
               foreach ($this->input->post('rej_date') as $key => $value) 
              {
                if($rej_date == "")
                {
                    $rej_date =  $value["rej_date"];
                }
                else
                {
                    $rej_date .= ','.$value["rej_date"];
                }
              
              }
              foreach ($this->input->post('description') as $key => $value) 
              {
                if($description == "")
                {
                    $description =  $value["description"];
                }
                else
                {
                    $description .= ','.$value["description"];
                }
              
              }
            $mem_nm = '';
             $mem_rel = '';
             $mem_con ='';
              foreach ($this->input->post('mem_nm') as $key => $value) 
              {
                if($mem_nm == "")
                {
                    $mem_nm =  $value["mem_nm"];
                }
                else
                {
                    $mem_nm .= ','.$value["mem_nm"];
                }
              
              }
               foreach ($this->input->post('mem_rel') as $key => $value) 
              {
                if($mem_rel == "")
                {
                    $mem_rel =  $value["mem_rel"];
                }
                else
                {
                    $mem_rel .= ','.$value["mem_rel"];
                }
              
              }
              foreach ($this->input->post('mem_con') as $key => $value) 
              {
                if($mem_con == "")
                {
                    $mem_con =  $value["mem_con"];
                }
                else
                {
                    $mem_con .= ','.$value["mem_con"];
                }
              
              }
                  
            $params = array(
            
              'fname' => $this->input->post('fname'),
              'lname' => $this->input->post('lname'),
              'esic_num' => $this->input->post('esic_num'),
              'faname' => $this->input->post('faname'),
              'moname' => $this->input->post('moname'),
              'addr' => $this->input->post('addr'),
              'addr2' => $this->input->post('addr2'),
              'desg' => $this->input->post('desg'),
              'gender' => $this->input->post('gender'),
              'cont' => $this->input->post('cont'),
              'dob' => $this->input->post('dob'),
              'ac_no' => $this->input->post('ac_no'),
              'ac_name' => $this->input->post('ac_name'),
              'ifsc' => $this->input->post('ifsc'),
              'bank_name' => $this->input->post('bank_name'),
              'loc_type' => $this->input->post('loc_type'),
              'city' => $this->input->post('city'),
              'co_name' => $this->input->post('co_name'),
              'zone' => $this->input->post('zone'),
              'med_cer' => $this->input->post('med_cer'),
              'polic_ver' => $this->input->post('polic_ver'),
              'polic_case' => $this->input->post('polic_case'),
              'nationality' => $this->input->post('nationality'),
              'mrg_status' => $this->input->post('mrg_status'),
              'adhar_num' => $this->input->post('adhar_num'),
              'pan_num' => $this->input->post('pan_num'),
              'other_bnk' => $this->input->post('other_bnk'),
              'jdate' => $jdate,
              'rej_date' => $rej_date,
              'description' => $description,
              'mem_nm' => $mem_nm,
              'mem_rel' => $mem_rel,
              'mem_con' => $mem_con,
              'image' => $image,
              'adhar' => $adhar,
              'passbook' => $passbook,
              'pan_up' => $pan_up,
              'ten_mask' => $ten_mask,
              'twl_mark' => $twl_mark,
              'medcer_pic' => $medcer_pic,
              'policcer_pic' => $policcer_pic,
              
            );

            $this->Admin_model->update_emp($id,$params);
            redirect('AdminDash/All_Employee');
          }
          else
          {
            $data['emp_ad'] = $this->Admin_model->get_emp($id);
            $data['all_city_type'] = $this->Admin_model->get_all_city_type('city');
             $data['all_cmp_type'] = $this->Admin_model->get_all_comp_type();
             $data['all_zone_type'] = $this->Admin_model->get_all_zone_type();
            $data['_view'] = 'Admin/Employee/Editemp';
            $this->load->view('Admin/Employee/Editemp',$data);
          }
        }
        else
        {
          show_error('The City you are trying to edit does not exist.');
        }
      }
      
      function Employee_View($id)
      {
        

            $data['emp_ad'] = $this->Admin_model->get_emp($id);
            $data['all_city_type'] = $this->Admin_model->get_all_city_type('city');
             $data['all_cmp_type'] = $this->Admin_model->get_all_comp_type();
             $data['all_zone_type'] = $this->Admin_model->get_all_zone_type();
            $data['_view'] = 'Admin/Employee/ViewEditemp';
            $this->load->view('Admin/Employee/ViewEditemp',$data);
          
        }
        
      function Del_Employee($id)
      {
          $emp = $this->Admin_model->get_emp($id);

          if(isset($emp['id']))
          {
              $this->Admin_model->delete_emp($id);
              redirect('AdminDash/All_Employee');
          }
          else
              show_error('The admin you are trying to delete does not exist.');
      }
      function lets_upload_employee( $field_name )   
      {
        if( ! $this->upload->do_upload( $field_name ))    
        {
          $this->data['notification'] .= $this->upload->display_errors(); 
        }
        else
        {
          $upload_data = $this->upload->data();    
          $path = $upload_data['file_name'];   
          $this->data['notification'] = " is successfully uploaded.<br>";    
        }
      }
      
    
     /*Client Close*/

   


     /*Employeee  Start*/
      function All_Attandance()
      {    
        $params['limit'] = 'RECORDS_PER_PAGE'; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('Admin/attendance/Viewattd');
        $config['total_rows'] = $this->Admin_model->get_all_attendance_count();
        $this->pagination->initialize($config);

        $data['attnd_data'] = $this->Admin_model->get_all_attendanceList($params);
        
      
        $data['cur_page'] = "dashboard";
        $data['main_page'] = "All_Client";
        $data['_view'] =  'Admin/attendance/Viewattd';
        $this->load->view('Admin/attendance/Viewattd',$data);
      }
      
       function New_Attandance()
      {    
        $params['limit'] = 'RECORDS_PER_PAGE'; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('Admin/newAtnd/Viewnewatnd');
        $config['total_rows'] = $this->Admin_model->get_all_empat_count();
        $this->pagination->initialize($config);

        $data['attnd_data'] = $this->Admin_model->get_all_empatList($params); 
      
        $data['cur_page'] = "dashboard";
        $data['main_page'] = "All_Client";
        $data['all_company'] = $this->Admin_model->get_company_data();
        $data['_view'] =  'Admin/newAtnd/Viewnewatnd';
        $this->load->view('Admin/newAtnd/Viewnewatnd',$data);
      }
      
      function search_att()
      {   
        $data['cur_page'] = "dashboard";
        $data['main_page'] = "All_Client";
        $data['_view'] =  'Admin/attendance/Viewempat';
        $this->load->view('Admin/attendance/Viewempat',$data);
      }

     function Emp_attendance($id)
      {
        $data['cur_page'] = "dashboard"; 
        $data['data_ad'] = $this->Admin_model->get_emp_atd_data($id);
        $data['_view'] = 'Admin/attendance/Addattendace';
        $this->load->view('Admin/attendance/Addattendace',$data);
      }
      
      function Del_attendance($id)
      {
          $emp = $this->Admin_model->get_attendance($id);

          if(isset($emp['id']))
          {
              $this->Admin_model->delete_attendance($id);
              redirect('AdminDash/All_Attandance');
          }
          else
              show_error('The admin you are trying to delete does not exist.');
      }
      
    
     /*Client Close*/
     
    function printDiv($id)
   {
   
        if($id)
        {
            $order_data = $this->Admin_model->get_emp($id);
            
            $mem_nm = explode(',',$order_data['mem_nm']);
            $mem_rel = explode(',',$order_data['mem_rel']);
            $mem_con = explode(',',$order_data['mem_con']);
            
              $vend_id = $order_data['city'];
              $data2 = $this->Admin_model->comapare($vend_id);
               $vend_id1 = $order_data['co_name'];
              $data1 = $this->Admin_model->comapare_com($vend_id1);
               $vend_id3 = $order_data['zone'];
              $data3 = $this->Admin_model->comapare_zone($vend_id3);
            
        
              $html = '<!-- Main content -->
                <!DOCTYPE html>
                <html>
                  <head>
                    <title>Gama Guard Application Form</title>
                    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
                    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
                    <style>
                      html, body {
                      min-height: 90%;
                      }
                      body, div, form, input, select, textarea, label { 
                      padding: 0;
                      margin: 0;
                      outline: none;
                      font-family: Roboto, Arial, sans-serif;
                      font-size: 14px;
                      color: #666;
                      line-height: 22px;
                      }
                      h1 {
                      position: absolute;
                      margin:0;
                      font-size: 30px;
                      color: #fff;
                      z-index: 2;
                      line-height: 83px;
                      
                      }
                      legend {
                      padding: 10px;      
                      font-family: Roboto, Arial, sans-serif;
                      font-size: 18px;
                      color: #fff;
                      background-color: #1c87c9;
                      }
                      textarea {
                      width: calc(100% - 12px);
                      padding: 5px;
                      }
                      .testbox {
                      display: flex;
                      justify-content: center;
                      align-items: center;
                      height: inherit;
                      padding: 20px;
                      }
                      form {
                      width: 90%;
                      padding: 20px;
                      border-radius: 5px;
                      background: #fff;
                      box-shadow: 0 0 8px #006622; 
                      }
                      .banner {
                      position: relative;
                      height: 70px;
                      display: flex;
                      justify-content: center;
                      align-items: center;
                      text-align: center;
                      }
                      .banner::after {
                      content: "";
                      background-color: rgba(0, 0, 0, 0.4); 
                      position: absolute;
                      width: 100%;
                      height: 100%;
                      }
                      input, select, textarea {
                      margin-bottom: 10px;
                      border: 1px solid #ccc;
                      border-radius: 3px;
                      }
                      input {
                      width: calc(100% - 10px);
                      padding: 5px;
                      }
                      input[type="date"] {
                      padding: 4px 5px;
                      }
                      textarea {
                      width: calc(100% - 12px);
                      padding: 5px;
                      }
                      .item:hover p, .item:hover i, .question:hover p, .question label:hover, input:hover::placeholder {
                      color:  #006622;
                      }
                     
                    
                      .item {
                      position: relative;
                      margin: 3px 0;
                      }
                      .item span {
                      color: red;
                      }
                      .week {
                      display:flex;
                      justfiy-content:space-between;
                      }
                      .colums {
                      display:flex;
                      justify-content:space-between;
                      flex-direction:row;
                      flex-wrap:wrap;
                      }
                      .colums div {
                      width:48%;
                      }
                      input[type=radio], input[type=checkbox]  {
                      display: none;
                      }
                      label.radio {
                      position: relative;
                      display: inline-block;
                      margin: 5px 20px 15px 0;
                      cursor: pointer;
                      }
                      .question span {
                      margin-left: 30px;
                      }
                      .question-answer label {
                      display: block;
                      }
                      label.radio:before {
                      content: "";
                      position: absolute;
                      left: 0;
                      width: 5px;
                      height: 5px;
                      border-radius: 50%;
                      border: 2px solid #ccc;
                      }
                      input[type=radio]:checked + label:before, label.radio:hover:before {
                      border: 2px solid  #006622;
                      }

                      label{
                        font-weight: 500;
                        font-size: 15px;
                      }
                      
                    
                      .flax {
                      display:flex;
                      justify-content:space-around;
                      }
                      .btn-block {
                      margin-top: 10px;
                      text-align: center;
                      }
                      button {
                      width: 150px;
                      padding: 10px;
                      border: none;
                      border-radius: 5px; 
                      background:  #1c87c9;
                      font-size: 16px;
                      color: #fff;
                      cursor: pointer;
                      }
                      button:hover {
                      background:  #0692e8;
                      }
                      @media (min-width: 568px) {
                      .name-item, .city-item {
                      display: flex;
                      flex-wrap: wrap;
                      justify-content: space-between;
                      }
                      .name-item input, .name-item div {
                      width: calc(50% - 20px);
                      }
                      .name-item div input {
                      width:97%;}
                      .name-item div label {
                      display:block;
                      padding-bottom:5px;
                      }
                      }
                      .banner p{
                        margin-top:80px;
                        color: red;
                      }
                    </style>
                  </head>
                  <body>
                    <div class="testbox">
                    <form>
                      <div class="banner">
                       <h1>GAMA GUARD SERVICES PVT</h1>
                      </div>
                       <hr>
                        <p>Regd. Office: Ploat No. 35, Narayan Nagar, Near Bhopal Gas Agency, Hoshangabad Road,Bhopal M.P.  Phone: 0755-4004810,7898909920  E-mail: gssmpbpl@gmail.com</p>
                      <hr>
                      <br/>
                      <fieldset>
                        <legend>Personal Details</legend>
                        <div class="colums">
                          <div class="item">
                            <label for="fname">Employee Id<span>*</span> </label> 
                             <h2>'.$order_data['emp_id'].'</h2>
                             <label for="fname">Father Name<span>*</span> </label> 
                             <h2>'.$order_data['faname'].'</h2>
                          </div>
                          <div class="item">
                           <img alt="" src="../../../Gama_hrms/upload/Employee/'.$order_data['image'].'" style="width: 100px; height:100px;">
                          </div>
                          <div class="item">
                            <label for="address">Mother Name<span>*</span></label>
                             <h2>'.$order_data['moname'].'</h2>
                          </div>
                          <div class="item">
                            <label for="phone">Address <span>*</span> </label>
                            <h2>'.$order_data['addr'].'</h2>
                          </div>
                          <div class="item">
                            <label for="saddress">Address 2 <span>*</span> </label>
                             <h2>'.$order_data['addr2'].'</h2>
                          </div>
                          <div class="item">
                            <label for="country">Company Name<span>*</span> </label>
                           <h2>'.$data1[0]['cl_coname'].'</h2>
                          </div>
                          <div class="item">
                            <label for="city">City <span>*</span> </label>
                             <h2>'.$data2[0]['city'].'</h2>
                          </div>
                          <div class="item">
                            <label for="zip">Zone <span>*</span> </label>
                            <h2>'.$data3[0]['zone'].'</h2>
                          </div>
                          <div class="item">
                            <label for="country">Mobile<span>*</span> </label>
                           <h2>'.$order_data['cont'].'</h2>
                          </div>
                          <div class="item">
                            <label for="country">Gender <span>*</span> </label>
                           <h2>'.$order_data['gender'].'</h2>
                          </div>
                           <div class="item">
                            <label for="country">Date of Birth <span>*</span> </label>
                           <h2>'.$order_data['dob'].'</h2>
                          </div>
                           <div class="item">
                            <label for="country">Married Status<span>*</span> </label>
                           <h2>'.$order_data['mrg_status'].'</h2>
                          </div>
                        </div>
                      </fieldset>
                      <br/> <br/> <br/>
                      <fieldset>
                        <legend>Professional Details</legend>
                        <div class="colums">
                          <div class="item">
                            <label for="fname">UAN Number<span>*</span> </label> 
                             <h2>'.$order_data['lname'].'</h2>
                          </div>
                          <div class="item"> 
                            <label for="lname">ESIC Number<span>*</span></label>
                             <h2>'.$order_data['esic_num'].'</h2>
                          </div>
                          <div class="item">
                            <label for="address">Education<span>*</span></label>
                             <h2>'.$order_data['faname'].'   '.$order_data['faname'].' </h2> 
                          </div>
                          <div class="item">
                            <label for="phone">Adhar Number <span>*</span></label>
                            <h2>'.$order_data['adhar_num'].'</h2>
                          </div>
                          <div class="item">
                            <label for="saddress">Pan Number <span>*</span></label>
                             <h2>'.$order_data['pan_num'].'</h2>
                          </div>
                        </div>  
                      </fieldset>
                       <br/>
                      <fieldset>
                        <legend>Bank Details</legend>
                        <div class="colums">
                          <div class="item"> 
                            <label for="lname">Bank Name<span>*</span></label>
                             <h2>'.$order_data['bank_name'].'</h2>
                          </div>
                          <div class="item">
                            <label for="address">Holder Name<span>*</span></label>
                             <h2>'.$order_data['ac_name'].'</h2>
                          </div>
                          <div class="item">
                            <label for="phone">Account Number</label>
                            <h2>'.$order_data['ac_no'].'</h2>
                          </div>
                          <div class="item">
                            <label for="saddress">IFSCI Code</label>
                             <h2>'.$order_data['ifsc'].'</h2>
                          </div>
                        </div>  
                      </fieldset>
                       <fieldset>
                        <legend>Family Details</legend>
                        <div class="colums">
                         <table class="table table-hover table-active" id="dynamic_field1">  
                    <thead class="f1">
                      <tr>
                         <th scope="col" class="f2">Member Name</th>
                         <th scope="col" class="f2">Member relation</th>
                         <th scope="col" class="f2">Contact</th>
                      </tr>
                    </thead>
                     <tbody class="thead-light"> ';
                      
                        $i=0;
                        foreach ($mem_nm as $key1)
                        {
                          $but = "";
                          $j = $i+1;
                          
                          $html .='
                          <thead>
                          <tr id="row'.$i.'">
                            <td> <h2>'.$key1.'</h2></td>
                            <td> <h2>'.$mem_rel[$i].'</h2></td>
                            <td> <h2>'.$mem_con[$i].'</h2></td>
                          </tr>
                          </thead>
                          ';
                          $i++;
                        }
                      $html .='
                    </tbody>
                  </table> 
                        </div>  
                      </fieldset>
                     <div class="btn-block">
                      <button onclick="window.print();return false;" type="" href="/"><i class="fas fa-print"></i></button>
                    </div>
                    </form>
                    </div>
                     
                  </body>
                </html>';
            echo $html;
        }
    }
    
   public function Print_attandance($id)
     {
        
        $attend_data = $this->Admin_model->get_emp_atd_data($id); 
        
        $attend_data = $this->Admin_model->get_emp_atd_data($id); 
         $ab1 = explode('-_-', $attend_data['absent_detail']);
                $ab_day = array();
                $ab_det = array();
          for ($i=0; $i < $attend_data['absent_days'] ; $i++)
          { 
           $ab2 = explode('-', $ab1[$i]);
           array_push($ab_day, $ab2[0]);
           array_push($ab_det, $ab2[1]);
          }
        
         


         $attend_days =  $attend_data['month_days']-$attend_data['absent_days'];
         $vend_id = $attend_data['emp_id'];
         $data2 = $this->Admin_model->get_emp($vend_id);
         
        $vend_id = $data2['city'];
        $city = $this->Admin_model->comapare($vend_id);
         
        $vend_id3 = $data2['zone'];
        $zone = $this->Admin_model->comapare_zone($vend_id3);
         
       

           
        $html = '<!-- Main content -->
         <!DOCTYPE html>
        <html>
          <head>
            <title>GAMA Attandance Slip</title>
            <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
            <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
            <style>
              html, body {
              min-height: 90%;
              }
              body, div, form, input, select, textarea, label { 
              padding: 0;
              margin: 0;
              outline: none;
              font-family: Roboto, Arial, sans-serif;
              font-size: 14px;
              color: #666;
              line-height: 22px;
              }
              h1 {
              position: absolute;
              margin:0;
              font-size: 30px;
              color: #fff;
              z-index: 2;
              line-height: 83px;
              top:10px;
              }
              legend {
              padding: 10px;      
              font-family: Roboto, Arial, sans-serif;
              font-size: 18px;
              color: #fff;
              background-color: #1c87c9;
              }
              textarea {
              width: calc(100% - 12px);
              padding: 5px;
              }
              .testbox {
              display: flex;
              justify-content: center;
              align-items: center;
              height: inherit;
              padding: 20px;
              }
              form {
              width: 90%;
              padding: 20px;
              border-radius: 5px;
              background: #fff;
              box-shadow: 0 0 8px #006622; 
              }
              .banner {
              position: relative;
              height: 100px;
              display: flex;
              justify-content: center;
              align-items: center;
              text-align: center;
              }
              .banner::after {
              content: "";
              background-color: rgba(0, 0, 0, 0.4); 
              position: absolute;
              width: 100%;
              height: 100%;
              }
              input, select, textarea {
              margin-bottom: 10px;
              border: 1px solid #ccc;
              border-radius: 3px;
              }
              input {
              width: calc(100% - 10px);
              padding: 5px;
              }
              input[type="date"] {
              padding: 4px 5px;
              }
              textarea {
              width: calc(100% - 12px);
              padding: 5px;
              }
              .item:hover p, .item:hover i, .question:hover p, .question label:hover, input:hover::placeholder {
              color:  #006622;
              }
              .item {
              position: relative;
              margin: 3px 0;
              }
              .item span {
              color: red;
              }
              .week {
              display:flex;
              justfiy-content:space-between;
              }
              .colums {
              display:flex;
              justify-content:space-between;
              flex-direction:row;
              flex-wrap:wrap;
              }
              .colums div {
              width:48%;
              }
              input[type=radio], input[type=checkbox]  {
              display: none;
              }
              label.radio {
              position: relative;
              display: inline-block;
              margin: 5px 20px 15px 0;
              cursor: pointer;
              }
              .question span {
              margin-left: 30px;
              }
              .question-answer label {
              display: block;
              }
              label.radio:before {
              content: "";
              position: absolute;
              left: 0;
              width: 5px;
              height: 5px;
              border-radius: 50%;
              border: 2px solid #ccc;
              }
              input[type=radio]:checked + label:before, label.radio:hover:before {
              border: 2px solid  #006622;
              }

              label{
                font-weight: 500;
                font-size: 15px;
              }
              
            
              .flax {
              display:flex;
              justify-content:space-around;
              }
              .btn-block {
              margin-top: 10px;
              text-align: center;
              }
              button {
              width: 150px;
              padding: 10px;
              border: none;
              border-radius: 5px; 
              background:  #1c87c9;
              font-size: 16px;
              color: #fff;
              cursor: pointer;
              }
              button:hover {
              background:  #0692e8;
              }
              @media (min-width: 568px) {
              .name-item, .city-item {
              display: flex;
              flex-wrap: wrap;
              justify-content: space-between;
              }
              .name-item input, .name-item div {
              width: calc(50% - 20px);
              }
              .name-item div input {
              width:97%;}
              .name-item div label {
              display:block;
              padding-bottom:5px;
              }
              }
              .banner p{
                margin-top:80px;
                color: red;
              }
            </style>
          </head>
          <body>
            <div class="testbox">
            <form>

              <div class="banner">
                <img src="../../../Gama_hrms/upload/logo.png" style="width: 50px; height: 50px; "><h1>GAMA GUARD SERVICES PVT</h1>
              </div>
              <br/>
              <fieldset>
                <legend>Information</legend>
                <div class="colums">
                  <div class="item">
                    <label for="fname"><span>*</span>Name of Contractors -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;'.$attend_data['cmp_name'].'</label> 
                  </div>
                  <div class="item">
                    <label for="fname"><span>*</span>Name of Principal Employee -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;'.$data2['fname'].'</label>
                  </div>
                  <div class="item">
                    <label for="fname"><span>*</span>Location of Work -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;'.$city[0]['city'].'&nbsp;,&nbsp;'.$zone[0]['zone'].'</label> 
                  </div>
                  <div class="item">
                    <label for="fname"><span>*</span>Wages Period -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;'.$attend_data['month'].'/'.$attend_data['year'].'</label>
                  </div>
                  <div class="item">
                    <label for="fname"><span>*</span> First Name -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;</label> 
                  </div>
                  <div class="item">
                    <label for="fname"><span>*</span> From -&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;</label>
                    <label for="fname"><span>*</span> To -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;</label>
                  </div>
                </div>
              </fieldset><br><br><br>
               <table class="table table-bordered" id="table_nodisp1" border="1">
                                  <thead>
                                      <tr>
                                          <th class="center">S.no</th>
                                          <th class="center">emp code</th>
                                          <th class="center">Name</th>
                                          <th class="center">designation</th>';
                                          for ($i=1; $i <= $attend_data['month_days']; $i++) 
                                          { 
                                              $html .='<th> '.$i.' </th>';
                                          }
                                         
                                           $html .='<th class="center">total</th>
                                          <th class="center">Signature</th>
                                      </tr>
                                  </thead>
                                  <tbody id="nodisp_out">
                                    <tr>
                                       <td>01</td>  
                                       <td>'.$attend_data['emp_code'].'</td>  
                                       <td>'.$attend_data['emp_name'].'</td>  
                                       <td>'.$data2['desg'].'</td>';
                                        $j=0;
                                       $l=1;

                                        for ($i=0,$day = 1; $i < $attend_data['month_days']; $i++,$day++) 
                                        { 
                                          
                                        if (in_array($day, $ab_day))
                                        {
                                          $pos = array_search($day, $ab_day);
                                            $html .='<td id="'.$i.'">'.$ab_det[$pos].'</td>';
                                          }
                                          else{
                                             $html .='<td id="'.$i.'">P</td>';
                                          }

                                            
                                        }
                                       $html .='
                                       <td>'.$attend_days.'</td>  
                                    </tr>
                                  </tbody>
                            </table>
              <br/> <br/>
             
             <div class="btn-block">
              <button onclick="window.print();return false;" type="" href="/"><i class="fas fa-print"></i></button>
            </div>
            </form>
            </div>
             
          </body>
        </html>';
          echo $html;
      
     }
     
      public function Print_atndby_mnth($id)
     {
        $data = $this->Admin_model->get_atdby_month($id);
        $ad = $data[0]['month_days'];


      
        foreach ($data as $key) {
            
         $attend_days =  $key['month_days']-$key['absent_days'];
         $vend_id = $key['emp_id'];
         $data2 = $this->Admin_model->get_emp($vend_id);


         $ab1 = explode('-_-', $key['absent_detail']);
           $ab_day = array();
            $ab_det = array();
          for ($i=0; $i < $key['absent_days'] ; $i++)
          { 
           $ab2 = explode('-', $ab1[$i]);
           array_push($ab_day, $ab2[0]);
           array_push($ab_det, $ab2[1]);
          }

        
           
        $html = '<!-- Main content -->
         <!DOCTYPE html>
        <html>
          <head>
            <title>GAMA Attandance Slip</title>
            <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
            <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
            <style>
              html, body {
              min-height: 90%;
              }
              body, div, form, input, select, textarea, label { 
              padding: 0;
              margin: 0;
              outline: none;
              font-family: Roboto, Arial, sans-serif;
              font-size: 14px;
              color: #666;
              line-height: 22px;
              }
              h1 {
              position: absolute;
              margin:0;
              font-size: 30px;
              color: #fff;
              z-index: 2;
              line-height: 83px;
              top:10px;
              }
              legend {
              padding: 10px;      
              font-family: Roboto, Arial, sans-serif;
              font-size: 18px;
              color: #fff;
              background-color: #1c87c9;
              }
              textarea {
              width: calc(100% - 12px);
              padding: 5px;
              }
              .testbox {
              display: flex;
              justify-content: center;
              align-items: center;
              height: inherit;
              padding: 20px;
              }
              form {
              width: 90%;
              padding: 20px;
              border-radius: 5px;
              background: #fff;
              box-shadow: 0 0 8px #006622; 
              }
              .banner {
              position: relative;
              height: 100px;
              display: flex;
              justify-content: center;
              align-items: center;
              text-align: center;
              }
              .banner::after {
              content: "";
              background-color: rgba(0, 0, 0, 0.4); 
              position: absolute;
              width: 100%;
              height: 100%;
              }
              input, select, textarea {
              margin-bottom: 10px;
              border: 1px solid #ccc;
              border-radius: 3px;
              }
              input {
              width: calc(100% - 10px);
              padding: 5px;
              }
              input[type="date"] {
              padding: 4px 5px;
              }
              textarea {
              width: calc(100% - 12px);
              padding: 5px;
              }
              .item:hover p, .item:hover i, .question:hover p, .question label:hover, input:hover::placeholder {
              color:  #006622;
              }
              .item {
              position: relative;
              margin: 3px 0;
              }
              .item span {
              color: red;
              }
              .week {
              display:flex;
              justfiy-content:space-between;
              }
              .colums {
              display:flex;
              justify-content:space-between;
              flex-direction:row;
              flex-wrap:wrap;
              }
              .colums div {
              width:48%;
              }
              input[type=radio], input[type=checkbox]  {
              display: none;
              }
              label.radio {
              position: relative;
              display: inline-block;
              margin: 5px 20px 15px 0;
              cursor: pointer;
              }
              .question span {
              margin-left: 30px;
              }
              .question-answer label {
              display: block;
              }
              label.radio:before {
              content: "";
              position: absolute;
              left: 0;
              width: 5px;
              height: 5px;
              border-radius: 50%;
              border: 2px solid #ccc;
              }
              input[type=radio]:checked + label:before, label.radio:hover:before {
              border: 2px solid  #006622;
              }

              label{
                font-weight: 500;
                font-size: 15px;
              }
              
            
              .flax {
              display:flex;
              justify-content:space-around;
              }
              .btn-block {
              margin-top: 10px;
              text-align: center;
              }
              button {
              width: 150px;
              padding: 10px;
              border: none;
              border-radius: 5px; 
              background:  #1c87c9;
              font-size: 16px;
              color: #fff;
              cursor: pointer;
              }
              button:hover {
              background:  #0692e8;
              }
              @media (min-width: 568px) {
              .name-item, .city-item {
              display: flex;
              flex-wrap: wrap;
              justify-content: space-between;
              }
              .name-item input, .name-item div {
              width: calc(50% - 20px);
              }
              .name-item div input {
              width:97%;}
              .name-item div label {
              display:block;
              padding-bottom:5px;
              }
              }
              .banner p{
                margin-top:80px;
                color: red;
              }
            </style>
          </head>
          <body>
            <div class="testbox">
            <form>

              <div class="banner">
                <img src="../../../Gama_hrms/upload/logo.png" style="width: 50px; height: 50px; "><h1>GAMA GUARD SERVICES PVT</h1>
              </div>
              <br/>
             
                <div class="colums">
                  <div class="item">
                    <label for="fname"><span>*</span>Name of Contractors -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;</label> 
                  </div>
                  <div class="item">
                    <label for="fname"><span>*</span>Name of Principal Employee -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;</label>
                  </div>
                  <div class="item">
                    <label for="fname"><span>*</span>Location of Work -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;</label> 
                  </div>
                  <div class="item">
                    <label for="fname"><span>*</span>Wages Period -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;</label>
                  </div>
                  <div class="item">
                    <label for="fname"><span>*</span> First Name -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;</label> 
                  </div>
                  <div class="item">
                    <label for="fname"><span>*</span> From -&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;</label>
                    <label for="fname"><span>*</span> To -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;</label>
                  </div>
                </div>
             <br><br><br>
              <table class="table table-bordered" id="table_nodisp1" border="1">
                 <thead>';
                      foreach ($data as $key) 
                       {
                        
                           $attend_days =  $key['month_days']-$key['absent_days'];
                           $vend_id = $key['emp_id'];
                           $data2 = $this->Admin_model->get_emp($vend_id);


                           $ab1 = explode('-_-', $key['absent_detail']);
                        
                          $ab_day = array();
                          $ab_det = array();
                            for ($i=0; $i < $key['absent_days'] ; $i++)
                            { 
                               $ab2 = explode('-', $ab1[$i]);
                               array_push($ab_day, $ab2[0]);
                               array_push($ab_det, $ab2[1]);
                            }
                       
                          '<tr>
                            <th class="center">S.no</th>
                            <th class="center">emp code</th>
                            <th class="center">Name</th>
                            <th class="center">designation</th>
                            <th class="center">total</th>
                            <th class="center">Signature</th>
                        </tr>
                    </thead>
                    <tbody id="nodisp_out">
                    <tr>
                             <td>01</td>  
                             <td>'.$key['emp_code'].'</td>  
                             <td>'.$key['emp_name'].'</td>  
                             <td>'.$data2['desg'].'</td>';
                             $j=0;
                             $l=1;
                             
                              for ($i=0,$day = 1; $i < $ad; $i++,$day++) 
                              { 
                                
                                if (in_array($day, $ab_day))
                                {
                                  $pos = array_search($day, $ab_day);
                                  $html .='<td id="'.$i.'">'.$ab_det[$pos].'</td>';
                                }
                                else{
                                   $html .='<td id="'.$i.'">P</td>';
                                }

                                  
                              }
                             $html .='
                             <td>'.$attend_days.'</td>  
                          </tr></tbody>';
                           }
               '</table>
              <br/> <br/>
             
             <div class="btn-block">
              <button onclick="window.print();return false;" type="" href="/"><i class="fas fa-print"></i></button>
            </div>
            </form>
            </div>
             
          </body>
        </html>';
         }
          echo $html;
      
     }
     
     
     /*Client Info*/
     
    function printClientInfo($id)
    {
   
        if($id)
        {
            $client_data = $this->Admin_model->get_client_avail($id);

               $vend_id = $client_data['cl_city'];
              $data2 = $this->Admin_model->comapare($vend_id);
        
              $html = '<!-- Main content -->
                <!DOCTYPE html>
                <html>
                  <head>
                    <title>Gama Guard Client Form</title>
                    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
                    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
                    <style>
                      html, body {
                      min-height: 90%;
                      }
                      body, div, form, input, select, textarea, label { 
                      padding: 0;
                      margin: 0;
                      outline: none;
                      font-family: Roboto, Arial, sans-serif;
                      font-size: 14px;
                      color: #666;
                      line-height: 22px;
                      }
                      h1 {
                      position: absolute;
                      margin:0;
                      font-size: 30px;
                      color: #fff;
                      z-index: 2;
                      line-height: 83px;
                      
                      }
                      legend {
                      padding: 10px;      
                      font-family: Roboto, Arial, sans-serif;
                      font-size: 18px;
                      color: #fff;
                      background-color: #1c87c9;
                      }
                      textarea {
                      width: calc(100% - 12px);
                      padding: 5px;
                      }
                      .testbox {
                      display: flex;
                      justify-content: center;
                      align-items: center;
                      height: inherit;
                      padding: 20px;
                      }
                      form {
                      width: 90%;
                      padding: 20px;
                      border-radius: 5px;
                      background: #fff;
                      box-shadow: 0 0 8px #006622; 
                      }
                      .banner {
                      position: relative;
                      height: 70px;
                      display: flex;
                      justify-content: center;
                      align-items: center;
                      text-align: center;
                      }
                      .banner::after {
                      content: "";
                      background-color: rgba(0, 0, 0, 0.4); 
                      position: absolute;
                      width: 100%;
                      height: 100%;
                      }
                      input, select, textarea {
                      margin-bottom: 10px;
                      border: 1px solid #ccc;
                      border-radius: 3px;
                      }
                      input {
                      width: calc(100% - 10px);
                      padding: 5px;
                      }
                      input[type="date"] {
                      padding: 4px 5px;
                      }
                      textarea {
                      width: calc(100% - 12px);
                      padding: 5px;
                      }
                      .item:hover p, .item:hover i, .question:hover p, .question label:hover, input:hover::placeholder {
                      color:  #006622;
                      }
                     
                    
                      .item {
                      position: relative;
                      margin: 3px 0;
                      }
                      .item span {
                      color: red;
                      }
                      .week {
                      display:flex;
                      justfiy-content:space-between;
                      }
                      .colums {
                      display:flex;
                      justify-content:space-between;
                      flex-direction:row;
                      flex-wrap:wrap;
                      }
                      .colums div {
                      width:48%;
                      }
                      input[type=radio], input[type=checkbox]  {
                      display: none;
                      }
                      label.radio {
                      position: relative;
                      display: inline-block;
                      margin: 5px 20px 15px 0;
                      cursor: pointer;
                      }
                      .question span {
                      margin-left: 30px;
                      }
                      .question-answer label {
                      display: block;
                      }
                      label.radio:before {
                      content: "";
                      position: absolute;
                      left: 0;
                      width: 5px;
                      height: 5px;
                      border-radius: 50%;
                      border: 2px solid #ccc;
                      }
                      input[type=radio]:checked + label:before, label.radio:hover:before {
                      border: 2px solid  #006622;
                      }

                      label{
                        font-weight: 500;
                        font-size: 15px;
                      }
                      
                    
                      .flax {
                      display:flex;
                      justify-content:space-around;
                      }
                      .btn-block {
                      margin-top: 10px;
                      text-align: center;
                      }
                      button {
                      width: 150px;
                      padding: 10px;
                      border: none;
                      border-radius: 5px; 
                      background:  #1c87c9;
                      font-size: 16px;
                      color: #fff;
                      cursor: pointer;
                      }
                      button:hover {
                      background:  #0692e8;
                      }
                      @media (min-width: 568px) {
                      .name-item, .city-item {
                      display: flex;
                      flex-wrap: wrap;
                      justify-content: space-between;
                      }
                      .name-item input, .name-item div {
                      width: calc(50% - 20px);
                      }
                      .name-item div input {
                      width:97%;}
                      .name-item div label {
                      display:block;
                      padding-bottom:5px;
                      }
                      }
                      .banner p{
                        margin-top:80px;
                        color: red;
                      }
                    </style>
                  </head>
                  <body>
                    <div class="testbox">
                    <form>
                      <div class="banner">
                       <h1>GAMA GUARD SERVICES PVT</h1>
                      </div>
                       
                      <br/>
                      <fieldset>
                        <legend>Personal Details</legend>
                        <div class="colums">
                         <div class="item">
                           <img alt="" src="../../../Gama_hrms/upload/client/'.$client_data['client_logo'].'" style="width: 100px; height:100px;">
                          </div>
                          <div class="item">
                            <label for="fname">Client Name<span>*</span> </label> 
                             <h2>'.$client_data['cl_name'].'</h2>
                             <label for="fname">Company Name<span>*</span> </label> 
                             <h2>'.$client_data['cl_coname'].'</h2>
                          </div>
                          <div class="item">
                            <label for="address">Contact Number<span>*</span></label>
                             <h2>'.$client_data['cl_cont'].'</h2>
                          </div>
                          <div class="item">
                            <label for="phone">Address <span>*</span> </label>
                            <h2>'.$client_data['cl_address'].'</h2>
                          </div>
                          <div class="item">
                            <label for="phone">City <span>*</span> </label>
                            <h2>'.$data2[0]['city'].'</h2>
                          </div>
                          <div class="item">
                            <label for="phone">Strength <span>*</span> </label>
                            <h2>'.$client_data['cl_noemp'].'</h2>
                          </div>
                            <div class="item">
                            <label for="phone">GSTIN <span>*</span> </label>
                            <h2>'.$client_data['cl_gst'].'</h2>
                          </div>
                            <div class="item">
                            <label for="phone">Agreement No.<span>*</span> </label>
                            <h2>'.$client_data['cl_agno'].'</h2>
                          </div>
                          <div class="item">
                            <label for="phone">Laber Licence No<span>*</span> </label>
                            <h2>'.$client_data['laber_no'].'</h2>
                          </div>
                           <div class="item">
                            <label for="phone">Agreement Start Date<span>*</span> </label>
                            <h2>'.$client_data['cl_agri_stdate'].'</h2>
                          </div>
                          <div class="item">
                            <label for="phone">Agreement End Date<span>*</span> </label>
                            <h2>'.$client_data['cl_agri_enddate'].'</h2>
                          </div>
                          <div class="item">
                            <label for="phone">Work Order Number<span>*</span> </label>
                            <h2>'.$client_data['work_order_no'].'</h2>
                          </div>
                         
                      </fieldset>
                     <div class="btn-block">
                      <button onclick="window.print();return false;" type="" href="/"><i class="fas fa-print"></i></button>
                    </div>
                    </form>
                    </div>
                     
                  </body>
                </html>';
            echo $html;
        }
    }









}?>