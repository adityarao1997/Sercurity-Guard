<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	/**
	 *  Index Page for this controller.
	 */
    
    function __construct()
    {
        parent::__construct();
        $this->load->model('SAdmin_model');
        $this->load->model('Login_model');
        $this->load->model('Admin_model');
                
    }
   /*
    *  Dashboard Index
    */
    function index()
    {
       if(!$this->session->userdata('id'))
         {
            return redirect('Login');
         }else{
                   $this->load->view('SubAdmin/Dashboard/index');
              }
             
    }
   function access_ajax_other()
  {
      $data['_view'] = 'SubAdmin/Layout/function';
     $this->load->view('SubAdmin/Layout/function',$data);
  }

      /*Employeee  Start*/
      function All_Employee()
      {    
        $params['limit'] = 'RECORDS_PER_PAGE'; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('SubAdmin/Employee/Viewemp');
        $config['total_rows'] = $this->SAdmin_model->get_all_emp_count();
        $this->pagination->initialize($config);

        $data['emp_data'] = $this->SAdmin_model->get_all_empList($params);
        
      
        $data['cur_page'] = "dashboard";
        $data['main_page'] = "All_Client";
        $data['_view'] =  'SubAdmin/Employee/Viewemp';
        $this->load->view('SubAdmin/Employee/Viewemp',$data);
      }

      function Create_Employee()
      {    
        
       if( $this->input->post('upload') )    // if form is posted
        {
          $Login_id = $this->session->userdata('id'); 
          $this->form_validation->set_rules('fname','fname','required');
          $this->form_validation->set_rules('lname','lname','required');
          $this->form_validation->set_rules('esic_num','esic_num','required');
          $this->form_validation->set_rules('faname','faname','required');
          $this->form_validation->set_rules('moname','moname','required');
          $this->form_validation->set_rules('addr','addr','required');
          $this->form_validation->set_rules('addr2','addr2','required');
          $this->form_validation->set_rules('desg','desg','required');
          $this->form_validation->set_rules('gender','gender','required');
          $this->form_validation->set_rules('cont','cont','required');
          $this->form_validation->set_rules('dob','dob','required');
          $this->form_validation->set_rules('jdate','jdate','required');
          $this->form_validation->set_rules('ac_no','ac_no','required');
          $this->form_validation->set_rules('ac_name','ac_name','required');
          $this->form_validation->set_rules('ifsc','ifsc','required');
          $this->form_validation->set_rules('bank_name','bank_name','required');
          $this->form_validation->set_rules('loc_type','loc_type','required');
          $this->form_validation->set_rules('co_name','co_name','required');
          $this->form_validation->set_rules('zone','zone','required');
          $this->form_validation->set_rules('med_cer','med_cer','required');
          $this->form_validation->set_rules('polic_ver','polic_ver','required');
          $this->form_validation->set_rules('polic_case','polic_case','required');
          $this->form_validation->set_rules('nationality','nationality','required');
          $this->form_validation->set_rules('mrg_status','mrg_status','required');
          $this->form_validation->set_rules('adhar_num','adhar_num','required');
          $this->form_validation->set_rules('pan_num','pan_num','required');
           
          $fname = $this->input->post('fname');
          $lname = $this->input->post('lname');
          $esic_num = $this->input->post('esic_num');
          $faname = $this->input->post('faname');
          $moname = $this->input->post('moname');
          $addr = $this->input->post('addr');
          $addr2 = $this->input->post('addr2');
          $desg = $this->input->post('desg');
          $gender = $this->input->post('gender');
          $cont = $this->input->post('cont');
          $dob = $this->input->post('dob');
          $jdate = $this->input->post('jdate');
          $ac_no = $this->input->post('ac_no');
          $ac_name = $this->input->post('ac_name');
          $ifsc = $this->input->post('ifsc');
          $bank_name = $this->input->post('bank_name');
          $loc_type = $this->input->post('loc_type');
          $city = $this->input->post('city');
          $co_name = $this->input->post('co_name');
          $zone = $this->input->post('zone');
          $med_cer = $this->input->post('med_cer');
          $polic_ver = $this->input->post('polic_ver');
          $polic_case = $this->input->post('polic_case');
          $nationality = $this->input->post('nationality');
          $mrg_status = $this->input->post('mrg_status');
          $adhar_num = $this->input->post('adhar_num');
          $pan_num = $this->input->post('pan_num');
          $Login_id = $this->input->post('Login_id');

          $image = "";
          $adhar = "";
          $passbook = "";
          $pan_up = "";
          $ten_mask = "";
          $twl_mark = "";
          $medcer_pic = "";
          $policcer_pic = "";

          $config['upload_path'] = './upload/Employee/';
          $config['allowed_types'] = 'jpg|png|jpeg|gif';


          if($_FILES["image"]["name"] != "")
           {
             $image_ext2 = explode('.', $_FILES["image"]["name"]);
             $image_ext2 = end($image_ext2);
             $image = 'Employee-Image'.uniqid().date('Y-m-d');
             $config['file_name']= $image;  
             $this->load->library('upload', $config);  
             $this->lets_upload_employee('image');
            $image = $image.'.'.$image_ext2;
           }

           if($_FILES["adhar"]["name"] != "")
           {
             $adhar_ext2 = explode('.', $_FILES["adhar"]["name"]);
             $adhar_ext2 = end($adhar_ext2);
             $adhar = 'Adhar-pic'.uniqid().date('Y-m-d');
             $config['file_name']= $adhar;  
             $this->upload->initialize($config);  
             $this->load->library('upload', $config);  
             $this->lets_upload_employee('adhar');
            $adhar = $adhar.'.'.$adhar_ext2;
           }
           if($_FILES["passbook"]["name"] != "")
           {
             $passbook_ext2 = explode('.', $_FILES["passbook"]["name"]);
             $passbook_ext2 = end($passbook_ext2);
             $passbook = 'BankPassbook'.uniqid().date('Y-m-d');
             $config['file_name']= $passbook;  
             $this->upload->initialize($config);  
             $this->load->library('upload', $config);  
             $this->lets_upload_employee('passbook');
            $passbook = $passbook.'.'.$passbook_ext2;
           }
           if($_FILES["pan_up"]["name"] != "")
           {
             $pan_up_ext2 = explode('.', $_FILES["pan_up"]["name"]);
             $pan_up_ext2 = end($pan_up_ext2);
             $pan_up = 'PanCard'.uniqid().date('Y-m-d');
             $config['file_name']= $pan_up;  
             $this->upload->initialize($config);  
             $this->load->library('upload', $config);  
             $this->lets_upload_employee('pan_up');
            $pan_up = $pan_up.'.'.$pan_up_ext2;
           }
           if($_FILES["ten_mask"]["name"] != "")
           {
             $ten_mask_ext2 = explode('.', $_FILES["ten_mask"]["name"]);
             $ten_mask_ext2 = end($ten_mask_ext2);
             $ten_mask = 'MarkTen'.uniqid().date('Y-m-d');
             $config['file_name']= $ten_mask;  
             $this->upload->initialize($config);  
             $this->load->library('upload', $config);  
             $this->lets_upload_employee('ten_mask');
            $ten_mask = $ten_mask.'.'.$ten_mask_ext2;
           }
           if($_FILES["twl_mark"]["name"] != "")
           {
             $twl_mark_ext2 = explode('.', $_FILES["twl_mark"]["name"]);
             $twl_mark_ext2 = end($twl_mark_ext2);
             $twl_mark = 'MarkTwl'.uniqid().date('Y-m-d');
             $config['file_name']= $twl_mark;  
             $this->upload->initialize($config);  
             $this->load->library('upload', $config);  
             $this->lets_upload_employee('twl_mark');
            $twl_mark = $twl_mark.'.'.$twl_mark_ext2;
           }
            if($_FILES["medcer_pic"]["name"] != "")
           {
             $medcer_pic_ext2 = explode('.', $_FILES["medcer_pic"]["name"]);
             $medcer_pic_ext2 = end($medcer_pic_ext2);
             $medcer_pic = 'mediclCer'.uniqid().date('Y-m-d');
             $config['file_name']= $medcer_pic;  
             $this->upload->initialize($config);  
             $this->load->library('upload', $config);  
             $this->lets_upload_employee('medcer_pic');
            $medcer_pic = $medcer_pic.'.'.$medcer_pic_ext2;
           }
            if($_FILES["policcer_pic"]["name"] != "")
           {
             $policcer_pic_ext2 = explode('.', $_FILES["policcer_pic"]["name"]);
             $policcer_pic_ext2 = end($policcer_pic_ext2);
             $policcer_pic = 'Policeer'.uniqid().date('Y-m-d');
             $config['file_name']= $policcer_pic;  
             $this->upload->initialize($config);  
             $this->load->library('upload', $config);  
             $this->lets_upload_employee('policcer_pic');
            $policcer_pic = $policcer_pic.'.'.$policcer_pic_ext2;
           }
            $mem_nm = '';
             $mem_rel = '';
             $mem_con ='';
              foreach ($this->input->post('mem_nm') as $key => $value) 
              {
                if($mem_nm == "")
                {
                    $mem_nm =  $value["mem_nm"];
                }
                else
                {
                    $mem_nm .= ','.$value["mem_nm"];
                }
              
              }
               foreach ($this->input->post('mem_rel') as $key => $value) 
              {
                if($mem_rel == "")
                {
                    $mem_rel =  $value["mem_rel"];
                }
                else
                {
                    $mem_rel .= ','.$value["mem_rel"];
                }
              
              }
              foreach ($this->input->post('mem_con') as $key => $value) 
              {
                if($mem_con == "")
                {
                    $mem_con =  $value["mem_con"];
                }
                else
                {
                    $mem_con .= ','.$value["mem_con"];
                }
              
              }
             if($this->SAdmin_model->add_employee($fname,$lname,$esic_num,$faname,$moname,$addr,$addr2,$desg,$gender,$cont,$dob,$jdate,$ac_no,$ac_name,$ifsc,$bank_name,$loc_type,$city,$co_name,$zone,$mem_nm,$mem_rel,$mem_con,$med_cer,$polic_ver,$polic_case,$nationality,$mrg_status,$adhar_num,$pan_num,$image,$adhar,$passbook,$pan_up,$ten_mask,$twl_mark,$medcer_pic,$policcer_pic,$Login_id))
             {
                
                  return redirect('Dashboard/All_Employee');
             }else
              {
                   $this->load->view('SubAdmin/Employee/Addemp');
              }
             
        } 
        $data['cur_page'] = "dashboard";
         $data['all_city_type'] = $this->SAdmin_model->get_all_city_type('city');
         $data['all_cmp_type'] = $this->SAdmin_model->get_all_comp_type();
         $data['all_zone_type'] = $this->SAdmin_model->get_all_zone_type();
        $data['_view'] =  'SubAdmin/Employee/Addemp';
        $this->load->view('SubAdmin/Employee/Addemp',$data);
      }

      function Employee_Edit($id)
      {
        $data['emp_ad'] = $this->SAdmin_model->get_emp($id);

        if(isset($data['emp_ad']['id']))
        {

          $this->form_validation->set_rules('fname','fname','required');
          $this->form_validation->set_rules('lname','lname','required');
          $this->form_validation->set_rules('esic_num','esic_num','required');
          $this->form_validation->set_rules('faname','faname','required');
          $this->form_validation->set_rules('moname','moname','required');
          $this->form_validation->set_rules('addr','addr','required');
          $this->form_validation->set_rules('addr2','addr2','required');
          $this->form_validation->set_rules('desg','desg','required');
          $this->form_validation->set_rules('gender','gender','required');
          $this->form_validation->set_rules('cont','cont','required');
          $this->form_validation->set_rules('dob','dob','required');
          $this->form_validation->set_rules('ac_no','ac_no','required');
          $this->form_validation->set_rules('ac_name','ac_name','required');
          $this->form_validation->set_rules('ifsc','ifsc','required');
          $this->form_validation->set_rules('bank_name','bank_name','required');
          $this->form_validation->set_rules('loc_type','loc_type','required');
          $this->form_validation->set_rules('co_name','co_name','required');
          $this->form_validation->set_rules('zone','zone','required');
          $this->form_validation->set_rules('mem_nm','mem_nm','required');
          $this->form_validation->set_rules('mem_rel','mem_rel','required');
          $this->form_validation->set_rules('mem_lvng','mem_lvng','required');
          $this->form_validation->set_rules('mem_con','mem_con','required');
          $this->form_validation->set_rules('med_cer','med_cer','required');
          $this->form_validation->set_rules('polic_ver','polic_ver','required');
          $this->form_validation->set_rules('polic_case','polic_case','required');
          $this->form_validation->set_rules('nationality','nationality','required');
          $this->form_validation->set_rules('mrg_status','mrg_status','required');
          $this->form_validation->set_rules('adhar_num','adhar_num','required');
          $this->form_validation->set_rules('pan_num','pan_num','required');

          if($this->form_validation->run())     
          {  
            $image = $data['emp_ad']['image'];
            $adhar = $data['emp_ad']['adhar'];
            $passbook = $data['emp_ad']['passbook'];
            $pan_up = $data['emp_ad']['pan_up'];
            $ten_mask = $data['emp_ad']['ten_mask'];
            $twl_mark = $data['emp_ad']['twl_mark'];
            $medcer_pic = $data['emp_ad']['medcer_pic'];
            $policcer_pic = $data['emp_ad']['policcer_pic'];
           
            $config['upload_path'] = './upload/Employee/';                        
            $config['allowed_types'] = 'jpg|png|jpeg|gif';
            $this->load->library('upload');
            
            if(isset($_FILES["image"]['tmp_name']))
            {
              if(file_exists($_FILES["image"]['tmp_name']) || is_uploaded_file($_FILES['image']['tmp_name']))
              {
                //echo "cmp<br>";
                $test1 = explode(".", $_FILES["image"]["name"]);
                $extension1 = end($test1);
                $image = 'Updated_emp-profle-'.date('Y-m-d').uniqid().'.'.$extension1;
          
                $config['file_name']= $image;
                $this->upload->initialize($config);
                $this->load->library('upload', $config);  
                $this->lets_upload_employee('image');

                $file = './upload/'.$data['emp_ad']['image'];
                if(is_file($file))
                  unlink($file);
              }
            }
            if(isset($_FILES["adhar"]['tmp_name']))
            {
              if(file_exists($_FILES["adhar"]['tmp_name']) || is_uploaded_file($_FILES['adhar']['tmp_name']))
              {
                //echo "cmp<br>";
                $test1 = explode(".", $_FILES["adhar"]["name"]);
                $extension1 = end($test1);
                $adhar = 'Updated-Adhar_image-'.date('Y-m-d').uniqid().'.'.$extension1;
          
                $config['file_name']= $adhar;
                $this->upload->initialize($config);
                $this->load->library('upload', $config);  
                $this->lets_upload_employee('adhar');

                $file = './upload/'.$data['emp_ad']['adhar'];
                if(is_file($file))
                  unlink($file);
              }
            }
            if(isset($_FILES["passbook"]['tmp_name']))
            {
              if(file_exists($_FILES["passbook"]['tmp_name']) || is_uploaded_file($_FILES['passbook']['tmp_name']))
              {
                //echo "cmp<br>";
                $test1 = explode(".", $_FILES["passbook"]["name"]);
                $extension1 = end($test1);
                $passbook = 'Updated-Passbook-'.date('Y-m-d').uniqid().'.'.$extension1;
          
                $config['file_name']= $passbook;
                $this->upload->initialize($config);
                $this->load->library('upload', $config);  
                $this->lets_upload_employee('passbook');

                $file = './upload/'.$data['emp_ad']['passbook'];
                if(is_file($file))
                  unlink($file);
              }
            }
            if(isset($_FILES["pan_up"]['tmp_name']))
            {
              if(file_exists($_FILES["pan_up"]['tmp_name']) || is_uploaded_file($_FILES['pan_up']['tmp_name']))
              {
                //echo "cmp<br>";
                $test1 = explode(".", $_FILES["pan_up"]["name"]);
                $extension1 = end($test1);
                $pan_up = 'Updated-Pancard-'.date('Y-m-d').uniqid().'.'.$extension1;
          
                $config['file_name']= $pan_up;
                $this->upload->initialize($config);
                $this->load->library('upload', $config);  
                $this->lets_upload_employee('pan_up');

                $file = './upload/'.$data['emp_ad']['pan_up'];
                if(is_file($file))
                  unlink($file);
              }
            }
            if(isset($_FILES["ten_mask"]['tmp_name']))
            {
              if(file_exists($_FILES["ten_mask"]['tmp_name']) || is_uploaded_file($_FILES['ten_mask']['tmp_name']))
              {
                //echo "cmp<br>";
                $test1 = explode(".", $_FILES["ten_mask"]["name"]);
                $extension1 = end($test1);
                $ten_mask = 'Update-TenMark-'.date('Y-m-d').uniqid().'.'.$extension1;
          
                $config['file_name']= $ten_mask;
                $this->upload->initialize($config);
                $this->load->library('upload', $config);  
                $this->lets_upload_employee('ten_mask');

                $file = './upload/'.$data['emp_ad']['ten_mask'];
                if(is_file($file))
                  unlink($file);
              }
            }
            if(isset($_FILES["twl_mark"]['tmp_name']))
            {
              if(file_exists($_FILES["twl_mark"]['tmp_name']) || is_uploaded_file($_FILES['twl_mark']['tmp_name']))
              {
                //echo "cmp<br>";
                $test1 = explode(".", $_FILES["twl_mark"]["name"]);
                $extension1 = end($test1);
                $twl_mark = 'Update-TwlMark-'.date('Y-m-d').uniqid().'.'.$extension1;
          
                $config['file_name']= $twl_mark;
                $this->upload->initialize($config);
                $this->load->library('upload', $config);  
                $this->lets_upload_employee('twl_mark');

                $file = './upload/'.$data['emp_ad']['twl_mark'];
                if(is_file($file))
                  unlink($file);
              }
            }

            if(isset($_FILES["medcer_pic"]['tmp_name']))
            {
              if(file_exists($_FILES["medcer_pic"]['tmp_name']) || is_uploaded_file($_FILES['medcer_pic']['tmp_name']))
              {
                //echo "cmp<br>";
                $test1 = explode(".", $_FILES["medcer_pic"]["name"]);
                $extension1 = end($test1);
                $medcer_pic = 'Update-TwlMark-'.date('Y-m-d').uniqid().'.'.$extension1;
          
                $config['file_name']= $medcer_pic;
                $this->upload->initialize($config);
                $this->load->library('upload', $config);  
                $this->lets_upload_employee('medcer_pic');

                $file = './upload/'.$data['emp_ad']['medcer_pic'];
                if(is_file($file))
                  unlink($file);
              }
            }

            if(isset($_FILES["policcer_pic"]['tmp_name']))
            {
              if(file_exists($_FILES["policcer_pic"]['tmp_name']) || is_uploaded_file($_FILES['policcer_pic']['tmp_name']))
              {
                //echo "cmp<br>";
                $test1 = explode(".", $_FILES["policcer_pic"]["name"]);
                $extension1 = end($test1);
                $policcer_pic = 'Update-TwlMark-'.date('Y-m-d').uniqid().'.'.$extension1;
          
                $config['file_name']= $policcer_pic;
                $this->upload->initialize($config);
                $this->load->library('upload', $config);  
                $this->lets_upload_employee('policcer_pic');

                $file = './upload/'.$data['emp_ad']['policcer_pic'];
                if(is_file($file))
                  unlink($file);
              }
            }

             $jdate = '';
             $rej_date = '';
             $description ='';
              foreach ($this->input->post('jdate') as $key => $value) 
              {
                if($jdate == "")
                {
                    $jdate =  $value["jdate"];
                }
                else
                {
                    $jdate .= ','.$value["jdate"];
                }
              
              }
               foreach ($this->input->post('rej_date') as $key => $value) 
              {
                if($rej_date == "")
                {
                    $rej_date =  $value["rej_date"];
                }
                else
                {
                    $rej_date .= ','.$value["rej_date"];
                }
              
              }
              foreach ($this->input->post('description') as $key => $value) 
              {
                if($description == "")
                {
                    $description =  $value["description"];
                }
                else
                {
                    $description .= ','.$value["description"];
                }
              
              }
                  
            $params = array(
            
              'fname' => $this->input->post('fname'),
              'lname' => $this->input->post('lname'),
              'esic_num' => $this->input->post('esic_num'),
              'faname' => $this->input->post('faname'),
              'moname' => $this->input->post('moname'),
              'addr' => $this->input->post('addr'),
              'addr2' => $this->input->post('addr2'),
              'desg' => $this->input->post('desg'),
              'gender' => $this->input->post('gender'),
              'cont' => $this->input->post('cont'),
              'dob' => $this->input->post('dob'),
              'ac_no' => $this->input->post('ac_no'),
              'ac_name' => $this->input->post('ac_name'),
              'ifsc' => $this->input->post('ifsc'),
              'bank_name' => $this->input->post('bank_name'),
              'loc_type' => $this->input->post('loc_type'),
              'city' => $this->input->post('city'),
              'co_name' => $this->input->post('co_name'),
              'zone' => $this->input->post('zone'),
              'mem_nm' => $this->input->post('mem_nm'),
              'mem_rel' => $this->input->post('mem_rel'),
              'mem_lvng' => $this->input->post('mem_lvng'),
              'mem_con' => $this->input->post('mem_con'),
              'med_cer' => $this->input->post('med_cer'),
              'polic_ver' => $this->input->post('polic_ver'),
              'polic_case' => $this->input->post('polic_case'),
              'nationality' => $this->input->post('nationality'),
              'mrg_status' => $this->input->post('mrg_status'),
              'adhar_num' => $this->input->post('adhar_num'),
              'pan_num' => $this->input->post('pan_num'),
              'jdate' => $jdate,
              'rej_date' => $rej_date,
              'description' => $description,
              'image' => $image,
              'adhar' => $adhar,
              'passbook' => $passbook,
              'pan_up' => $pan_up,
              'ten_mask' => $ten_mask,
              'twl_mark' => $twl_mark,
              'medcer_pic' => $medcer_pic,
              'policcer_pic' => $policcer_pic,
              
            );

            $this->SAdmin_model->update_emp($id,$params);
            redirect('Dashboard/All_Employee');
          }
          else
          {
            $data['emp_ad'] = $this->SAdmin_model->get_emp($id);
            $data['all_city_type'] = $this->SAdmin_model->get_all_city_type('city');
             $data['all_cmp_type'] = $this->SAdmin_model->get_all_comp_type();
             $data['all_zone_type'] = $this->SAdmin_model->get_all_zone_type();
            $data['_view'] = 'SubAdmin/Employee/Editemp';
            $this->load->view('SubAdmin/Employee/Editemp',$data);
          }
        }
        else
        {
          show_error('The City you are trying to edit does not exist.');
        }
      }
      function Del_Employee($id)
      {
          $emp = $this->SAdmin_model->get_emp($id);

          if(isset($emp['id']))
          {
              $this->SAdmin_model->delete_emp($id);
              redirect('Dashboard/All_Employee');
          }
          else
              show_error('The admin you are trying to delete does not exist.');
      }
      function lets_upload_employee( $field_name )   
      {
        if( ! $this->upload->do_upload( $field_name ))    
        {
          $this->data['notification'] .= $this->upload->display_errors(); 
        }
        else
        {
          $upload_data = $this->upload->data();    
          $path = $upload_data['file_name'];   
          $this->data['notification'] = " is successfully uploaded.<br>";    
        }
      }


     /*Employeee  Start*/
      function All_Attandance()
      {    
        $params['limit'] = 'RECORDS_PER_PAGE'; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('SubAdmin/attendance/Viewattd');
        $config['total_rows'] = $this->SAdmin_model->get_all_attendance_count();
        $this->pagination->initialize($config);

        $data['attnd_data'] = $this->SAdmin_model->get_all_attendanceList($params);
        
      
        $data['cur_page'] = "dashboard";
        $data['main_page'] = "All_Client";
        $data['_view'] =  'SubAdmin/attendance/Viewattd';
        $this->load->view('SubAdmin/attendance/Viewattd',$data);
      }

       function Add_Attandance()
      {    
        $params['limit'] = 'RECORDS_PER_PAGE'; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('SubAdmin/attendance/Viewempat');
        $config['total_rows'] = $this->SAdmin_model->get_all_empat_count();
        $this->pagination->initialize($config);

        $data['emp_data'] = $this->SAdmin_model->get_all_empatList($params);
        
      
        $data['cur_page'] = "dashboard";
        $data['main_page'] = "All_Client";
        $data['_view'] =  'SubAdmin/attendance/Viewempat';
        $this->load->view('SubAdmin/attendance/Viewempat',$data);
      }
      
      function search_att()
      {    
        
        $data['cur_page'] = "dashboard";
        $data['main_page'] = "All_Client";
        $data['_view'] =  'SubAdmin/attendance/Viewempat';
        $this->load->view('SubAdmin/attendance/Viewempat',$data);
      }
     
       function Emp_attendance($id)
      {
        $data['cur_page'] = "dashboard"; 
        $data['data_ad'] = $this->SAdmin_model->get_emp_atd_data($id);
        $data['_view'] = 'SubAdmin/attendance/Addattendace';
        $this->load->view('SubAdmin/attendance/Addattendace',$data);
      }
      
      function New_Attandance()
      {    
        $params['limit'] = 'RECORDS_PER_PAGE'; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('SubAdmin/newAtnd/Viewnewatnd');
        $config['total_rows'] = $this->Admin_model->get_all_empat_count();
        $this->pagination->initialize($config);

        $data['attnd_data'] = $this->Admin_model->get_all_empatList($params); 
      
        $data['cur_page'] = "dashboard";
        $data['main_page'] = "All_Client";
        $data['all_company'] = $this->Admin_model->get_company_data();
        $data['_view'] =  'SubAdmin/newAtnd/Viewnewatnd';
        $this->load->view('SubAdmin/newAtnd/Viewnewatnd',$data);
      }
    
    /*Attendance Print Monthly*/
     
    public function Print_atn_mnthly($id)
    {
        $data = $this->SAdmin_model->get_atdby_month($id);
      
        foreach ($data as $key) {
            
         $attend_days =  $key['month_days']-$key['absent_days'];
         $vend_id = $key['emp_id'];
         $data2 = $this->SAdmin_model->get_emp($vend_id);


        $ab1 = explode('-_-', $key['absent_detail']);
      
        $ab_day = array();
        $ab_det = array();
          for ($i=0; $i < $key['absent_days'] ; $i++)
          { 
           $ab2 = explode('-', $ab1[$i]);
           array_push($ab_day, $ab2[0]);
           array_push($ab_det, $ab2[1]);
          }
         
        $html = '<!-- Main content -->
         <!DOCTYPE html>
        <html>
          <head>
            <title>GAMA Attandance Slip</title>
            <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
            <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
            <style>
              html, body {
              min-height: 90%;
              }
              body, div, form, input, select, textarea, label { 
              padding: 0;
              margin: 0;
              outline: none;
              font-family: Roboto, Arial, sans-serif;
              font-size: 14px;
              color: #666;
              line-height: 22px;
              }
              h1 {
              position: absolute;
              margin:0;
              font-size: 30px;
              color: #fff;
              z-index: 2;
              line-height: 83px;
              top:10px;
              }
              legend {
              padding: 10px;      
              font-family: Roboto, Arial, sans-serif;
              font-size: 18px;
              color: #fff;
              background-color: #1c87c9;
              }
              textarea {
              width: calc(100% - 12px);
              padding: 5px;
              }
              .testbox {
              display: flex;
              justify-content: center;
              align-items: center;
              height: inherit;
              padding: 20px;
              }
              form {
              width: 90%;
              padding: 20px;
              border-radius: 5px;
              background: #fff;
              box-shadow: 0 0 8px #006622; 
              }
              .banner {
              position: relative;
              height: 100px;
              display: flex;
              justify-content: center;
              align-items: center;
              text-align: center;
              }
              .banner::after {
              content: "";
              background-color: rgba(0, 0, 0, 0.4); 
              position: absolute;
              width: 100%;
              height: 100%;
              }
              input, select, textarea {
              margin-bottom: 10px;
              border: 1px solid #ccc;
              border-radius: 3px;
              }
              input {
              width: calc(100% - 10px);
              padding: 5px;
              }
              input[type="date"] {
              padding: 4px 5px;
              }
              textarea {
              width: calc(100% - 12px);
              padding: 5px;
              }
              .item:hover p, .item:hover i, .question:hover p, .question label:hover, input:hover::placeholder {
              color:  #006622;
              }
              .item {
              position: relative;
              margin: 3px 0;
              }
              .item span {
              color: red;
              }
              .week {
              display:flex;
              justfiy-content:space-between;
              }
              .colums {
              display:flex;
              justify-content:space-between;
              flex-direction:row;
              flex-wrap:wrap;
              }
              .colums div {
              width:48%;
              }
              input[type=radio], input[type=checkbox]  {
              display: none;
              }
              label.radio {
              position: relative;
              display: inline-block;
              margin: 5px 20px 15px 0;
              cursor: pointer;
              }
              .question span {
              margin-left: 30px;
              }
              .question-answer label {
              display: block;
              }
              label.radio:before {
              content: "";
              position: absolute;
              left: 0;
              width: 5px;
              height: 5px;
              border-radius: 50%;
              border: 2px solid #ccc;
              }
              input[type=radio]:checked + label:before, label.radio:hover:before {
              border: 2px solid  #006622;
              }

              label{
                font-weight: 500;
                font-size: 15px;
              }
              
            
              .flax {
              display:flex;
              justify-content:space-around;
              }
              .btn-block {
              margin-top: 10px;
              text-align: center;
              }
              button {
              width: 150px;
              padding: 10px;
              border: none;
              border-radius: 5px; 
              background:  #1c87c9;
              font-size: 16px;
              color: #fff;
              cursor: pointer;
              }
              button:hover {
              background:  #0692e8;
              }
              @media (min-width: 568px) {
              .name-item, .city-item {
              display: flex;
              flex-wrap: wrap;
              justify-content: space-between;
              }
              .name-item input, .name-item div {
              width: calc(50% - 20px);
              }
              .name-item div input {
              width:97%;}
              .name-item div label {
              display:block;
              padding-bottom:5px;
              }
              }
              .banner p{
                margin-top:80px;
                color: red;
              }
            </style>
          </head>
          <body>
            <div class="testbox">
            <form>

              <div class="banner">
                <img src="../../../Gama_hrms/upload/logo.png" style="width: 50px; height: 50px; "><h1>GAMA GUARD SERVICES PVT</h1>
              </div>
              <br/>
             
                <div class="colums">
                  <div class="item">
                    <label for="fname"><span>*</span>Name of Contractors -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;</label> 
                  </div>
                  <div class="item">
                    <label for="fname"><span>*</span>Name of Principal Employee -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;</label>
                  </div>
                  <div class="item">
                    <label for="fname"><span>*</span>Location of Work -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;</label> 
                  </div>
                  <div class="item">
                    <label for="fname"><span>*</span>Wages Period -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;</label>
                  </div>
                  <div class="item">
                    <label for="fname"><span>*</span> First Name -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;</label> 
                  </div>
                  <div class="item">
                    <label for="fname"><span>*</span> From -&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;</label>
                    <label for="fname"><span>*</span> To -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;</label>
                  </div>
                </div>
             <br><br><br>
               <table class="table table-bordered" id="table_nodisp1" border="1">
                 <thead>
                        <tr>
                            <th class="center">S.no</th>
                            <th class="center">emp code</th>
                            <th class="center">Name</th>
                            <th class="center">designation</th>';
                            for ($i=1; $i <= $key['month_days']; $i++) 
                            { 
                                $html .='<th> '.$i.' </th>';
                            }
                           
                             $html .='<th class="center">total</th>
                            <th class="center">Signature</th>
                        </tr>
                    </thead>
                    <tbody id="nodisp_out">
                      <tr>
                         <td>01</td>  
                         <td>'.$key['emp_code'].'</td>  
                         <td>'.$key['emp_name'].'</td>  
                         <td>'.$data2['desg'].'</td>';
                         $j=0;
                         $l=1;
                         
                          for ($i=0,$day = 1; $i < $key['month_days']; $i++,$day++) 
                          { 
                            
                            if (in_array($day, $ab_day))
                            {
                              $pos = array_search($day, $ab_day);
                              $html .='<td id="'.$i.'">'.$ab_det[$pos].'</td>';
                            }
                            else{
                               $html .='<td id="'.$i.'">P</td>';
                            }

                              
                          }
                         $html .='
                         <td>'.$attend_days.'</td>  
                      </tr>
                    </tbody>
              </table>
              <br/> <br/>
             
             <div class="btn-block">
              <button onclick="window.print();return false;" type="" href="/"><i class="fas fa-print"></i></button>
            </div>
            </form>
            </div>
             
          </body>
         </html>';
        }
          echo $html;
      
    }
    
    /*Attendance Print Single*/
     public function Print_attandance($id)
     {
        $attend_data = $this->Admin_model->get_emp_atd_data($id); 

         $ab1 = explode('-_-', $attend_data['absent_detail']);
      
        $ab_day = array();
        $ab_det = array();
          for ($i=0; $i < $attend_data['absent_days'] ; $i++)
          { 
           $ab2 = explode('-', $ab1[$i]);
           array_push($ab_day, $ab2[0]);
           array_push($ab_det, $ab2[1]);
          }
         


         $attend_days =  $attend_data['month_days']-$attend_data['absent_days'];
         $vend_id = $attend_data['emp_id'];
         $data2 = $this->Admin_model->get_emp($vend_id);
         
        $vend_id = $data2['city'];
        $city = $this->Admin_model->comapare($vend_id);
         
        $vend_id3 = $data2['zone'];
        $zone = $this->Admin_model->comapare_zone($vend_id3);


           
        $html = '<!-- Main content -->
         <!DOCTYPE html>
        <html>
          <head>
            <title>GAMA Attandance Slip</title>
            <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
            <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
            <style>
              html, body {
              min-height: 90%;
              }
              body, div, form, input, select, textarea, label { 
              padding: 0;
              margin: 0;
              outline: none;
              font-family: Roboto, Arial, sans-serif;
              font-size: 14px;
              color: #666;
              line-height: 22px;
              }
              h1 {
              position: absolute;
              margin:0;
              font-size: 30px;
              color: #fff;
              z-index: 2;
              line-height: 83px;
              top:10px;
              }
              legend {
              padding: 10px;      
              font-family: Roboto, Arial, sans-serif;
              font-size: 18px;
              color: #fff;
              background-color: #1c87c9;
              }
              textarea {
              width: calc(100% - 12px);
              padding: 5px;
              }
              .testbox {
              display: flex;
              justify-content: center;
              align-items: center;
              height: inherit;
              padding: 20px;
              }
              form {
              width: 90%;
              padding: 20px;
              border-radius: 5px;
              background: #fff;
              box-shadow: 0 0 8px #006622; 
              }
              .banner {
              position: relative;
              height: 100px;
              display: flex;
              justify-content: center;
              align-items: center;
              text-align: center;
              }
              .banner::after {
              content: "";
              background-color: rgba(0, 0, 0, 0.4); 
              position: absolute;
              width: 100%;
              height: 100%;
              }
              input, select, textarea {
              margin-bottom: 10px;
              border: 1px solid #ccc;
              border-radius: 3px;
              }
              input {
              width: calc(100% - 10px);
              padding: 5px;
              }
              input[type="date"] {
              padding: 4px 5px;
              }
              textarea {
              width: calc(100% - 12px);
              padding: 5px;
              }
              .item:hover p, .item:hover i, .question:hover p, .question label:hover, input:hover::placeholder {
              color:  #006622;
              }
              .item {
              position: relative;
              margin: 3px 0;
              }
              .item span {
              color: red;
              }
              .week {
              display:flex;
              justfiy-content:space-between;
              }
              .colums {
              display:flex;
              justify-content:space-between;
              flex-direction:row;
              flex-wrap:wrap;
              }
              .colums div {
              width:48%;
              }
              input[type=radio], input[type=checkbox]  {
              display: none;
              }
              label.radio {
              position: relative;
              display: inline-block;
              margin: 5px 20px 15px 0;
              cursor: pointer;
              }
              .question span {
              margin-left: 30px;
              }
              .question-answer label {
              display: block;
              }
              label.radio:before {
              content: "";
              position: absolute;
              left: 0;
              width: 5px;
              height: 5px;
              border-radius: 50%;
              border: 2px solid #ccc;
              }
              input[type=radio]:checked + label:before, label.radio:hover:before {
              border: 2px solid  #006622;
              }

              label{
                font-weight: 500;
                font-size: 15px;
              }
              
            
              .flax {
              display:flex;
              justify-content:space-around;
              }
              .btn-block {
              margin-top: 10px;
              text-align: center;
              }
              button {
              width: 150px;
              padding: 10px;
              border: none;
              border-radius: 5px; 
              background:  #1c87c9;
              font-size: 16px;
              color: #fff;
              cursor: pointer;
              }
              button:hover {
              background:  #0692e8;
              }
              @media (min-width: 568px) {
              .name-item, .city-item {
              display: flex;
              flex-wrap: wrap;
              justify-content: space-between;
              }
              .name-item input, .name-item div {
              width: calc(50% - 20px);
              }
              .name-item div input {
              width:97%;}
              .name-item div label {
              display:block;
              padding-bottom:5px;
              }
              }
              .banner p{
                margin-top:80px;
                color: red;
              }
            </style>
          </head>
          <body>
            <div class="testbox">
            <form>

              <div class="banner">
                <img src="../../../Gama_hrms/upload/logo.png" style="width: 50px; height: 50px; "><h1>GAMA GUARD SERVICES PVT</h1>
              </div>
              <br/>
             
                <div class="colums">
                  <div class="item">
                    <label for="fname"><span>*</span>Name of Contractors -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;'.$attend_data['cmp_name'].'</label> 
                  </div>
                  <div class="item">
                    <label for="fname"><span>*</span>Name of Principal Employee -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;'.$data2['fname'].'</label>
                  </div>
                  <div class="item">
                    <label for="fname"><span>*</span>Location of Work -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;'.$city[0]['city'].'&nbsp;,&nbsp;'.$zone[0]['zone'].'</label> 
                  </div>
                  <div class="item">
                    <label for="fname"><span>*</span>Wages Period -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;'.$attend_data['month'].'/'.$attend_data['year'].'</label>
                  </div>
                  <div class="item">
                    <label for="fname"><span>*</span> First Name -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;</label> 
                  </div>
                  <div class="item">
                    <label for="fname"><span>*</span> From -&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;</label>
                    <label for="fname"><span>*</span> To -&nbsp;&nbsp;</label> 
                    <label for="fname">&nbsp;&nbsp;</label>
                  </div>
                </div>
             <br><br><br>
               <table class="table table-bordered" id="table_nodisp1" border="1">
                    <thead>
                        <tr>
                            <th class="center">S.no</th>
                            <th class="center">emp code</th>
                            <th class="center">Name</th>
                            <th class="center">designation</th>';
                            for ($i=1; $i <= $attend_data['month_days']; $i++) 
                            { 
                                $html .='<th> '.$i.' </th>';
                            }
                           
                             $html .='<th class="center">total</th>
                            <th class="center">Signature</th>
                        </tr>
                    </thead>
                    <tbody id="nodisp_out">
                      <tr>
                         <td>01</td>  
                         <td>'.$attend_data['emp_code'].'</td>  
                         <td>'.$attend_data['emp_name'].'</td>  
                         <td>'.$data2['desg'].'</td>';
                         $j=0;
                         $l=1;
                          for ($i=0,$day = 1; $i < $attend_data['month_days']; $i++,$day++) 
                          { 
                            
                            if (in_array($day, $ab_day))
                            {
                              $pos = array_search($day, $ab_day);
                              $html .='<td id="'.$i.'">'.$ab_det[$pos].'</td>';
                            }
                            else{
                               $html .='<td id="'.$i.'">P</td>';
                            }

                              
                          }
                         $html .='
                         <td>'.$attend_days.'</td>  
                      </tr>
                    </tbody>
              </table>
              <br/> <br/>
             
             <div class="btn-block">
              <button onclick="window.print();return false;" type="" href="/"><i class="fas fa-print"></i></button>
            </div>
            </form>
            </div>
             
          </body>
        </html>';
          echo $html;
      
     }

}