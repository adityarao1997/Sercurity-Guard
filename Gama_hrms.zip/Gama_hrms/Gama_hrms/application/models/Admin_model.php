<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model
{
        function __construct()
        {
            parent::__construct();
        }
        
       /*
        *   Profile Detail Incubatee
        */
        function get_current_profile()
        {
            $Login_id = $this->session->userdata('id');
            $query=$this->db->query("select * from user_admin where id='$Login_id'");
            return $query->result_array();
           
        } 
        function comapare($id)
        {
             $city_id = $id;
             $this->db->from('city');
             $where = "id='$city_id'";
             $this->db->where($where);
             return $this->db->get()->result_array();
        }
        function comapare_zone($id)
        {
             $zone_id = $id;
             $this->db->from('zone');
             $where = "id='$zone_id'";
             $this->db->where($where);
             return $this->db->get()->result_array();
        }
        function comapare_com($id)
        {
             $company_id = $id;
             $this->db->from('client');
             $where = "id='$company_id'";
             $this->db->where($where);
             return $this->db->get()->result_array();
        }
        /*
       * Get Profile by id
       */
        function get_profile($id)
        {
            return $this->db->get_where('user_admin',array('id'=>$id))->row_array();
        }
         function update_profile($id,$params)
        {
            $this->db->where('id',$id);
            return $this->db->update('user_admin',$params);
        }

       /*City Panel Start*/
        function get_all_city_count()
        {
            $this->db->from('city');
            return $this->db->count_all_results();
        }
        function get_all_cityList($params = array())
        {
            $this->db->order_by('id', 'desc');
            return $this->db->get('city')->result_array();
        }
        function get_city_avail($id)
        {
            return $this->db->get_where('city',array('id'=>$id))->row_array();
        }
        function add_city($city)
        {
            
            $data = array(

                'city' => $city,
                
                 );
            return $this->db->insert('city', $data); 
        }
        function update_city($id,$params)
        {
            $this->db->where('id',$id);
            return $this->db->update('city',$params);
        }
        function delete_city($id)
        {
            return $this->db->delete('city',array('id'=>$id));
        }
        function get_company_data()
        {
            $this->db->order_by('id', 'desc');
            return $this->db->get('emp_detail')->result_array();
        }
        /*City Panel Close*/


        /*City Panel Start*/
        function get_all_client_count()
        {
            $this->db->from('client');
            return $this->db->count_all_results();
        }
        function get_all_clientList($params = array())
        {
            $this->db->order_by('id', 'desc');
            return $this->db->get('client')->result_array();
        }
        function get_client_avail($id)
        {
            return $this->db->get_where('client',array('id'=>$id))->row_array();
        }
         function add_client($cl_name,$cl_coname,$cl_city,$cl_address,$work_order_no,$work_order_pic,$cl_noemp,$cl_gst,$cl_agno,$cl_cont,$laber_no,$cl_agri_stdate,$cl_agri_enddate,$client_logo,$laber_pic,$order_pic,$rate_breakup_img)
        {
            
            $data = array(

                'cl_name' => $cl_name,
                'cl_coname' => $cl_coname,
                'cl_city' => $cl_city,
                'cl_address' => $cl_address,
                'work_order_no' => $work_order_no,
                'work_order_pic' => $work_order_pic,
                'cl_noemp' => $cl_noemp,
                'cl_gst' => $cl_gst,
                'cl_agno' => $cl_agno,
                'cl_cont' => $cl_cont,
                'laber_no' => $laber_no,
                'cl_agri_stdate' => $cl_agri_stdate,
                'cl_agri_enddate' => $cl_agri_enddate,
                'client_logo' => $client_logo,
                'laber_pic' => $laber_pic,
                'order_pic' => $order_pic,
                'rate_breakup_img' => $rate_breakup_img,
                
                 );
            return $this->db->insert('client', $data); 
        }
        function update_client($id,$params)
        {
            $this->db->where('id',$id);
            return $this->db->update('client',$params);
        }
        function delete_client($id)
        {
            return $this->db->delete('client',array('id'=>$id));
        }
        function get_all_city_type($params)
        {
            $this->db->order_by('id', 'desc');
             $where = "$params<>'no' ";
            $this->db->where($where);
            return $this->db->get('city')->result_array();
        }
        function get_all_comp_type()
        {
            $this->db->order_by('id', 'desc');
            
            return $this->db->get('client')->result_array();
        }
         function get_all_zone_type()
        {
            $this->db->order_by('id', 'desc');
            
            return $this->db->get('zone')->result_array();
        }
        /*City Panel Close*/


          /*City Panel Start*/
        function get_all_zone_count()
        {
            $this->db->from('zone');
            return $this->db->count_all_results();
        }
        function get_all_zoneList($params = array())
        {
            $this->db->order_by('id', 'desc');
            return $this->db->get('zone')->result_array();
        }
        function get_zone_avail($id)
        {
            return $this->db->get_where('zone',array('id'=>$id))->row_array();
        }
        function add_zone($city,$co_name,$zone,$depf,$cepf,$desi,$cesi)
        {
            
            $data = array(

                'city' => $city,
                'co_name' => $co_name,
                'zone' => $zone,
                'depf' => $depf,
                'cepf' => $cepf,
                'desi' => $desi,
                'cesi' => $cesi,
                
                 );
            return $this->db->insert('zone', $data); 
        }
        function update_zone($id,$params)
        {
            $this->db->where('id',$id);
            return $this->db->update('zone',$params);
        }
        function delete_zone($id)
        {
            return $this->db->delete('zone',array('id'=>$id));
        }
        /*Zone CLose*/


         /*City Panel Start*/
        function get_all_admin_count()
        {
            $this->db->from('user_admin');
            return $this->db->count_all_results();
        }
        function get_all_adminList($params = array())
        {
            $this->db->order_by('id', 'desc');
            $where = "type='1'";
            $this->db->where($where);
            return $this->db->get('user_admin')->result_array();
        }
        function get_admin($id)
        {
            return $this->db->get_where('user_admin',array('id'=>$id))->row_array();
        }
        function add_admin($name,$email,$contact,$city,$pass,$type,$avtar)
        {
            
            $data = array(

                'name' => $name,
                'email' => $email,
                'contact' => $contact,
                'city' => $city,
                'pass' => $pass,
                'type' => $type,
                
                 );
            return $this->db->insert('user_admin', $data); 
        }
        function update_admin($id,$params)
        {
            $this->db->where('id',$id);
            return $this->db->update('user_admin',$params);
        }
        function delete_admin($id)
        {
            return $this->db->delete('user_admin',array('id'=>$id));
        }
        /*Zone CLose*/

         /*City Panel Start*/
        function get_all_sadmin_count()
        {
            $this->db->from('user_admin');
            return $this->db->count_all_results();
        }
        function get_all_sadminList($params = array())
        {
            $this->db->order_by('id', 'desc');
            $where = "type='2'";
            $this->db->where($where);
            return $this->db->get('user_admin')->result_array();
        }
        function get_sadmin($id)
        {
            return $this->db->get_where('user_admin',array('id'=>$id))->row_array();
        }
        function add_sadmin($city,$co_name,$zone,$depf,$cepf,$desi,$cesi)
        {
            
            $data = array(

                'city' => $city,
                'co_name' => $co_name,
                'zone' => $zone,
                'depf' => $depf,
                'cepf' => $cepf,
                'desi' => $desi,
                'cesi' => $cesi,
                
                 );
            return $this->db->insert('user_admin', $data); 
        }
        function update_sadmin($id,$params)
        {
            $this->db->where('id',$id);
            return $this->db->update('user_admin',$params);
        }
        function delete_sadmin($id)
        {
            return $this->db->delete('user_admin',array('id'=>$id));
        }
        /*Zone CLose*/


         /*City Panel Start*/
        function get_all_emp_count()
        {
            $this->db->from('emp_detail');
            return $this->db->count_all_results();
        }
        function get_all_empList($params = array())
        {
            $this->db->order_by('id', 'desc');
            return $this->db->get('emp_detail')->result_array();
        }
        function get_emp($id)
        {
            return $this->db->get_where('emp_detail',array('id'=>$id))->row_array();
        }
        function add_employee($fname,$lname,$esic_num,$faname,$moname,$addr,$addr2,$desg,$gender,$cont,$dob,$jdate,$ac_no,$ac_name,$ifsc,$bank_name,$loc_type,$city,$co_name,$zone,$mem_nm,$mem_rel,$mem_con,$med_cer,$polic_ver,$polic_case,$nationality,$mrg_status,$adhar_num,$pan_num,$image,$adhar,$passbook,$pan_up,$ten_mask,$twl_mark,$other_bnk,$other_deg,$medcer_pic,$policcer_pic)
        {
            $emp_id = 'GAMA000'.strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 1));
            $data = array(

                'fname' => $fname,
                'lname' => $lname,
                'esic_num' => $esic_num,
                'faname' => $faname,
                'moname' => $moname,
                'addr' => $addr,
                'addr2' => $addr2,
                'desg' => $desg,
                'gender' => $gender,
                'cont' => $cont,
                'dob' => $dob,
                'jdate' => $jdate,
                'ac_no' => $ac_no,
                'ac_name' => $ac_name,
                'ifsc' => $ifsc,
                'bank_name' => $bank_name,
                'loc_type' => $loc_type,
                'city' => $city,
                'co_name' => $co_name,
                'zone' => $zone,
                'mem_nm' => $mem_nm,
                'mem_rel' => $mem_rel,
                'mem_con' => $mem_con,
                'med_cer' => $med_cer,
                'polic_ver' => $polic_ver,
                'polic_case' => $polic_case,
                'nationality' => $nationality,
                'mrg_status' => $mrg_status,
                'adhar_num' => $adhar_num,
                'pan_num' => $pan_num,
                'image' => $image,
                'adhar' => $adhar,
                'passbook' => $passbook,
                'pan_up' => $pan_up,
                'ten_mask' => $ten_mask,
                'twl_mark' => $twl_mark,
                'other_bnk' => $other_bnk,
                'other_deg' => $other_deg,
                'medcer_pic' => $medcer_pic,
                'policcer_pic' => $policcer_pic,
                'emp_id' => $emp_id,
                
                 );
            return $this->db->insert('emp_detail', $data); 
        }
        function update_emp($id,$params)
        {
            $this->db->where('id',$id);
            return $this->db->update('emp_detail',$params);
        }
        function delete_emp($id)
        {
            return $this->db->delete('emp_detail',array('id'=>$id));
        }
        /*City Panel Close*/

        /*City Panel Start*/
        function get_all_attendance_count()
        {
            $this->db->from('payment');
            return $this->db->count_all_results();
        }
        function get_all_attendanceList($params = array())
        {
            $this->db->order_by('id', 'desc');
            return $this->db->get('payment')->result_array();
        }
        function add_attandace($emp_name,$contact_no,$cmp_name,$month,$year,$city,$zone,$uan,$absent_days,$absent_type,$emp_id,$contact_no)
        {
            
            $data = array(

                'emp_name' => $emp_name,
                'contact_no' => $contact_no,
                'cmp_name' => $cmp_name,
                'month' => $month,
                'year' => $year,
                'city' => $city,
                'zone' => $zone,
                'uan' => $uan,
                'emp_id' => $emp_id,
                'contact_no' => $contact_no,
                'absent_days' => $absent_days,
                'absent_type' => $absent_type,
                
                 );
            return $this->db->insert('payment', $data); 
        }
         function get_all_empat_count()
        {
            $this->db->from('emp_detail');
            return $this->db->count_all_results();
        }
        function get_all_empatList($params = array())
        {
            $this->db->order_by('id', 'desc');
            return $this->db->get('emp_detail')->result_array();
        }
        function get_emp_atd_data($id)
        {
            return $this->db->get_where('payment',array('id'=>$id))->row_array();
        }
         
       
        function add_atd($params)
        {
            $this->db->insert('payment',$params);
            return $this->db->insert_id();
        }
        
        function get_attendance($id)
        {
            return $this->db->get_where('payment',array('id'=>$id))->row_array();
        }
        function delete_attendance($id)
        {
            return $this->db->delete('payment',array('id'=>$id));
        }
        
         function serch_locType($loc)
        {
          $query = $this->db->query("SELECT DISTINCT city FROM emp_detail WHERE loc_type='$loc'");
          $total = $query->num_rows();
          $ret = "";
          if($total > 0)
          {
            //$ret = $query->result_array();
            $result = $query->result_array();
            foreach($result as $key)
            {
              $temp_city_id = $key["city"];
              $query1 = $this->db->query("SELECT city FROM city WHERE id='$temp_city_id'");
              $result1 = $query1->row_array();

              $city_name = $result1["city"];
              $ret .= '<option value="'.$city_name.'-_-'.$temp_city_id.'">'.$city_name.'</option>';
            }
          }
          else
          {
            $ret = '<option value="">No Employee In This Location</option>';
          }
          return $ret;
        }

        function serchcmp_bycity($city)
        {
          $query = $this->db->query("SELECT zone FROM emp_detail WHERE city='$city'");
          $total = $query->num_rows();
          $ret = "";
          if($total > 0)
          {
            //$ret = $query->result_array();
            $result = $query->result_array();
            foreach($result as $key)
            {
              $temp_id = $key["zone"];
              $query1 = $this->db->query("SELECT zone FROM zone WHERE id='$temp_id'");
              $result1 = $query1->row_array();

              $get_name = $result1["zone"];
              $ret .= '<option value="'.$get_name.'-_-'.$temp_id.'">'.$get_name.'</option>';
            }
          }
          else
          {
            $ret = '<option value="">No Employee In This City '.$city.'</option>';
          }
          return $ret;
        }

        function serchcmp_byzone($zone)
        {
          $query = $this->db->query("SELECT co_name FROM emp_detail WHERE zone='$zone'");
          $total = $query->num_rows();
          $ret = "";
          if($total > 0)
          {
            //$ret = $query->result_array();
            $result = $query->result_array();
            foreach($result as $key)
            {
              $temp_id = $key["co_name"];
              $query1 = $this->db->query("SELECT cl_coname FROM client WHERE id='$temp_id'");
              $result1 = $query1->row_array();

              $get_name = $result1["cl_coname"];
              $ret .= '<option value="'.$get_name.'-_-'.$temp_id.'">'.$get_name.'</option>';
            }
          }
          else
          {
            $ret = '<option value="">No Employee In This City '.$city.'</option>';
          }
          return $ret;
        }

        function serchcmp_byemp($coname_sel)
        {
          
          $query = $this->db->query("SELECT * FROM emp_detail WHERE co_name='$coname_sel'");
          $total = $query->num_rows();
          $ret = "";
          if($total > 0)
          {
            //$ret = $query->result_array();
            $result = $query->result_array();
            $ret .= 
            '<tbody class="tbody_top_body">';
              foreach($result as $key)
              {
                $i = 1;
                $id = $key["id"];
                $fname = $key["fname"];
                $mob = $key["cont"];
                $uan = $key["lname"];
                $desg = $key["desg"];
                $ret .= '
                    <tr>
                      <td><input type="checkbox" class="select_employee" id="'.$id.'" value="'.$id.'">&nbsp '.$i.'</td>
                      <td>'.$fname.'</td>
                      <td>'.$desg.'</td>
                      <td>'.$mob.'</td>
                      <td>'.$uan.'</td>
                    </tr>
                ';$i++;
              }
            $ret .= 
            '</tbody>';
          }
          else
          {
            $ret = '<option value="">No Employee In This City '.$city.'</option>';
          }
          return $ret;
        }
        
        function rettddata($idemp, $sel_month, $sel_year)
        {
          $id = $idemp;
          $query = $this->db->query("SELECT * FROM emp_detail WHERE id='$id'");

          $days_in_month=cal_days_in_month(CAL_GREGORIAN,$sel_month,$sel_year);

          $row = $query->row_array();
          $name = $row["fname"];
          $image = $row["image"];
          $uan = $row["lname"];
          $bname = $row["bank_name"];
          $bifsc = $row["ifsc"];
          $bacno = $row["ac_no"];
          $cont = $row["cont"];
          $emp_code = $row["emp_id"];
          $desg = $row["desg"];
          $output = "";

          $optn = '<option value="full">Full</option><option value="half">Half</option><option value="NH">NH</option>';

          $output .= '
          <tr id="row-'.$id.'" class="alltrs">
            <td class="text-center first_td" id="row-'.$id.'"></td>
            <td class="text-center" >
              '.$emp_code.'
            </td>
            <td class="text-center" >
              '.$uan.'
            </td>
            <td class="text-center" id="nametd-'.$id.'">
              '.$name.'
              <input type="hidden" id="uanno_'.$id.'" value="'.$uan.'">
              <input type="hidden" id="contaid_'.$id.'" value="'.$cont.'">
              <input type="hidden" id="empname_'.$id.'" value="'.$name.'">
              <input type="hidden" id="emp_code_'.$id.'" value="'.$emp_code.'">
            </td>
            <td class="text-center">
              '.$desg.'
            </td>
            <td class="text-center">
              '.$bacno.'
            </td>
            
            ';
            $i = 1;
            while($i <= $days_in_month)
            {
              $output .= '
                <td>
                  <input type="checkbox" id="daytd'.$id.$i.'" class="allabscheck allabscheck'.$id.' allabscheck'.$id.$i.'" value="'.$i.'" data-curid="'.$id.'" data-curday="'.$i.'"><select id="daysel_'.$id.$i.'">'.$optn.'</select>
                </td>
              ';
              $i++;
            }
            $output .= '
            
          </tr>.
          ';
          return $output;
        }
        
         function convert_city($temp)
        {
            $this->db->order_by('city', 'desc');
            $where = "id='$temp'";
            $this->db->where($where);
            return $this->db->get('city')->result_array();
        }
        
        function add_attendanceNewOne($emp_code_a,$nametd_a,$uanno_a,$contaid_a,$daytd_a,$daysel_a)
        {
                $data = array(

                'emp_id' => $emp_code_a,
                'emp_name' => $nametd_a,
                'uan' => $uanno_a,
                'contact_no' => $contaid_a,
                'absent_days' => $daytd_a,
                'absent_type' => $daysel_a,
                 );
            return $this->db->insert('payment', $data); 
        }

        function add_attendancenew($emp_code_a, $nametd_a, $uanno_a, $contaid_a, $emp_atid, $absent_days, $all_absent_detail,$atsub_cmp, $atsub_monthday, $atsub_month, $atsub_year)
        {
          $cmp = explode('-_-', $atsub_cmp);
          $temp1 = explode('-_-', $all_absent_detail);
          $Login_id = $this->session->userdata('id');
          $cmp_id = $cmp[1];
          $query = $this->db->query("SELECT id FROM payment WHERE emp_id='$emp_atid' AND cmp_id='$cmp_id' AND month='$atsub_month' AND year='$atsub_year'");
          $total = $query->num_rows();
          if($total == 0)
          {
            $data = array(
            'emp_id' => $emp_atid,
            'admin_id' => $Login_id,
            'emp_code' => $emp_code_a,
            'uan' => $uanno_a,
            'emp_name' => $nametd_a,
            'contact_no' => $contaid_a,
            'cmp_name' => $cmp[0],
            'cmp_id' => $cmp_id,
            'month' => $atsub_month,
            'month_days' => $atsub_monthday,
            'year' => $atsub_year,
            'absent_days' => $absent_days,
            'absent_detail' => $all_absent_detail,
             );
             $this->db->insert('payment', $data);
            
            $count_product = $absent_days;
            for($x = 0; $x < $count_product; $x++) {
            $temp2 = explode('-', $temp1[$x]);
             $y = 1;
             $z = 0;
            $items = array(
                'emp_id' => $emp_atid,
                'mnth' => $atsub_month,
                'day' => $temp2[$z],
                'year' => $atsub_year,
                'abs_det' => $temp2[$y],
                'emp_code' => $emp_code_a,
                'cmp_id' => $cmp_id,
            );
 
            $this->db->insert('absnt_detail', $items);
           
              }
          }
          else
          {
            return "already";
          }
        }
        
        
         function serch_month_attenda($loc)
        {
          $query = $this->db->query("SELECT DISTINCT month  FROM payment WHERE year='$loc'");
          $total = $query->num_rows();
          $ret = "";
          if($total > 0)
          {
            //$ret = $query->result_array();
            $result = $query->result_array();
            foreach($result as $key)
            {
              $temp_city_id = $key["month"];
              $ret = $temp_city_id;
            }
          }
          else
          {
            $ret = '<p>No Month In This Year</p>';
          }
          return $ret;
        }

         function get_atdby_month($id)
        {
            $this->db->order_by('id', 'desc');
            $where = "month='$id'";
            $this->db->where($where);
            return $this->db->get('payment')->result_array();

        }
         
}?>