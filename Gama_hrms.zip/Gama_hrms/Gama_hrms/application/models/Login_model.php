<?php

 /**
  * 
  */
 class Login_model extends CI_Model
 {
 	
 	 public function login_all($email, $pass, $type)
 	 {
 	      $query = $this->db->where(['email'=>$email, 'pass'=>$pass, 'type'=>$type])->get('user_admin');

              if($query->num_rows() > 0){
                  return $query->row()->id;
              }
 	 }
 	 
 	 public function login_sub($email, $pass, $type)
       {
            $query = $this->db->where(['email'=>$email, 'pass'=>$pass, 'type'=>$type])->get('user_admin');
    
                  if($query->num_rows() > 0){
                      return $query->row()->id;
                  }
       }

 	/*
     * function to add new vendor
     */
    function add_vendor($params)
    {
        $this->db->insert('admin',$params);
        return $this->db->insert_id();
    }
    
   
     function Get_vender_catergory($id)
        {
             $query = $this->db->where(['id'=>$id])
                 ->get('vendor_type');
               
                   return $query->result();
              
        } 
        
    function get_all_preferd_id($params = array())
    {
        if(isset($_SESSION["Login_id"]))
        {
          $login = $_SESSION["Login_id"];
          $this->db->where('vendor_id',$login);
        }

        if(isset($params) && !empty($params))
        {
          $this->db->where($params);
        }

        $this->db->order_by('id', 'desc');
        return $this->db->get('prefered_for')->result_array();
    }
     function get_all_food_id($params = array())
    {
        if(isset($_SESSION["Login_id"]))
        {
          $login = $_SESSION["Login_id"];
          $this->db->where('vendor_id',$login);
        }

        if(isset($params) && !empty($params))
        {
          $this->db->where($params);
        }

        $this->db->order_by('id', 'desc');
        return $this->db->get('food_available')->result_array();
    }
      function get_all_music_type($params = array())
        {
            $this->db->order_by('id', 'desc');   
            return $this->db->get('music')->result_array();
        }
    function get_all_music_id($params = array())
    {
        if(isset($_SESSION["Login_id"]))
        {
          $login = $_SESSION["Login_id"];
          $this->db->where('vendor_id',$login);
        }
        if(isset($params) && !empty($params))
        {
          $this->db->where($params);
        }

        $this->db->order_by('id', 'desc');
        return $this->db->get('music_available')->result_array();
    }
    function get_all_facility_id($params = array())
    {
        if(isset($_SESSION["Login_id"]))
        {
          $login = $_SESSION["Login_id"];
          $this->db->where('vendor_id',$login);
        }
        if(isset($params) && !empty($params))
        {
          $this->db->where($params);
        }
        $this->db->order_by('id', 'desc');
        return $this->db->get('facility_available')->result_array();
    }
    function get_all_special_id($params = array())
    {
        if(isset($_SESSION["Login_id"]))
        {
          $login = $_SESSION["Login_id"];
          $this->db->where('vendor_id',$login);
        }
        if(isset($params) && !empty($params))
        {
          $this->db->where($params);
        }
        
        $this->db->order_by('id', 'desc');
        return $this->db->get('special_available')->result_array();
    }
      function get_all_special_cat($vend_type)
        {
            $this->db->order_by('id', 'desc');
            $this->db->group_by('special_cat');
            $where = "vendor_typeid='$vend_type'";
            $this->db->where($where);
            return $this->db->get('special')->result_array();
        }
    function get_all_deco_id($params = array())
    {
        if(isset($_SESSION["Login_id"]))
        {
          $login = $_SESSION["Login_id"];
          $this->db->where('vendor_id',$login);
        }

        if(isset($params) && !empty($params))
        {
          $this->db->where($params);
        }
        
        $this->db->order_by('id', 'desc');
        return $this->db->get('decoration_type_available')->result_array();
    }
    function get_all_setup_id($params = array())
    {
        if(isset($_SESSION["Login_id"]))
        {
          $login = $_SESSION["Login_id"];
          $this->db->where('vendor_id',$login);
        }
        if(isset($params) && !empty($params))
        {
          $this->db->where($params);
        }
        
        $this->db->order_by('id', 'desc');
        return $this->db->get('setup_available')->result_array();
    }
    function get_all_type_id($params = array())
    {
        if(isset($_SESSION["Login_id"]))
        {
          $login = $_SESSION["Login_id"];
          $this->db->where('vendor_id',$login);
        }
        if(isset($params) && !empty($params))
        {
          $this->db->where($params);
        }
        
        $this->db->order_by('id', 'desc');
        return $this->db->get('type_available')->result_array();
    }
    
       /*
        * Get admin by id
        */
        function get_all_food_type($params = array())
        {
            $this->db->order_by('id', 'desc');   
            return $this->db->get('food')->result_array();
        }

        /*
        * Get admin by id
        */
        function get_all_facility_type($params = array())
        {
            $this->db->order_by('id', 'desc');
            
            return $this->db->get('facilities')->result_array();
        }
        /*
        * Get admin by id
        */
        function get_all_type($params = array())
        {
            $this->db->order_by('id', 'desc');
            
            return $this->db->get('types')->result_array();
        }
         /*
        * Get admin by id
        */
        function get_all_special($params = array())
        {
            $this->db->order_by('id', 'desc');
            
            return $this->db->get('special')->result_array();
        }
       /*
        * Get admin by id
        */
        function get_all_prefered($params = array())
        {
            $this->db->order_by('id', 'desc');
            
            return $this->db->get('prefered')->result_array();
        }
         function get_Vendor_from_data($id)
        {
            return $this->db->get_where('vendor_form_data',array('id'=>$id))->row_array();
        }
        /*
        * Get admin by id
        */
        function get_all_Services()
        {
            $this->db->order_by('id', 'desc');
            
            return $this->db->get('doyou_provide')->result_array();
        }
        /*
        * Get admin by id
        */
        function get_all_setup()
        {
            $this->db->order_by('id', 'desc');
            
            return $this->db->get('setup')->result_array();
        }
        /*
        * Get admin by id
        */
        function get_all_decoTpe($params = array())
        {
            $this->db->order_by('id', 'desc');
            return $this->db->get('decoration_type')->result_array();
        }
       

        function Get_vender_catergory_form($id)
        {
             $query = $this->db->where(['id'=>$id])
                 ->get('vendor_type');
               
                   return $query->result();
              
        }
    
  
 }
?>