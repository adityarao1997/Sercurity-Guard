<?php

    /**
     *  Sub admin Model 
     */
    class SAdmin_model extends CI_Model
    {
    	
    	 function __construct()
         {
            parent::__construct();
         }

          /*
        *   Profile Detail Incubatee
        */
        function get_current_profile()
        {
            $Login_id = $this->session->userdata('id');
            $query=$this->db->query("select * from user_admin where id='$Login_id'");
            return $query->result_array();
           
        } 
        function comapare($id)
        {
             $city_id = $id;
             $this->db->from('city');
             $where = "id='$city_id'";
             $this->db->where($where);
             return $this->db->get()->result_array();
        }
        function comapare_zone($id)
        {
             $zone_id = $id;
             $this->db->from('zone');
             $where = "id='$zone_id'";
             $this->db->where($where);
             return $this->db->get()->result_array();
        }
        function comapare_com($id)
        {
             $company_id = $id;
             $this->db->from('client');
             $where = "id='$company_id'";
             $this->db->where($where);
             return $this->db->get()->result_array();
        }
        function get_all_city_type($params)
        {
            $this->db->order_by('id', 'desc');
             $where = "$params<>'no' ";
            $this->db->where($where);
            return $this->db->get('city')->result_array();
        }
        function get_all_comp_type()
        {
            $this->db->order_by('id', 'desc');
            
            return $this->db->get('client')->result_array();
        }
         function get_all_zone_type()
        {
            $this->db->order_by('id', 'desc');
            
            return $this->db->get('zone')->result_array();
        }

              /*City Panel Start*/
        function get_all_emp_count()
        {
            
            $this->db->from('emp_detail');
             
            return $this->db->count_all_results();
        }
        function get_all_empList($params = array())
        {
             
             $login_dtl = $this->SAdmin_model->get_current_profile();
             $log_city = $login_dtl[0]['city'];
            $this->db->order_by('id', 'desc');
            $where = "city='$log_city'";
            $this->db->where($where);
            return $this->db->get('emp_detail')->result_array();
        }
        function get_emp($id)
        {
            return $this->db->get_where('emp_detail',array('id'=>$id))->row_array();
        }
        function add_employee($fname,$lname,$esic_num,$faname,$moname,$addr,$addr2,$desg,$gender,$cont,$dob,$jdate,$ac_no,$ac_name,$ifsc,$bank_name,$loc_type,$city,$co_name,$zone,$mem_nm,$mem_rel,$mem_con,$med_cer,$polic_ver,$polic_case,$nationality,$mrg_status,$adhar_num,$pan_num,$image,$adhar,$passbook,$pan_up,$ten_mask,$twl_mark,$medcer_pic,$policcer_pic)
        {
            $admin_id = $this->session->userdata('id');
            $emp_id = 'GAMA000'.strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 1));
            $data = array(

                'fname' => $fname,
                'lname' => $lname,
                'esic_num' => $esic_num,
                'faname' => $faname,
                'moname' => $moname,
                'addr' => $addr,
                'addr2' => $addr2,
                'desg' => $desg,
                'gender' => $gender,
                'cont' => $cont,
                'dob' => $dob,
                'jdate' => $jdate,
                'ac_no' => $ac_no,
                'ac_name' => $ac_name,
                'ifsc' => $ifsc,
                'bank_name' => $bank_name,
                'loc_type' => $loc_type,
                'city' => $city,
                'co_name' => $co_name,
                'zone' => $zone,
                'mem_nm' => $mem_nm,
                'mem_rel' => $mem_rel,
                'mem_con' => $mem_con,
                'med_cer' => $med_cer,
                'polic_ver' => $polic_ver,
                'polic_case' => $polic_case,
                'nationality' => $nationality,
                'mrg_status' => $mrg_status,
                'adhar_num' => $adhar_num,
                'pan_num' => $pan_num,
                'image' => $image,
                'adhar' => $adhar,
                'passbook' => $passbook,
                'pan_up' => $pan_up,
                'ten_mask' => $ten_mask,
                'twl_mark' => $twl_mark,
                'medcer_pic' => $medcer_pic,
                'policcer_pic' => $policcer_pic,
                'admin_id' => $admin_id, 
                'emp_id' => $emp_id, 
                
                 );
            return $this->db->insert('emp_detail', $data); 
        }
        function update_emp($id,$params)
        {
            $this->db->where('id',$id);
            return $this->db->update('emp_detail',$params);
        }
        function delete_emp($id)
        {
            return $this->db->delete('emp_detail',array('id'=>$id));
        }
        /*City Panel Close*/

        /*City Panel Start*/
        function get_all_attendance_count()
        {
            $this->db->from('payment');
            return $this->db->count_all_results();
        }
        function get_all_attendanceList($params = array())
        {
            $admin_id = $this->session->userdata('id');
            $this->db->order_by('id', 'desc');
            $where = "admin_id='$admin_id'";
            $this->db->where($where);
            return $this->db->get('payment')->result_array();
        }
         function get_all_empat_count()
        {
            $this->db->from('emp_detail');
            return $this->db->count_all_results();
        }
        function get_all_empatList($params = array())
        {
            $this->db->order_by('id', 'desc');
            return $this->db->get('emp_detail')->result_array();
        }
        function get_emp_atd_data($id)
        {
            return $this->db->get_where('payment',array('id'=>$id))->row_array();
        }
         
       
        function add_atd($params)
        {
            $this->db->insert('payment',$params);
            return $this->db->insert_id();
        }
         /*City Panel Close*/
         
        function serch_locType($loc)
        {
          $query = $this->db->query("SELECT DISTINCT city FROM emp_detail WHERE loc_type='$loc'");
          $total = $query->num_rows();
          $ret = "";
          if($total > 0)
          {
            //$ret = $query->result_array();
              $result = $query->result_array();
              $admin_id = $this->session->userdata('id');
              $vender_city = $this->SAdmin_model->get_current_profile($admin_id);
              $city = $vender_city[0]["city"];
              $query1 = $this->db->query("SELECT city FROM city WHERE id='$city'");
              $result1 = $query1->row_array();

              $city_name = $result1["city"];
              $ret .= '<option value="'.$city_name.'-_-'.$city.'">'.$city_name.'</option>';
          }
          else
          {
            $ret = '<option value="">No Employee In This Location</option>';
          }
          return $ret;
        }

        function serchcmp_bycity($city)
        {
          $query = $this->db->query("SELECT zone FROM emp_detail WHERE city='$city'");
          $total = $query->num_rows();
          $ret = "";
          if($total > 0)
          {
            //$ret = $query->result_array();
            $result = $query->result_array();
            foreach($result as $key)
            {
              $temp_id = $key["zone"];
              $query1 = $this->db->query("SELECT zone FROM zone WHERE id='$temp_id'");
              $result1 = $query1->row_array();

              $get_name = $result1["zone"];
              $ret .= '<option value="'.$get_name.'-_-'.$temp_id.'">'.$get_name.'</option>';
            }
          }
          else
          {
            $ret = '<option value="">No Employee In This City '.$city.'</option>';
          }
          return $ret;
        }

        function serchcmp_byzone($zone)
        {
          $query = $this->db->query("SELECT co_name FROM emp_detail WHERE zone='$zone'");
          $total = $query->num_rows();
          $ret = "";
          if($total > 0)
          {
            //$ret = $query->result_array();
            $result = $query->result_array();
            foreach($result as $key)
            {
              $temp_id = $key["co_name"];
              $query1 = $this->db->query("SELECT cl_coname FROM client WHERE id='$temp_id'");
              $result1 = $query1->row_array();

              $get_name = $result1["cl_coname"];
              $ret .= '<option value="'.$get_name.'-_-'.$temp_id.'">'.$get_name.'</option>';
            }
          }
          else
          {
            $ret = '<option value="">No Employee In This City '.$city.'</option>';
          }
          return $ret;
        }

        function serchcmp_byemp($coname_sel)
        {
          $query = $this->db->query("SELECT * FROM emp_detail WHERE co_name='$coname_sel'");
          $total = $query->num_rows();
          $ret = "";
          if($total > 0)
          {
            //$ret = $query->result_array();
            $result = $query->result_array();
            foreach($result as $key)
            {
              $i = 1;
              $id = $key["id"];
              $fname = $key["fname"];
              $mob = $key["cont"];
              $uan = $key["lname"];
              $desg = $key["desg"];
              $ret .= '
                  <tr>
                   <td><input type="checkbox" class="select_employee" id="'.$id.'" value="'.$id.'">&nbsp '.$i.'</td>
                    <td>'.$fname.'</td>
                    <td>'.$desg.'</td>
                    <td>'.$mob.'</td>
                    <td>'.$uan.'</td>
                </tr>
              ';$i++;
            }
          }
          else
          {
            $ret = '<option value="">No Employee In This City '.$city.'</option>';
          }
          return $ret;
        }
        
        function rettddata($idemp, $sel_month, $sel_year)
        {
          $id = $idemp;
          $query = $this->db->query("SELECT * FROM emp_detail WHERE id='$id'");

          $days_in_month=cal_days_in_month(CAL_GREGORIAN,$sel_month,$sel_year);

          $row = $query->row_array();
          $name = $row["fname"];
          $image = $row["image"];
          $uan = $row["lname"];
          $bname = $row["bank_name"];
          $bifsc = $row["ifsc"];
          $bacno = $row["ac_no"];
          $cont = $row["cont"];
          $emp_code = $row["emp_id"];
          $desg = $row["desg"];
          $output = "";

          $optn = '<option value="full">Full</option><option value="half">Half</option><option value="NH">NH</option>';

          $output .= '
          <tr id="row-'.$id.'" class="alltrs">
            <td class="text-center first_td" id="row-'.$id.'"></td>
            <td class="text-center" >
              '.$emp_code.'
            </td>
            <td class="text-center" >
              '.$uan.'
            </td>
            <td class="text-center" id="nametd-'.$id.'">
              '.$name.'
              <input type="hidden" id="uanno_'.$id.'" value="'.$uan.'">
              <input type="hidden" id="contaid_'.$id.'" value="'.$cont.'">
              <input type="hidden" id="empname_'.$id.'" value="'.$name.'">
              <input type="hidden" id="emp_code_'.$id.'" value="'.$emp_code.'">
            </td>
            <td class="text-center">
              '.$desg.'
            </td>
            <td class="text-center">
              '.$bacno.'
            </td>
            
            ';
            $i = 1;
            while($i <= $days_in_month)
            {
              $output .= '
                <td>
                  <input type="checkbox" id="daytd'.$id.$i.'" class="allabscheck allabscheck'.$id.' allabscheck'.$id.$i.'" value="'.$i.'" data-curid="'.$id.'" data-curday="'.$i.'"><select id="daysel_'.$id.$i.'">'.$optn.'</select>
                </td>
              ';
              $i++;
            }
            $output .= '
            
          </tr>.
          ';
          return $output;
        }
        
         function convert_city($temp)
        {
            $this->db->order_by('city', 'desc');
            $where = "id='$temp'";
            $this->db->where($where);
            return $this->db->get('city')->result_array();
        }
        
        function add_attendanceNewOne($emp_code_a,$nametd_a,$uanno_a,$contaid_a,$daytd_a,$daysel_a)
        {
                $data = array(

                'emp_id' => $emp_code_a,
                'emp_name' => $nametd_a,
                'uan' => $uanno_a,
                'contact_no' => $contaid_a,
                'absent_days' => $daytd_a,
                'absent_type' => $daysel_a,
                 );
            return $this->db->insert('payment', $data); 
        }

       

         function add_attendancenew($emp_code_a, $nametd_a, $uanno_a, $contaid_a, $emp_atid, $absent_days, $all_absent_detail,$atsub_cmp, $atsub_monthday, $atsub_month, $atsub_year)
        {
          $cmp = explode('-_-', $atsub_cmp);
          $temp1 = explode('-_-', $all_absent_detail);
          $Login_id = $this->session->userdata('id');
          $cmp_id = $cmp[1];
          $query = $this->db->query("SELECT id FROM payment WHERE emp_id='$emp_atid' AND cmp_id='$cmp_id' AND month='$atsub_month' AND year='$atsub_year'");
          $total = $query->num_rows();

          if($total == 0)
          {
             
            $data = array(
            'emp_id' => $emp_atid,
            'emp_code' => $emp_code_a,
            'uan' => $uanno_a,
            'emp_name' => $nametd_a,
            'contact_no' => $contaid_a,
            'cmp_name' => $cmp[0],
            'cmp_id' => $cmp_id,
            'month' => $atsub_month,
            'month_days' => $atsub_monthday,
            'year' => $atsub_year,
            'absent_days' => $absent_days,
            'absent_detail' => $all_absent_detail,
            'admin_id' => $Login_id,
             );
             $this->db->insert('payment', $data);
            
            $count_product = $absent_days;
            for($x = 0; $x < $count_product; $x++) {
            $temp2 = explode('-', $temp1[$x]);
             $y = 1;
             $z = 0;
            $items = array(
                'emp_id' => $emp_atid,
                'mnth' => $atsub_month,
                'day' => $temp2[$z],
                'year' => $atsub_year,
                'abs_det' => $temp2[$y],
                'emp_code' => $emp_code_a,
                'cmp_id' => $cmp_id,
            );
 
            $this->db->insert('absnt_detail', $items);
           
              }
          }
          else
          {
            return "already";
          }
        }
        
        
          function serch_month_attenda($loc)
        {
          $query = $this->db->query("SELECT DISTINCT month FROM payment WHERE year='$loc'");
          $total = $query->num_rows();
          $ret = "";
          if($total > 0)
          {
            //$ret = $query->result_array();
            $result = $query->result_array();
            foreach($result as $key)
            {
              $temp_city_id = $key["month"];
              $ret = $temp_city_id;
            }
          }
          else
          {
            $ret = '<p>No Month In This Year</p>';
          }
          return $ret;
        }

         function get_atdby_month($id)
        {
            $this->db->order_by('id', 'desc');
            $where = "month='$id'";
            $this->db->where($where);
            return $this->db->get('payment')->result_array();

        }


    
 
 
}?>