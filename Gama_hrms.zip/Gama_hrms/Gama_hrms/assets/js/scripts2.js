$(document).ready(function()
{
  $('#col_table').DataTable();
});



function scroll_to_class(element_class, removed_height) {
	var scroll_to = $(element_class).offset().top - removed_height;
	if($(window).scrollTop() != scroll_to) {
		$('html, body').stop().animate({scrollTop: scroll_to}, 0);
	}
}

function bar_progress(progress_line_object, direction) {
	var number_of_steps = progress_line_object.data('number-of-steps');
	var now_value = progress_line_object.data('now-value');
	var new_value = 0;
	if(direction == 'right') {
		new_value = now_value + ( 100 / number_of_steps );
	}
	else if(direction == 'left') {
		new_value = now_value - ( 100 / number_of_steps );
	}
	progress_line_object.attr('style', 'width: ' + new_value + '%;').data('now-value', new_value);
}

jQuery(document).ready(function() {
	
    /*
        Fullscreen background
    */
    
    
    $('#top-navbar-1').on('shown.bs.collapse', function(){
    	$.backstretch("resize");
    });
    $('#top-navbar-1').on('hidden.bs.collapse', function(){
    	$.backstretch("resize");
    });
    
    /*
        Form
    */
    $('.f1 fieldset:first').fadeIn('slow');
    
    $('.f1 input[type="text"], .f1 input[type="password"], .f1 textarea').on('focus', function() {
    	$(this).removeClass('input-error');
    });
    
    // next step
    $('.f1 .btn-next').on('click', function() {
    	var parent_fieldset = $(this).parents('fieldset');
    	var next_step = true;
    	// navigation steps / progress steps
    	var current_active_step = $(this).parents('.f1').find('.f1-step.active');
    	var progress_line = $(this).parents('.f1').find('.f1-progress-line');
    	
    	// fields validation
    	parent_fieldset.find('input[type="text"], input[type="password"], textarea').each(function() {
    		if( $(this).val() == "" ) {
    			$(this).addClass('input-error');
    			next_step = false;
    		}
    		else {
    			$(this).removeClass('input-error');
    		}
    	});
    	// fields validation
    	
    	if( next_step ) {
    		parent_fieldset.fadeOut(400, function() {
    			// change icons
    			current_active_step.removeClass('active').addClass('activated').next().addClass('active');
    			// progress bar
    			bar_progress(progress_line, 'right');
    			// show next step
	    		$(this).next().fadeIn();
	    		// scroll window to beginning of the form
    			scroll_to_class( $('.f1'), 20 );
	    	});
    	}
    	
    });
    
    // previous step
    $('.f1 .btn-previous').on('click', function() {
    	// navigation steps / progress steps
    	var current_active_step = $(this).parents('.f1').find('.f1-step.active');
    	var progress_line = $(this).parents('.f1').find('.f1-progress-line');
    	
    	$(this).parents('fieldset').fadeOut(400, function() {
    		// change icons
    		current_active_step.removeClass('active').prev().removeClass('activated').addClass('active');
    		// progress bar
    		bar_progress(progress_line, 'left');
    		// show previous step
    		$(this).prev().fadeIn();
    		// scroll window to beginning of the form
			scroll_to_class( $('.f1'), 20 );
    	});
    });
    
    // submit
    $('.f1').on('submit', function(e) {
    	
    	// fields validation
    	$(this).find('input[type="text"], input[type="password"], textarea').each(function() {
    		if( $(this).val() == "" ) {
    			e.preventDefault();
    			$(this).addClass('input-error');
    		}
    		else {
    			$(this).removeClass('input-error');
    		}
    	});
    	// fields validation
    	
    });
    
    
});
$(document).on('click' , '.dlt_click', function()
{ //console.log('dfsddsfsddddddd');
    event.preventDefault();
    var dlt_click = $(this).attr("data-url");
    var data_name = $(this).attr("data-name");
    $('.modal-body').html('<b>Name</b>- '+data_name);
    $('.delete_id').attr('href', dlt_click);
    
    $('#exampleModal').modal('show');
});

$(document).on('change', '#loc_type', function()
{
  var loc_type1 = $('#loc_type').val();
  $('#co_name').html('');
  $("#emp_type").html('');
  $('#emp_out').html('');
  $("#table_emp_body").html('');
  $('#city_div').html('Please Wait city...');
  if(loc_type1 != "")
  { 
    $.ajax({
        
        url:"../Dashboard/access_ajax_other/",
        method:"POST",
        data:{loc_type1:loc_type1},
        cache:false,
        dataType : "json",
        success:function(data)
        {
            //console.log(data);
            $('#city_div').html(data);
        }
    });
  }
  else
  {
    $('#city_div').html('');
  }
});

$(document).on('change', '#city_sel', function()
{
  var city_sel = $('#city_sel').val().split("-_-");
  $("#emp_type").html('');
  $("#table_emp_body").html('');
  $('#emp_out').html('');
  $('#zone_div').html('Please Wait...');
  if(city_sel[0] != "")
  {
    city_sel1 = city_sel[1];

    $.ajax({
        url:"../Dashboard/access_ajax_other/",
        method:"POST",
        data:{city_sel1:city_sel1},
        success:function(data)
        {
          //console.log(data);
          $('#zone_div').html(data);
        }
    });
  }
  else
  {
    $('#zone_div').html('');
  }
});

$(document).on('change', '#zone_sel', function()
{
  var zone_sel = $('#zone_sel').val().split("-_-");
  $("#emp_type").html('');
  $("#table_emp_body").html('');
  $('#emp_out').html('');
  $('#co_name').html('Please Wait...');
  if(zone_sel[0] != "")
  {
    zone_sel1 = zone_sel[1];

    $.ajax({
        url:"../Dashboard/access_ajax_other/",
        method:"POST",
        data:{zone_sel1:zone_sel1},
        success:function(data)
        {
          //console.log(data);
          $('#co_name').html(data);
        }
    });
  }
  else
  {
    $('#co_name').html('');
  }
});

$(document).on('change', '#coname_sel', function()
{
  var coname_sel = $('#coname_sel').val().split("-_-");
  $("#emp_type").html('');
  $("#table_emp_body").html('');
  $('#emp_out').html('');
  $('#emp_type').html('Please Wait...');
  if(coname_sel[0] != "")
  {
    coname_sel1 = coname_sel[1];

    $.ajax({
        url:"../Dashboard/access_ajax_other/",
        method:"POST",
        data:{coname_sel1:coname_sel1},
        success:function(data)
        {
          //console.log(data);
          $('#emp_type').html(data);
        }
    });
  }
  else
  {
    $('#emp_type').html('');
  }
});


$(document).on('change', '#emp_sel', function()
{
  var emp_sel = $('#emp_sel').val();
  var cotemp = $('#coname_sel').val();
  var tmp = $('#emp_sel').val().split("-_-");
  $('#zone_ida').val(tmp[1]);
  var coname_sel1 = tmp[0];
  
  var loc_type2 = $('#loc_type').val();
  var dtmonthps = $('#dtmonthp').val();
  var dtyearps = $('#dtyearp').val();
  $("#table_emp_body").html('');
  if(emp_sel != "")
  {
    emp_sel = tmp[1];
    $.ajax({
        url:"../Dashboard/access_ajax_other",
        method:"POST",
        data:{emp_sel:emp_sel,coname_sel1:coname_sel1,loc_type2:loc_type2, dtmonthps:dtmonthps, dtyearps:dtyearps},
        success:function(data)
        {

          $('#emp_out').html(data);
        }
    });
  }
  else
  {
    $('#emp_out').html('');
  }
});

$(document).on('click', '#chk_all_r', function()
{
  if($(this).prop("checked") == true)
  {
    $(".select_employee").prop("checked", true);
    var tr_allid = get_filter('select_employee');
    $.ajax({
        url:"../Dashboard/access_ajax_other/",
        method:"POST",
        data:{tr_allid:tr_allid},
        beforeSend:function()
        {
            $("input.select_employee").attr("disabled", true);
            $("input#chk_all_r").attr("disabled", true);
        },
        success:function(data)
        {
          $("#table_emp_body").html(data);
          $("input.select_employee").removeAttr("disabled");
          $("input#chk_all_r").removeAttr("disabled");
          put_td_sn11()
        }
    });
  }
  else
  {
    $(".select_employee").prop("checked", false);
    $("#table_emp_body").html('');
  }
});

$(document).on('click', '.select_employee', function()
{
  var tr_id = $(this).attr("id");
  var tr_allid = get_filter('select_employee');
  var sel_month = $("#dtmonthp").val();
  var sel_year = $("#dtmonthp").val();
  $('#tr_allids').val(tr_allid);
  if($(this).prop("checked") == true)
  {
    $.ajax({
        url:"../Dashboard/access_ajax_other/",
        method:"POST",
        data:{tr_id:tr_id, sel_month:sel_month, sel_year:sel_year},
        beforeSend:function()
        {
            $(".select_employee").attr("disabled", true);
        },
        success:function(data)
        {
          //console.log(data);
          $("#add_att_table tbody").append(data);
          $(".select_employee").removeAttr("disabled");
          put_td_sn11();
        }
    });
  }
  else
  {
    $("#row-"+tr_id).remove();
    put_td_sn11();
  }
});

function put_td_sn11()
{
  var rowtr = 0;
  $('.first_td').each(function()
  {
    rowtr++;
    $(this).html(rowtr);
    var rowid = $(this).attr('id');
    $(this).closest('tr').attr('id', rowid);
  });
  if(rowtr > 0)
  {
    $("#save_pay").attr("disabled", false);
  }
  else
  {
    $("#save_pay").attr("disabled", true);
  }
  return rowtr;
}

function get_filter(class_name)
{
  var filter = [];
  $('.'+class_name+':checked').each(function(){
    filter.push($(this).val());
  });
  return filter;
}

$(document).on('click' , '.send_otp_btn', function()
{
    event.preventDefault();
    var mob_no = $('#contact_no').val();
    if(mob_no != "")
    {
        if(mob_no.length == 10)
        {
            $('.send_otp_btn').html('Resend Otp');
            $.ajax({
                url:"access_ajax/",
                method:"POST",
                data:{mob_no:mob_no},
                success:function(data)
                {//console.log(data);
                    $('.otp_div').show();
                    $('#reg_otp').val(data);
                }
            });
        }
        else
        {
            $('#contact_no').addClass('input-error');
            $('.otp_div').hide();
        }   
    }
    else
    {
        $('#contact_no').addClass('input-error');
        $('.otp_div').hide();
    }
});



function chng_img(input, cls)
{
    if (input.files && input.files[0])
    {
        var reader = new FileReader();
        reader.onload = function (e)
        {
            $('.'+cls).attr('src', e.target.result);
        }
        reader.readAsDataURL(input.files[0]);
    }
}
$(document).on('change' , '.img_chng', function()
{
    var target_cl = $(this).attr('data-targetid');
    chng_img(this, target_cl);
});


$(document).on('click', '#save_pay', function()
{
  event.preventDefault();
  var tr_allid = get_filter('select_employee');
  var count_tr = put_td_sn11();
  var allemp_count = tr_allid.length;
  if(allemp_count > 0)
  {
    var form_data = new FormData();
    var atsub_cmp = $('#coname_sel').val();
    var atsub_year = $('#dtyearp').val();
    var atsub_month = $('#dtmonthp').val();

    var days = $("#dtmonthp").find(':selected').data('day');
    
    for (let i = 0; i < allemp_count; i++)
    {
      let curid = tr_allid[i];
      let absent_days = 0;
      let all_absent_detail = "";
      let tempday = "";
      let tempreason = "";
      form_data.append("emp_atid"+i, curid);
      form_data.append("emp_code_a"+i, $('#emp_code_'+curid).val());
      form_data.append("nametd_a"+i, $('#empname_'+curid).val());
      form_data.append("uanno_a"+i, $('#uanno_'+curid).val());
      form_data.append("contaid_a"+i, $('#contaid_'+curid).val());
      $('.allabscheck'+curid).each(function ()
      {
        if(this.checked === true)
        {
          absent_days++;
          tempday = $(this).val();
          tempreason = $('#daysel_'+curid+tempday).val();
          if(all_absent_detail != "")
          {
            all_absent_detail += '-_-';
          }
          all_absent_detail += tempday+'-'+tempreason;
        }
      });
      form_data.append("absent_days"+i, absent_days);
      form_data.append("all_absent_detail"+i, all_absent_detail);
    }
    form_data.append("emp_at_count", allemp_count);
    form_data.append("atsub_cmp", atsub_cmp);
    form_data.append("atsub_year", atsub_year);
    form_data.append("atsub_month", atsub_month);
    form_data.append("atsub_monthday", days);
    $.ajax({
      url:"../AdminDash/access_ajax_other/",
      method:"POST",
      data:form_data,
      contentType:false,
      cache:false,
      processData:false,
      success:function(data)
      {
        if(data == 1)
        {
          alert("Attandance Added");
        }
        else if(data == "already")
        {
          alert("Attandance Already Added");
        }
        else
        {
          alert("Please Retry Later");
        }
      }
    });
  }
});
$(document).on('keyup', '.validateNumber', function() { 
    if (/\D/g.test(this.value))
    {
        // Filter non-digits from input value.
        this.value = this.value.replace(/\D/g, '');
    }
});

$(document).on('click', '.save_vend_data', function()
{
  $('.error_form_msg').html('');
  var ch = 1;
  $('.inpreq').each(function()
  {
    if($(this).val() == "")
    {
      ch = 0;
      $(this).parent().find('label').addClass('error_form');
    }
    else
    {
      $(this).parent().find('label').removeClass('error_form');
    }
  });
  if(ch == 0)
  {
    $('.error_form_msg').html('<label class="text-danger">Please Fill Form First</label>');
    event.preventDefault();
  }
});

$(document).on('change', '#search_mnth', function()
{
  var search_mnth1 = $('#search_mnth').val();
  $('#co_name').html('');
  $("#emp_type").html('');
  $('#emp_out').html('');
  $("#table_emp_body").html('');
  $('#Mnth_btn').html('Please Wait...');
  if(search_mnth1 != "")
  { 
    $.ajax({
        
        url:"../Dashboard/access_ajax_other/",
        method:"POST",
        data:{search_mnth1:search_mnth1},
        cache:false,
        dataType : "json",
        success:function(data)
        {
            //console.log(data);
            $('#Mnth_btn').html(data);
        }
    });
  }
  else
  {
    $('#Mnth_btn').html('');
  }
});